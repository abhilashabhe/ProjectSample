#!/usr/bin/env node
console.log('Starting pre-commit linter...');

var exec = require('child_process').exec;
var fs = require('fs');
var CLIEngine = require('eslint').CLIEngine;
var gulp = require('gulp');
var tslint = require('gulp-tslint');

var files;
var exitCode = 0;

var child = exec("git diff-index --cached --name-only HEAD", function(error, stdout, stderr){
  files = stdout.split('\n').filter(function(i){
    return /\.(js|ts)$/.test(i) && fs.existsSync(i);
  });

  if(files.length === 0){
    console.log('No files to lint. Finished pre-commit linter.');
    return;
  }

  // JS Linting
  var jsFiles = files.filter(function(i) {
    return /\.(js)$/.test(i) && fs.existsSync(i);
  });

  if (jsFiles.length > 0) {
    console.log('JS LINT - \033[1;34mSTARTED\033[0m\n');

    var cli = new CLIEngine({});
    var report = cli.executeOnFiles(jsFiles);
    var results = cli.getFormatter()(report.results);
        exitCode = (report.errorCount === 0 ) ? 0 : 1;
    if(results !== ''){
      console.log(results);
    }
    console.log('JS LINT - \033[1;32mFINISHED\033[0m\n');
  }

  // TS Linting
  var tsFiles = files.filter(function(i) {
    return /\.(ts)$/.test(i) && fs.existsSync(i);
  });

  if (tsFiles.length > 0) {
    console.log('TS LINT - \033[1;34mSTARTED\033[0m\n');
    gulp.task('tslint', function() {
      return gulp.src(tsFiles)
        .pipe(tslint({formatter: 'stylish', configuration: 'tslint.json'}))
        .pipe(tslint.report())
        .on('error', function() {
          exitCode = 1;
          console.log('TS LINT - \033[1;32mFINISHED\033[0m\n');
          process.exit(exitCode);
        });
    });
    gulp.start('tslint');
  } else {
      process.exit(exitCode);
  }

});
