'use strict';

const config = require('../scripts/config');
const fs = require('fs');
const path = require('path');
const SprintWebpackResolver = require('../scripts/sprint-webpack-resolver');
const StatsPlugin = require('stats-webpack-plugin');
const TsConfigPathsPlugin = require('awesome-typescript-loader').TsConfigPathsPlugin;
const webpack = require('webpack');
const WebpackKarmaWarningsPlugin = require('./frontend-config/config/common/webpack/plugins/webpack-karma-warnings-plugin');
const webpackMerge = require('webpack-merge'); // used to merge webpack configs

/**
 * Build the metadata object. This is an options object that is passed to the frontend-config webpack build files
 * to properly create the webpack configuration. This object should also contain any data we may want to pass into the
 * body of the HTML file like a build number, sha, tag name, and/or date.
 */
const buildEnvironment = require('@sprint/frontend-config').getBuildEnvironment({
  projectRoot: path.resolve(__dirname)
});
const baseWebpackConfig = require('@sprint/frontend-config/config/common/webpack/webpack.common.js')(buildEnvironment);

const projectWebpackConfig = {
  // Disable sourcemaps -- AEM does not require these
  devtool: '',

  // Disable performance hints
  performance: {
    hints: false
  },

  /**
   * The base webpack config does not assume any entry points or bundles. You must add them here or nothing will be
   * built. Use an array to pull in multiple entry points into a bundle. The bundles configured here are defaults and
   * should probably be changed on a per-project basis. Please follow webpack configuration documentation.
   */
  entry: {
    'polyfills': [
      './frontend-care/src/polyfills.ts',
      './frontend-cart/src/polyfills.ts',
      './frontend-checkout/src/polyfills.ts'
    ],
    'aem-components': ['./aem-components.ts'],
    'frontend-care': ['./care-main.ts'],
    'frontend-cart': ['./cart-main.ts'],
    'frontend-checkout': ['./checkout-main.ts']
  },

  /**
   * The base webpack config does not assume any output options. You must configure you output if you want the output
   * to be directed to a specific location. This should probably be changed on a per-project basis. Please follow
   * webpack configuration documentation.
   */
  output: {
    path: path.join(__dirname, 'dist'),
    publicPath: '/',
    filename: '[name].js',
    chunkFilename: '[name].js',
    jsonpFunction: 'sprintWebpackJsonpCommon'
  },

  resolve: {
    plugins: [
      new SprintWebpackResolver(),
      new TsConfigPathsPlugin()
    ]
  },

  module: {
    rules: [
      /**
       * Typescript loader support for .ts
       */
      {
        test: /\.ts$/,
        exclude: [
          /\.(spec|e2e)\.ts$/
        ],
        use: [
          {
            loader: 'awesome-typescript-loader',
            query: {
              // Disable source maps, we don't need them
              sourceMap: false,
              inlineSourceMap: false,
              configFileName: 'tsconfig.webpack.json',
              transpileOnly: true, // Disable type checking....its already been done
              compilerOptions: {
                removeComments: true
              }
            }
          }
        ]
      },

      /**
       * Html loader support for *.html
       * Returns file content as string, and minimizing the HTML when required.
       *
       * This cannot be included in the common webpack configuration exposed by frontend-config because we need to add
       * an exclude when we are using the HTMLWebpackPlugin.
       *
       * See: https://github.com/webpack/html-loader
       */
      {
        test: /\.html$/,
        use: [
          {
            loader: 'html-loader'
          }
        ]
      }
    ]
  },

  /**
   * The base webpack config adds the below plugins. If you would like to add more, like the commons chunk plugin, you
   * will need to define them here.
   */
  plugins: [
    new webpack.optimize.OccurrenceOrderPlugin(),

    // Enable JS minification
    new webpack.optimize.UglifyJsPlugin({
      beautify: false,
      output: {
        comments: false
      },
      mangle: {
        screw_ie8: true,
        except: ['$']
      },
      compress: {
        screw_ie8: true,
        warnings: false,
        collapse_vars: true,
        reduce_vars: true,
        conditionals: true,
        unused: true,
        comparisons: true,
        sequences: true,
        dead_code: true,
        evaluate: true,
        if_return: true,
        join_vars: true,
        drop_console: false,
        drop_debugger: true
      }
    }),

    /*
     * Plugin: CommonsChunkPlugin
     * Description: Shares common code between the pages.
     * It identifies common modules and put them into a commons chunk.
     *
     * See: https://webpack.github.io/docs/list-of-plugins.html#commonschunkplugin
     * See: https://github.com/webpack/docs/wiki/optimization#multi-page-app
     */
    new webpack.optimize.CommonsChunkPlugin({
      name: 'polyfills',
      chunks: ['polyfills']
    }),
    new webpack.optimize.CommonsChunkPlugin({
      name: 'vendors',
      chunks: [
        'aem-components',
        'frontend-care',
        'frontend-cart',
        'frontend-checkout'
      ],
      // Move all node_modules into vendors chunk but not @angular
      minChunks: module => /node_modules\/(?!@angular)/.test(module.resource)
    }),
    new webpack.optimize.CommonsChunkPlugin({
      name: 'angular-vendors',
      chunks: [
        'aem-components',
        'frontend-care',
        'frontend-cart',
        'frontend-checkout'
      ],
      // Move all node_modules into vendors chunk but not @angular
      minChunks: module => /node_modules\/@angular/.test(module.resource)
    }),
    new webpack.optimize.CommonsChunkPlugin({
      name: 'shared-modules',
      chunks: [
        'aem-components',
        'frontend-care',
        'frontend-cart',
        'frontend-checkout'
      ],
      // Move duplicate modules to a shared-modules chunk
      minChunks: 2
    }),
    // Specify the correct order the scripts will be injected in
    new webpack.optimize.CommonsChunkPlugin({
      name: ['polyfills', 'vendors'].reverse()
    }),

    // Write out stats file to build directory.
    new StatsPlugin('stats.json', 'verbose'),

    // Fail build on compile warnings/errors
    new WebpackKarmaWarningsPlugin()
  ]
};

// Compile the webpack config and print to console for debugging purposes
const compiledConfig = webpackMerge.smart(baseWebpackConfig, projectWebpackConfig);
module.exports = compiledConfig;
