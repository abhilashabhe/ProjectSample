import './frontend-components/src/aem-components/rxjs';
import { AppModuleNgFactory } from './frontend-care/src/app.module.ngfactory';
import { enableProdMode } from '@angular/core';
import { platformBrowser } from '@angular/platform-browser';

try {
  enableProdMode();
} catch (error) {
  /**
   * We do not care if this errors out. It simply means prod mode
   * has already been enabled.
   */
}

platformBrowser()
  .bootstrapModuleFactory(AppModuleNgFactory)
  .catch(err => {
    console.error(`Bootstrap of the care AppModule failed:\n`, err);
  });
