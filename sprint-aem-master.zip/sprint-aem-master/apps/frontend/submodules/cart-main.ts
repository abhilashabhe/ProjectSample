import './frontend-components/src/aem-components/rxjs';
import { CartAppModuleNgFactory } from './frontend-cart/src/app/cart-app.module.ngfactory';
import { enableProdMode } from '@angular/core';
import { platformBrowser } from '@angular/platform-browser';

try {
  // enableProdMode();
} catch (error) {
  /**
   * We do not care if this errors out. It simply means prod mode
   * has already been enabled.
   */
}

platformBrowser()
  .bootstrapModuleFactory(CartAppModuleNgFactory)
  .catch(err => {
    console.error(`Bootstrap of the cart AppModule failed:\n`, err);
  });
