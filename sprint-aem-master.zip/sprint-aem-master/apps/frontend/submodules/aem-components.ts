// Then we find all the tests.
const context = require.context('./frontend-components/src/aem-components', true, /index\.js$/);
// And load the modules.
context.keys().map(context);
