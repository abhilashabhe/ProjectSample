'use strict';

const config = require('./scripts/config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');

function init() {
  return wrapTaskStatus(require('./scripts/clean-submodules'), 'Cleaning submodules')
    .then(() => Promise.all(
      config.submoduleList.map(submodule =>
        wrapTaskStatus(require('./scripts/checkout-submodule'), `Git checkout (${submodule.name}#${submodule.branch})`, [ submodule ])
      )
    ))
    .then(() => wrapTaskStatus(require('./scripts/copy-common-configurations'), 'Copying common configuration files'))
    .then(() => wrapTaskStatus(require('./scripts/install-dependencies'), 'Installing submodule dependencies'))
    .then(() => wrapTaskStatus(require('./scripts/symlink-submodules'), 'Symlinking submodules'));
}

function build() {
  return Promise.all([
      wrapTaskStatus(require('./scripts/compile-sass'), 'Compiling submodule SASS'),
      wrapTaskStatus(require('./scripts/minify-html'), 'Minifying submodule HTML')
    ])
    .then(() => wrapTaskStatus(require('./scripts/inline-angular-resources'), 'Inlining submodule Angular resources'))
    .then(() => Promise.all(
      config.submoduleList
        .filter(submodule => !submodule.supportSubmodule)
        .map(submodule => wrapTaskStatus(require('./scripts/compile-typescript'), `Compiling typescript for ${submodule.name}`, [ submodule ]))
    ))
    .then(() => wrapTaskStatus(require('./scripts/webpack-build'), 'Building with Webpack'))
    .then(() => wrapTaskStatus(require('./scripts/compile-versions'), 'Compiling submodule version info'))
    .then(() => wrapTaskStatus(require('./scripts/copy-compiled-submodules'), 'Copying compiled submodules'));
}

function refreshGlobalStyles() {
  const stylesSubmodule = config.submoduleList.find(submodule => submodule.name === 'frontend-styles');
  return fs.removeAsync(path.join(config.paths.submodulesPath, stylesSubmodule.name))
    .then(() => wrapTaskStatus(
      require('./scripts/checkout-submodule'),
      `Git checkout ${stylesSubmodule.name}`,
      [
        stylesSubmodule
      ]
    ));
}

function wrapTaskStatus(taskFn, name, args) {
  return new Promise((resolve, reject) => {
    const startTime = (new Date()).getTime();
    console.log(`[${name}] Starting task`);

    taskFn.apply(this, args)
      .then(() => {
        console.log(`[${name}] Task finished in ${(new Date()).getTime() - startTime}ms`);
        resolve();
      })
      .catch(error => {
        console.log(`[${name}] Task failed in ${(new Date()).getTime() - startTime}ms`);
        reject(error);
      });
  });
}

module.exports = {
  init,
  build,
  refreshGlobalStyles
};
