'use strict';

const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const klawSync = require('klaw-sync');
const path = require('path');

function inlineAngularResources() {
  return Promise.all(
    config.submoduleList
      .filter(submodule => !submodule.supportSubmodule)
      .map(submodule => Promise.all(
        klawSync(path.join(config.paths.submodulesPath, submodule.name, 'src'), { nodir: true })
          .filter(file =>
            /.\.ts$/i.test(file.path) &&
            !/.\.spec\.ts$/i.test(file.path)
          )
          .map(file => processFile(file.path))

      ))
  );
}

/**
 * Inline the resources of the given file.
 * @param filePath
 * @return {Promise}
 */
function processFile(filePath) {
  return fs.accessAsync(filePath, fs.constants.R_OK | fs.constants.W_OK)
    .then(() => fs.readFileAsync(filePath, 'utf-8'))
    .then(content => inlineResourcesFromString(content, url => {
      let resolved = path.join(path.dirname(filePath), url);

      if (/.\.scss$/.test(resolved)) {
        resolved = path.join(
          path.dirname(resolved),
          path.basename(resolved, path.extname(resolved)) + '.css'
        );
      }

      return resolved;
    }))
    .then(content => fs.writeFileAsync(filePath, content))
    .catch(error => {
      console.error(error);
    });
}

/**
 * Inline resources from a string content.
 * @param content {string} The source file's content.
 * @param urlResolver {Function} A resolver that takes a URL and return a path.
 * @returns {string} The content with resources inlined.
 */
function inlineResourcesFromString(content, urlResolver) {
  // Curry through the inlining functions.
  return [
    inlineTemplate,
    inlineStyle,
    removeModuleId
  ].reduce((content, fn) => fn(content, urlResolver), content);
}

/**
 * Inline the templates for a source file. Simply search for instances of `templateUrl: ...` and
 * replace with `template: ...` (with the content of the file included).
 * @param content {string} The source file's content.
 * @param urlResolver {Function} A resolver that takes a URL and return a path.
 * @return {string} The content with all templates inlined.
 */
function inlineTemplate(content, urlResolver) {
  return content.replace(/templateUrl:\s*'([^']+?\.html)'/g, function (m, templateUrl) {
    const templateFile = urlResolver(templateUrl);
    const templateContent = fs.readFileSync(templateFile, 'utf-8');
    const shortenedTemplate = templateContent
      .replace(/([\n\r]\s*)+/gm, ' ')
      .replace(/"/g, '\\"');

    return `template: "${shortenedTemplate}"`;
  });
}


/**
 * Inline the styles for a source file. Simply search for instances of `styleUrls: [...]` and
 * replace with `styles: [...]` (with the content of the file included).
 * @param urlResolver {Function} A resolver that takes a URL and return a path.
 * @param content {string} The source file's content.
 * @return {string} The content with all styles inlined.
 */
function inlineStyle(content, urlResolver) {
  return content.replace(/styleUrls:\s*(\[[\s\S]*?\])/gm, function (m, styleUrls) {
    const urls = eval(styleUrls);
    return 'styles: ['
      + urls.map(styleUrl => {
          const styleFile = urlResolver(styleUrl);
          const styleContent = fs.readFileSync(styleFile, 'utf-8');
          const shortenedStyle = styleContent
            .replace(/([\n\r]\s*)+/gm, ' ')
            .replace(/"/g, '\\"');
          return `"${shortenedStyle}"`;
        })
        .join(',\n')
      + ']';
  });
}


/**
 * Remove every mention of `moduleId: module.id`.
 * @param content {string} The source file's content.
 * @returns {string} The content with all moduleId: mentions removed.
 */
function removeModuleId(content) {
  return content.replace(/\s*moduleId:\s*module\.id\s*,?\s*/gm, '');
}

module.exports = inlineAngularResources;
