'use strict';

const child_process = require('child_process');
const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');

function compileSubmoduleVersions() {
  return Promise.all(
    config.submoduleList
      .map(submodule => {
        const versionInfo = {
          repository: submodule.name,
          branch: '',
          hash: '',
          buildDate: (new Date()).toISOString()
        };

        return getGitBranchName(path.join(config.paths.submodulesPath, submodule.name))
          .then(branch => {
            versionInfo.branch = branch;
            return getGitBranchHash(path.join(config.paths.submodulesPath, submodule.name));
          })
          .then(hash => {
            versionInfo.hash = hash;
          })
          .then(() => {
            var prependString = '/*!';
            prependString += '\n * Source Version Information';
            prependString += `\n * Repository: ${versionInfo.repository}`;
            prependString += `\n * Branch: ${versionInfo.branch}`;
            prependString += `\n * Hash: ${versionInfo.hash}`;
            prependString += `\n * Build Date: ${versionInfo.buildDate}`;
            prependString += '\n */\n';
            return fs.outputFileAsync(path.join(config.paths.submodulesPath, 'dist', `${versionInfo.repository}.version.js`), prependString);
          });
      })
  );
}

/**
 * Determines the branch of a git repository at the given path.
 * @param {string} rootPath Path to the git repository.
 * @return {Promise<string>} Branch name of the git repository.
 */
function getGitBranchName(rootPath) {
  return new Promise((resolve, reject) => {
    child_process.exec(
      'git branch | grep "*" | sed -e "s/\\*//g"',
      {
        cwd: rootPath
      },
      (error, result) => {
        if (error) {
          reject(error);
        }

        resolve(result.toString().trim())
      }
    );
  });
}

/**
 * Determines the SHA hash of a git repository at the given path.
 * @param {string} rootPath Path to the git repository.
 * @return {Promise<string>} SHA hash of the git repository.
 */
function getGitBranchHash(rootPath) {
  return new Promise((resolve, reject) => {
    child_process.exec(
      'git rev-parse HEAD',
      {
        cwd: rootPath
      },
      (error, result) => {
        if (error) {
          reject(error);
        }

        resolve(result.toString().trim())
      }
    );
  });
}

module.exports = compileSubmoduleVersions;
