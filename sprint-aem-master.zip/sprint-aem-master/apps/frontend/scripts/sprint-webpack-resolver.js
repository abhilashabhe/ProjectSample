'use strict';
const path = require('path');

/**
 * This class helps Webpack resolver Typescript non-relative imports. The import statements in Sprint frontend-*
 * submodules can look like `src/foobar.ts`. Normal Webpack module resolution would assume that this module lives
 * in node_modules. We could use TsConfigPathsPlugin to help with this but the plugin is ineffective since we
 * compile multiple projects at once (to support vendors.js creation). To solve the module resolution, we need to
 * tell Webpack the module actually can be found at `frontend-/dist/foobar.ts`. That is the goal of this resolver
 * plugin.
 * @constructor
 */
function SprintWebpackResolver() {
}

SprintWebpackResolver.prototype.apply = function(resolver) {
  /**
   * This plugin only cares about module imports when the import is found within a file contained in
   * `submodules/frontend-*`. We also only care about imports that start with `src`.
   *
   * submoduleRegex: This regex will capture the path to the frontend-* submodule.
   * shortImportRegex: This regex will capture the import path after `src`.
   */
  const submoduleRegex = /(.*?[\\|\/]submodules[\\|\/]frontend-.*?)[\\|\/].*/;
  const shortImportRegex = /^src[\\|\/](.*)/; // This is a little limiting and may need to change later

  resolver.plugin('described-resolve', function(module, callback) {
    if (submoduleRegex.test(module.path) && shortImportRegex.test(module.request)) {
      const modulePath = path.resolve(
        module.path.replace(submoduleRegex, '$1'), // The correct submodule to import from based on the requesting file
        'src', // Redirect the import to the `dist` folder
        module.request.replace(shortImportRegex, '$1') // The path to the module being imported starting from a directory with `src`
      );

      // Tell Webpack to do the resolve
      return resolver.doResolve(
        'resolve',
        Object.assign({}, module, { request: modulePath }),
        `expanded ts module import ${module.request} to ${modulePath}`,
        callback // We pass callback to allow other resolver plugins a chance to resolve the module
      );
    }

    return callback();
  });
};

module.exports = SprintWebpackResolver;
