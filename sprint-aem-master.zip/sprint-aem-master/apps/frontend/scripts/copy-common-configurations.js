'use strict';

const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');
var json = require('comment-json');

function copyCommonConfigurationFiles() {
  return Promise.all([
    copyJsonConfig(
      path.resolve(config.paths.submodulesPath, 'frontend-config', 'config', 'common', '.eslintrc.json'),
      path.resolve(config.paths.submodulesPath, '.eslintrc.json')
    ),
    copyJsonConfig(
      path.resolve(config.paths.submodulesPath, 'frontend-config', 'config', 'common', '.stylelintrc'),
      path.resolve(config.paths.submodulesPath, '.stylelintrc')
    ),
    copyJsonConfig(
      path.resolve(config.paths.submodulesPath, 'frontend-config', 'config', 'common', 'tslint.json'),
      path.resolve(config.paths.submodulesPath, 'tslint.json')
    ),
    fs.copyAsync(
      path.resolve(config.paths.submodulesPath, 'frontend-config', 'config', 'common', 'browserslist'),
      path.resolve(config.paths.submodulesPath, 'browserslist')
    )
  ]);
}

function copyJsonConfig(input, output) {
  return fs.readFileAsync(input)
    .then(content => json.parse(content))
    .then(content => fs.writeJsonAsync(output, content));
}

module.exports = copyCommonConfigurationFiles;
