'use strict';

const child_process = require('child_process');
const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');

const compilerPath = path.resolve(
  config.paths.submodulesPath,
  'node_modules',
  '.bin'
);

function webpackBuild() {
  return fs.readJsonAsync(path.resolve(config.paths.submodulesPath, 'tsconfig.base.json'))
    .then(tsConfig => {
      config.submoduleList
        .filter(submodule => !submodule.supportSubmodule)
        .forEach(submodule => {
          // Add includes
          tsConfig.include = [].concat(
            tsConfig.include,
            `./${submodule.name}/dist/**/*`
          );

          // Add excludes
          tsConfig.exclude = [].concat(
            tsConfig.exclude,
            `./${submodule.name}/dist/test.ts`
          );
        });

      return tsConfig;
    })
    .then(tsConfig => fs.writeJsonAsync(path.resolve(config.paths.submodulesPath, 'tsconfig.webpack.json'), tsConfig))
    .then(() => new Promise((resolve, reject) => {
      const webpack = child_process.spawn(
        path.resolve(compilerPath, 'webpack'),
        [
          '--progress',
          '--profile',
          '--bail'
        ],
        {
          cwd: path.resolve(config.paths.submodulesPath),
          stdio: [
            process.stdin,
            process.stdout,
            process.stderr,
            'pipe',
            'pipe'
          ]
        },
        (error) => {
          if (error) {
            reject(error);
          }

          resolve();
        }
      );

      webpack.on('close', (code) => {
        if (code) {
          reject();
        }

        resolve();
      });
  }));
}

module.exports = webpackBuild;
