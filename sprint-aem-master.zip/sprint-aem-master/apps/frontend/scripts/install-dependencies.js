'use strict';

const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');
const child_process = require('child_process');

function cleanSubmodules() {
  const configSubmodule = config.submoduleList.find(submodule => submodule.name === 'frontend-config');

  // Read and compile dependencies from frontend-config package.json
  return fs.readJsonAsync(path.join(config.paths.submodulesPath, configSubmodule.name, 'package.json'))
    .then(configPackage =>
      Object.keys(configPackage.dependencies)
        .filter(dependency => config.packageJSONIgnoreList.indexOf(dependency) === -1)
        .reduce((dependencies, dependency) => {
          dependencies[dependency] = configPackage.dependencies[dependency];
          return dependencies;
        }, {})
    )
    .then(configDependencies => {
      configDependencies['webpack-closure-compiler'] = '2.1.2';
      return configDependencies;
    })
    .then(configDependencies =>
      // Read and compile dependencies from all other submodules package.json
      config.submoduleList
        .filter(submodule => submodule.name !== 'frontend-config')
        .reduce((chain, submodule) =>
          chain.then(() =>
            fs.readJsonAsync(path.join(config.paths.submodulesPath, submodule.name, 'package.json'))
              .then(submodulePackage => {
                if (!submodulePackage.dependencies) {
                  return;
                }

                Object.keys(submodulePackage.dependencies)
                  .filter(dependency => !config.packageJSONIgnoreList[dependency])
                  .forEach(dependency => {
                    if (!configDependencies[dependency]) {
                      configDependencies[dependency] = submodulePackage.dependencies[dependency];
                    }
                  });
              })
          ), Promise.resolve())
        .then(() => configDependencies)
    )
    .then(configDependencies =>
      fs.writeJsonAsync(path.join(config.paths.submodulesPath, 'package.json'), { dependencies: configDependencies })
    )
    .then(() => npmInstall(config.paths.submodulesPath));
}

/**
 * Run `npm install` in the given directory.
 */
function npmInstall(rootPath) {
  return new Promise((resolve, reject) => {
    const install = child_process.spawn(
      'npm',
      [
        'install'
      ],
      {
        cwd: rootPath,
        stdio: [
          process.stdin,
          process.stdout,
          process.stderr,
          'pipe',
          'pipe'
        ]
      }
    );

    install.on('close', (code) => {
      if (code) {
        reject();
      }

      resolve();
    });
  });
}

module.exports = cleanSubmodules;
