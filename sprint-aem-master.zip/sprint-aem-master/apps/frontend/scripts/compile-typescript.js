'use strict';

const child_process = require('child_process');
const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');

const compilerPath = path.resolve(
  config.paths.submodulesPath,
  'node_modules',
  '.bin'
);

function compileTypescript(submodule) {
  return fs.readJsonAsync(path.resolve(config.paths.submodulesPath, 'tsconfig.base.json'))
    .then(tsConfig => {
      // Add paths for resolution
      tsConfig.compilerOptions.paths = Object.assign(
        {},
        tsConfig.compilerOptions.paths,
        {
          'src/*': [ `./${submodule.name}/src/*` ]
        }
      );

      // Add includes
      tsConfig.include = [].concat(
        tsConfig.include,
        `./${submodule.name}/src/**/*`
      );

      // Add excludes
      tsConfig.exclude = [].concat(
        tsConfig.exclude,
        `./${submodule.name}/src/test.ts`
      );

      return tsConfig;
    })
    .then(tsConfig => fs.writeJsonAsync(path.resolve(config.paths.submodulesPath, `tsconfig.${submodule.name}.json`), tsConfig))
    .then(() => new Promise((resolve, reject) => {
      child_process.execFile(
        path.resolve(compilerPath, 'ngc'),
        [
          '-p',
          path.resolve(config.paths.submodulesPath, `tsconfig.${submodule.name}.json`)
        ],
        {
          cwd: config.paths.submodulesPath,
          stdio: [
            process.stdin,
            process.stdout,
            process.stderr,
            'pipe',
            'pipe'
          ]
        },
        (error) => {
          if (error) {
            reject(error);
          }

          resolve();
        }
      );
    }));
}

module.exports = compileTypescript;
