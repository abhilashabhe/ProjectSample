'use strict';

const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');

function symlinkSubmodules() {
  return Promise.all(
    config.submoduleList
      .map(submodule =>
        fs.ensureSymlinkAsync(
          path.join(config.paths.submodulesPath, submodule.name),
          path.join(config.paths.submodulesPath, 'node_modules', '@sprint', submodule.name)
        )
      )
  );
}

module.exports = symlinkSubmodules;
