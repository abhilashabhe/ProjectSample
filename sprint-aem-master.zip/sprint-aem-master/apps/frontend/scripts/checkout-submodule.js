'use strict';

const child_process = require('child_process');
const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');
const process = require('process');

function checkoutSubmodule(submodule) {
  return fs.removeAsync(path.join(config.paths.submodulesPath, submodule.name))
    .then(() => gitClone(config.paths.submodulesPath, submodule.url))
    .then(() => gitCheckout(path.join(config.paths.submodulesPath, submodule.name), submodule.branch));
}

/**
 * Clone a remote repository into a local directory.
 * @param {string} rootPath Directory path remote repository should be cloned into.
 * @param {string} url URL pointing to the remote repository.
 * @private
 */
function gitClone(rootPath, url) {
  return new Promise((resolve, reject) => {
    const clone = child_process.spawn(
      'git',
      [
        'clone',
        url
      ],
      {
        cwd: rootPath,
        stdio: [
          process.stdin,
          process.stdout,
          process.stderr,
          'pipe',
          'pipe'
        ]
      }
    );

    clone.on('close', (code) => {
      if (code) {
        reject();
      }

      resolve();
    });
  });
}

/**
 * Checkout a specific branch in the provided git repository.
 * @param {string} rootPath Path to the git repository.
 * @param {string} branch Branch to checkout in the repository.
 * @private
 */
function gitCheckout(rootPath, branch) {
  return new Promise((resolve, reject) => {
    const checkout = child_process.spawn(
      'git',
      [
        'checkout',
        branch,
        '--quiet'
      ],
      {
        cwd: rootPath,
        stdio: [
          process.stdin,
          process.stdout,
          process.stderr,
          'pipe',
          'pipe'
        ]
      }
    );

    checkout.on('close', (code) => {
      if (code) {
        reject();
      }

      resolve();
    });
  });
}

module.exports = checkoutSubmodule;
