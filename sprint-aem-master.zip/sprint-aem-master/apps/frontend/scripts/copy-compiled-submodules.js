'use strict';

const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');

const dynamicContentXML_startText = `<?xml version="1.0" encoding="UTF-8"?>
<jcr:root xmlns:cq="http://www.day.com/jcr/cq/1.0" xmlns:jcr="http://www.jcp.org/jcr/1.0"
  jcr:primaryType="cq:ClientLibraryFolder"
  categories="`;
const dynamicContentXML_endText = `"/>
`;
const dynamicContentXML_global = dynamicContentXML_startText + `sprint-transformation.global` + dynamicContentXML_endText;
const dynamicContentXML_care = dynamicContentXML_startText + `sprint-transformation.care` + dynamicContentXML_endText;
const dynamicContentXML_cart = dynamicContentXML_startText + `sprint-transformation.cart` + dynamicContentXML_endText;
const dynamicContentXML_checkout = dynamicContentXML_startText + `sprint-transformation.checkout` + dynamicContentXML_endText;

function copyCompiledSubmodules() {
  return Promise.all([
    copyGlobalSubmodule(),
    copyCareSubmodule(),
    copyCartSubmodule(),
    copyCheckoutSubmodule()
  ]);
}

function copyGlobalSubmodule() {
  return fs.ensureDirAsync(path.join(config.paths.aemInstallRootPath, 'global'))
    .then(() => fs.emptyDirSync(path.join(config.paths.aemInstallRootPath, 'global')))
    .then(() => fs.outputFileAsync(path.join(config.paths.aemInstallRootPath, 'global', '.content.xml'), dynamicContentXML_global))
    .then(() => fs.copyAsync(
      path.join(config.paths.submodulesPath, 'frontend-styles', 'dist', 'assets'),
      path.join(config.paths.aemInstallRootPath, 'global', 'assets')
    ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'frontend-styles.version.js'),
      path.join(config.paths.aemInstallRootPath, 'global', 'assets', 'styles', 'frontend-styles.version.css')
    ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'polyfills.js'),
      path.join(config.paths.aemInstallRootPath, 'global', 'js', 'polyfills.js')
    ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'vendors.js'),
      path.join(config.paths.aemInstallRootPath, 'global', 'js', 'vendors.js')
    ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'angular-vendors.js'),
      path.join(config.paths.aemInstallRootPath, 'global', 'js', 'angular-vendors.js')
    ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'shared-modules.js'),
      path.join(config.paths.aemInstallRootPath, 'global', 'js', 'shared-modules.js')
    ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'aem-components.js'),
      path.join(config.paths.aemInstallRootPath, 'global', 'js', 'aem-components.js')
    ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'frontend-components.version.js'),
      path.join(config.paths.aemInstallRootPath, 'global', 'js', 'frontend-components.version.js')
    ))
    .then(() => fs.outputFileAsync(
      path.join(config.paths.aemInstallRootPath, 'global', 'css.txt'),
      `#base=assets/styles
frontend-styles.version.css
global.css
../../../common/assets/styles/components.css
`))
    .then(() => fs.outputFileAsync(
      path.join(config.paths.aemInstallRootPath, 'global', 'js.txt'),
      `#base=js
frontend-components.version.js
polyfills.js
vendors.js
angular-vendors.js
shared-modules.js
aem-components.js
`));
}

function copyCareSubmodule() {
  return fs.ensureDirAsync(path.join(config.paths.aemInstallRootPath, 'care'))
    .then(() => fs.emptyDirAsync(path.join(config.paths.aemInstallRootPath, 'care')))
    .then(() => fs.outputFileAsync(path.join(config.paths.aemInstallRootPath, 'care', '.content.xml'), dynamicContentXML_care))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'frontend-care.js'),
      path.join(config.paths.aemInstallRootPath, 'care', 'js', 'frontend-care.js')
    ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'frontend-care.version.js'),
      path.join(config.paths.aemInstallRootPath, 'care', 'js', 'frontend-care.version.js')
    ))
    .then(() => fs.outputFileAsync(
      path.join(config.paths.aemInstallRootPath, 'care', 'js.txt'),
      `#base=js
frontend-care.version.js
frontend-care.js
`));
}

function copyCartSubmodule() {
  return fs.ensureDirAsync(path.join(config.paths.aemInstallRootPath, 'cart'))
    .then(() => fs.emptyDirAsync(path.join(config.paths.aemInstallRootPath, 'cart')))
.then(() => fs.outputFileAsync(path.join(config.paths.aemInstallRootPath, 'cart', '.content.xml'), dynamicContentXML_cart))
.then(() => fs.copyAsync(
    path.join(config.paths.distPath, 'frontend-cart.js'),
    path.join(config.paths.aemInstallRootPath, 'cart', 'js', 'frontend-cart.js')
  ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'frontend-cart.version.js'),
      path.join(config.paths.aemInstallRootPath, 'cart', 'js', 'frontend-cart.version.js')
    ))
    .then(() => fs.outputFileAsync(
      path.join(config.paths.aemInstallRootPath, 'cart', 'js.txt'),
      `#base=js
frontend-cart.version.js
frontend-cart.js
`));
}

function copyCheckoutSubmodule() {
  return fs.ensureDirAsync(path.join(config.paths.aemInstallRootPath, 'checkout'))
    .then(() => fs.emptyDirAsync(path.join(config.paths.aemInstallRootPath, 'checkout')))
.then(() => fs.outputFileAsync(path.join(config.paths.aemInstallRootPath, 'checkout', '.content.xml'), dynamicContentXML_checkout))
.then(() => fs.copyAsync(
    path.join(config.paths.distPath, 'frontend-checkout.js'),
    path.join(config.paths.aemInstallRootPath, 'checkout', 'js', 'frontend-checkout.js')
  ))
    .then(() => fs.copyAsync(
      path.join(config.paths.distPath, 'frontend-checkout.version.js'),
      path.join(config.paths.aemInstallRootPath, 'checkout', 'js', 'frontend-checkout.version.js')
    ))
    .then(() => fs.outputFileAsync(
      path.join(config.paths.aemInstallRootPath, 'checkout', 'js.txt'),
      `#base=js
frontend-checkout.version.js
frontend-checkout.js
`));
}

module.exports = copyCompiledSubmodules;
