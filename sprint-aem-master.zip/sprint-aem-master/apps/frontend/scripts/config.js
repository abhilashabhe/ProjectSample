'use strict';

const path = require('path');

/**
 * Submodule list in order of compilation priority.
 * Support submodules should be listed and compiled first.
 */
const submoduleList = [
  {
    /**
     * Support submodule containing all configuration values
     * used by all other submodule repositories.
     */
    name: 'frontend-config',
    url: 'git@github.com:SprintDigital/frontend-config.git',
    branch: 'DR17.37.3',
    supportSubmodule: true
  },
  {
    /**
     * Support submodule containing all styles used by all
     * other submodule repositories.
     */
    name: 'frontend-styles',
    url: 'git@github.com:SprintDigital/frontend-styles.git',
    branch: 'DR17.37.3',
    supportSubmodule: true
  },
  {
    /**
     * Hybrid submodule containing AEM components and shared
     * Angular components. This submodule must be compiled
     * before all Angular submodules.
     */
    name: 'frontend-components',
    url: 'git@github.com:SprintDigital/frontend-components.git',
    branch: 'DR17.37.3'
  },
  {
    /**
     * Angular submodule containing the MySprint Care app.
     */
    name: 'frontend-care',
    url: 'git@github.com:SprintDigital/frontend-care.git',
    branch: 'DR17.37.3'
  },
  {
    /**
     * Angular submodule containing the Cart app.
     */
    name: 'frontend-cart',
    url: 'git@github.com:SprintDigital/frontend-cart.git',
    branch: 'DR17.37.3'
  },
  {
    /**
     * Angular submodule containing the Checkout app.
     */
    name: 'frontend-checkout',
    url: 'git@github.com:SprintDigital/frontend-checkout.git',
    branch: 'DR17.37.3'
  }
];

// Ignore these packages when building the root package.json
const packageJSONIgnoreList = [
  'git-hooks', // We do not want to install our githooks into this repo
  // Ignore all the frontend-* repos
  '@sprint/frontend-config',
  '@sprint/frontend-components',
  '@sprint/frontend-cart',
  '@sprint/frontend-checkout',
  '@sprint/frontend-care',
  '@sprint/frontend-styles'
];

// Paths
const rootPath = path.resolve(__dirname, '..');
const submodulesPath = path.resolve(rootPath, 'submodules');
const distPath = path.resolve(submodulesPath, 'dist');
const aemInstallRootPath = path.resolve(
  rootPath,
  '..',
  'src',
  'main',
  'content',
  'jcr_root',
  'etc',
  'clientlibs',
  'sprint-transformation'
);

module.exports = {
  submoduleList,
  packageJSONIgnoreList,
  paths: {
    rootPath,
    submodulesPath,
    distPath,
    aemInstallRootPath
  }
};
