'use strict';

const autoprefixerSettings = require('../submodules/frontend-config/config/common/postcss.config');
const config = require('./config');
const findParentDir = require('find-parent-dir');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const klawSync = require('klaw-sync');
const path = require('path');
const postcss = require('postcss');
const sass = require('node-sass');

const prefixer = postcss(autoprefixerSettings.plugins);

function compileSass() {
  return Promise.all(
    config.submoduleList
      .filter(submodule => !submodule.supportSubmodule)
      .map(submodule => Promise.all(
        klawSync(path.join(config.paths.submodulesPath, submodule.name, 'src'), { nodir: true })
          .filter(file =>
            /.\.s[a|c]ss$/i.test(file.path)
          )
          .map(file => processFile(file.path))
      ))
  );
}

/**
 * Compile each sass file
 * @param filePath
 * @return {Promise}
 */
function processFile(filePath) {
  return fs.accessAsync(filePath, fs.constants.R_OK)
    .then(() => runNodeSass(filePath))
    .then(content => prefixer.process(content))
    .then(content => fs.writeFileAsync(
      path.join(
        path.dirname(filePath),
        path.basename(filePath, path.extname(filePath)) + '.css'
      ),
      content.css.toString()
    ))
    // .then(() => fs.removeAsync(filePath))
    .catch(err => {
      console.error('An error occurred: ', err);
    });
}

function runNodeSass(filePath) {
  const sassObj = sass.renderSync({
    file: filePath,
    includePaths: [
      path.join(config.paths.submodulesPath, 'node_modules', '@sprint', 'soar-styles-global', 'src', 'stylesheets'),
      path.join(config.paths.submodulesPath, 'node_modules', '@sprint', 'soar-styles-global')
    ],
    importer: (url, prev) => {
      const packageRoot = findParentDir.sync(prev, 'node_modules') || findParentDir.sync(config.paths.submodulesPath, 'node_modules');

      if (url[0] === '~') {
        url = path.resolve(packageRoot, 'node_modules', url.substr(1));

        if (!/.\.(css|scss|sass)$/.test(url)) {
          const packageMain = require(path.join(url, 'package.json')).main;

          if (/.\.(css|scss|sass)$/.test(packageMain)) {
            url = path.join(url, packageMain);
          }
        }
      }

      return {file: url};
    }
  });

  if (sassObj && sassObj['css']){
   return sassObj.css.toString('utf8');
  }

  return '';

}

module.exports = compileSass;
