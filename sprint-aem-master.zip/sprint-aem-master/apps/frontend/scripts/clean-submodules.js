'use strict';

const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const path = require('path');

function cleanSubmodules() {
  return fs.removeAsync(path.join(config.paths.submodulesPath, 'node_modules'))
    .then(() => fs.removeAsync(path.join(config.paths.submodulesPath, 'package.json')))
    .then(() => fs.removeAsync(path.join(config.paths.submodulesPath, 'package-lock.json')))
    .then(() => fs.removeAsync(path.join(config.paths.distPath)))
    .then(() => Promise.all(
      config.submoduleList.map(submodule =>
        fs.removeAsync(path.join(config.paths.submodulesPath, submodule.name))
      )
    ));
}

module.exports = cleanSubmodules;
