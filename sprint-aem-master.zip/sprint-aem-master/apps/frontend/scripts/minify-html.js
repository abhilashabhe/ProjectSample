'use strict';

const config = require('./config');
const fs = require('fs-extra-promise').useFs(require('fs-extra'));
const htmlMinifier = require('html-minifier');
const klawSync = require('klaw-sync');
const path = require('path');

const htmlMinifierOptions = {
  caseSensitive: true,
  collapseBooleanAttributes: false,
  collapseInlineTagWhitespace: false,
  collapseWhitespace: true,
  conservativeCollapse: true,
  customAttrAssign: [
    /\)?\]?=/
  ],
  customAttrSurround: [
    [/#/, /(?:)/],
    [/\*/, /(?:)/],
    [/\[?\(?/, /(?:)/]
  ],
  keepClosingSlash: true,
  removeAttributeQuotes: false,
  removeComments: true,
  removeEmptyAttributes: false,
  removeEmptyElements: false,
  removeOptionalTags: false,
  removeRedundantAttributes: false,
  removeScriptTypeAttributes: true,
  removeStyleLinkTypeAttributes: true,
  sortAttributes: true,
  sortClassName: false,
  useShortDoctype: true
};

function minifyHtml() {
  return Promise.all(
    config.submoduleList
      .filter(submodule => !submodule.supportSubmodule)
      .map(submodule => Promise.all(
        klawSync(path.join(config.paths.submodulesPath, submodule.name, 'src'), { nodir: true })
          .filter(file =>
            /.\.html$/i.test(file.path)
          )
          .map(file => processFile(file.path))

      ))
  );
}

/**
 * Minify each html file
 * @param filePath
 * @return {Promise}
 */
function processFile(filePath) {
  return fs.accessAsync(filePath, fs.constants.R_OK | fs.constants.W_OK)
    .then(() => fs.readFileAsync(filePath, 'utf-8'))
    .then(content => htmlMinifier.minify(content, htmlMinifierOptions))
    .then(content => fs.writeFileAsync(filePath, content))
    .catch(err => {
      console.error('An error occurred: ', err);
    });
}

module.exports = minifyHtml;
