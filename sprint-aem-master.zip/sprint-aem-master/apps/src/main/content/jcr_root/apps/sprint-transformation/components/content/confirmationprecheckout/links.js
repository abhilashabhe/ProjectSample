"use strict";
(function () {

  var links = [];
  var linksList = granite.resource.properties['links'];

  if (linksList) {
    if (linksList.length > 1) {
      for (var i = 0; i < linksList.length; i++) {
        links.push(JSON.parse(linksList[i]));
      }
    } else {
      links.push(JSON.parse(linksList));
    }
  }

  return {
    data: links
  };
})();
