/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2013 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
;
(function ($, ns, channel, window, undefined) {

    /**
     * A set of toolbar actions grouped by editable type.
     * This is useful for rendering different set of toolbar actions according to the type of the editable. This way the actions conditions are much clearer.
     * @type {Object}
     */


    // actions for the target parsys
    // editable.type = cq/personalization/components/targetparsys
    var targetParsysActions = {
        'TARGET_COMPONENT_OPTIONS': {
            icon: "coral-Icon--gear",
            text: Granite.I18n.getMessage("Target component settings"),
            handler: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                ns.edit.actions.doConfigure(targetEditable);
            },
            condition: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                return (typeof targetEditable !== 'undefined');
            }
        },
        'DELETE_OFFER': {
            icon: "coral-Icon--delete",
            text: Granite.I18n.getMessage("Delete offer"),
            handler: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                CQ.TargetedContentManager.deleteOffer(targetEditable);
            },
            condition: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                return (typeof targetEditable !== 'undefined'
                && !CQ.TargetedContentManager.isDefaultExperienceSelected()
                && CQ.TargetedContentManager.hasOffer(targetEditable));
            }
        },
        'ADD_OFFER': {
            icon: "coral-Icon--add",
            text: Granite.I18n.getMessage("Add offer"),
            handler: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                if (typeof targetEditable !== 'undefined') {
                    CQ.TargetedContentManager.createOffer(targetEditable);
                }
            },
            condition: function (editable) {
                if (CQ.TargetedContentManager.isSimulation()) {
                    // must have at least one activity selected
                    return false;
                }
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                return (typeof targetEditable !== 'undefined'
                && !CQ.TargetedContentManager.hasOffer(targetEditable));
            }
        },
        'SAVE_OFFER': {
            icon: "coral-Icon--upload",
            text: Granite.I18n.getMessage("Save offer to offer library"),
            handler: function (editable) {
                CQ.ui.TargetedContentManagerUi.doSaveToOfferLibrary(editable);
            },
            condition: function (editable) {
                // render condition:
                // - we have an experience selected (other than default)
                // - we have more than one children (parsys has at least one, which is the /new)
                if (CQ.TargetedContentManager.isSimulation()) {
                    return false;
                }
                return (!CQ.TargetedContentManager.isDefaultExperienceSelected()
                && editable.getChildren().length > 1);
            }
        }
    }

    // actions for the target component
    // editable.type = cq/personalization/components/target
    var targetComponentActions = {
        'DISABLE_TARGET': {
            icon: "coral-Icon--exclude",
            text: Granite.I18n.getMessage("Disable targeting"),
            handler: function (editable) {
                var targetParent = CQ.TargetedContentManager.getTargetParent(editable);
                if (typeof targetParent !== 'undefined') {
                    $.get(targetParent.path + "/default.json")
                        .done(function(data, jqXHR) {
                            CQ.TargetedContentManager.targetComponent(targetParent, true, data["sling:resourceType"]);
                        })
                        .fail(function(reason) {
                            CQ.TargetedContentManager.showOperationResult("Failed to disable targeting", true, reason.statusText);
                        });
                }
            },
            condition: function (editable) {
                if (CQ.TargetedContentManager.isInParsys(editable)) {
                    // no disabling if this editable is in a  targetparsys
                    return false;
                }
                var targetParent = CQ.TargetedContentManager.getTargetParent(editable);
                return (typeof targetParent !== 'undefined'
                || editable["type"] === CQ.TargetingConstants.TARGET_COMPONENT_RTYPE)
            }
        },
        'DELETE_OFFER': {
            icon: "coral-Icon--delete",
            text: Granite.I18n.getMessage("Delete offer"),
            handler: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                CQ.TargetedContentManager.deleteOffer(targetEditable);
            },
            condition: function (editable) {
                return (!CQ.TargetedContentManager.isDefaultExperienceSelected()
                && CQ.TargetedContentManager.hasOffer(editable));
            }
        },
        'ADD_OFFER': {
            icon: "coral-Icon--add",
            text: Granite.I18n.getMessage("Add offer"),
            handler: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                if (typeof targetEditable !== 'undefined') {
                    CQ.TargetedContentManager.createOffer(targetEditable);
                }
            },
            condition: function (editable) {
                return (CQ.TargetedContentManager.currentActivity !== null
                && !CQ.TargetedContentManager.hasOffer(editable));
            }
        },
        'CHOOSE_OFFER': {
            icon: "coral-Icon--folder",
            text: Granite.I18n.getMessage("Choose from offer library"),
            handler: function (editable) {
                CQ.OfferPicker.loadOfferPicker(CQ.TargetedContentManager.getCurrentBrand(),editable);
            },
            condition: function (editable) {
                return (CQ.TargetedContentManager.currentActivity !== null
                && !CQ.TargetedContentManager.hasOffer(editable));
            }
        },
        'TARGET_COMPONENT_OPTIONS': {
            icon: "coral-Icon--gear",
            text: Granite.I18n.getMessage("Target component settings"),
            handler: function (editable) {
                ns.edit.actions.doConfigure(editable);
            },
            condition: function (editable) {
                return true;
            }
        },
        'MAKE_INLINE_OFFER': {
            icon: "coral-Icon--linkOff",
            text: Granite.I18n.getMessage("Convert to inline offer"),
            handler: function (editable) {
                CQ.TargetedContentManager.convertInlineOffer(editable);
            },
            condition: function (editable) {
                return CQ.TargetedContentManager.hasLockedOffer(editable);
            }
        },
        'EDIT_IN_NEW_TAB': {
            icon:"coral-Icon--popOut",
            text: Granite.I18n.getMessage("Open in new tab for editing"),
            handler: function(editable){
                CQ.TargetedContentManager.editOfferNewTab(editable);
            },
            condition: function(editable) {
                return CQ.TargetedContentManager.hasLockedOffer(editable);
            }
        }
    };

    // actions for any editable, except for the two above
    var defaultEditableActions = {
        'TARGET': {
            icon: "coral-Icon--targeted",
            text: Granite.I18n.getMessage("Target"),
            handler: function (editable, param, target) {
                CQ.TargetedContentManager.targetComponent(editable, false);
            },
            condition: function (editable) {
                if (CQ.TargetedContentManager.isInParsys(editable)) {
                    // no disabling if this editable is in a  targetparsys
                    return false;
                }
                return ( !editable.config.editConfig["disableTargeting"]
                && CQ.TargetedContentManager.currentActivity !== null  // must have at least one activity selected
                && editable["type"] !== "foundation/components/parsys"
                && editable["type"] !== "foundation/components/parsys/new"
                && !CQ.TargetedContentManager.getTargetParent(editable));
            }
        },
        'DISABLE_TARGET': {
            icon: "coral-Icon--exclude",
            text: Granite.I18n.getMessage("Disable targeting"),
            handler: function (editable, param, target) {
                var targetParent = CQ.TargetedContentManager.getTargetParent(editable);
                if (typeof targetParent !== 'undefined') {
                    CQ.TargetedContentManager.targetComponent(targetParent, true);
                }
            },
            condition: function (editable) {
                if (CQ.TargetedContentManager.isInParsys(editable)) {
                    // no disabling if this editable is in a  targetparsys
                    return false;
                }
                var targetParent = CQ.TargetedContentManager.getTargetParent(editable);
                return (typeof targetParent !== 'undefined'
                || editable["type"] === CQ.TargetingConstants.TARGET_COMPONENT_RTYPE)
            }
        },
        'DELETE_OFFER': {
            icon: "coral-Icon--delete",
            text: Granite.I18n.getMessage("Delete offer"),
            handler: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                CQ.TargetedContentManager.deleteOffer(targetEditable);
            },
            condition: function (editable) {
                if (CQ.TargetedContentManager.isInParsys(editable)) {
                    // no disabling if this editable is in a  targetparsys
                    return false;
                }
               return typeof CQ.TargetedContentManager.getTargetParent(editable) != "undefined"
                        && !CQ.TargetedContentManager.hasLockedOffer(editable)
                        && !CQ.TargetedContentManager.isDefaultExperienceSelected();
            }
        },
        'SAVE_OFFER': {
            icon: "coral-Icon--upload",
            text: Granite.I18n.getMessage("Save offer to offer library"),
            handler: function (editable) {
                CQ.ui.TargetedContentManagerUi.doSaveToOfferLibrary(editable);
            },
            condition: function (editable) {
                if (CQ.TargetedContentManager.isInParsys(editable)) {
                    // no disabling if this editable is in a  targetparsys
                    return false;
                }
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                return (typeof targetEditable !== 'undefined'
                    && !CQ.TargetedContentManager.isDefaultExperienceSelected()
                    && CQ.TargetedContentManager.hasOffer(editable));
            }
        },

        'ADD_OFFER': {
            icon: "coral-Icon--add",
            text: Granite.I18n.getMessage("Add offer"),
            handler: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                if (typeof targetEditable !== 'undefined') {
                    CQ.TargetedContentManager.createOffer(targetEditable);
                }
            },
            condition: function (editable) {
                if (CQ.TargetedContentManager.isInParsys(editable)) {
                    // we don't want this option for components in the target parsys
                    return false;
                }
                if (CQ.TargetedContentManager.currentActivity === null) {
                    // must have at least one activity selected
                    return false;
                }
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                return (typeof targetEditable !== 'undefined'
                && !CQ.TargetedContentManager.hasOffer(targetEditable));
            }
        },
        'SELECT_PARENT': {
            icon: 'coral-Icon--selectContainer',
            text: Granite.I18n.getMessage('Parent'),
            handler: function (editable, param, target) {
                target.addClass('is-active');
                ns.edit.actions.doSelectParent(editable, target);
                // do not close toolbar
                return false;
            },
            condition: function (editable) {
                return CQ.TargetedContentManager.isInParsys(editable);
            }
        },
        'EDIT': {
            icon: 'coral-Icon--edit',
            text: Granite.I18n.get('Edit'),
            handler: function (editable, param, target) {
                ns.edit.actions.doInPlaceEdit(editable);
            },
            condition: function (editable) {
                var canModify = ns.page.info.permissions && ns.page.info.permissions.modify; // same as for Configure
                return canModify && ns.edit.actions.canInPlaceEdit(editable);
            },
            isNonMulti: true // means it could be executed when only one editable is selected
        },
        'CONFIGURE': {
            icon:'coral-Icon--wrench',
            text: Granite.I18n.get('Configure A'),
            handler: function (editable, param, target) {
                ns.edit.actions.doConfigure(editable);
            },
            condition: function (editable) {
                var canModify = ns.page.info.permissions && ns.page.info.permissions.modify;
                return !!editable.config.dialog && canModify
            },
            isNonMulti: true // means it could be executed when only one editable is selected
        },
     		'OPEN_EXPERIENCE_PAGE': {
            icon: "coral-Icon--forward",
            text: Granite.I18n.getMessage("Open experience Page"),
            handler: function (editable, param, target) {
                console.log(editable.path);
                var path=editable.path;
                var url=path.split("/jcr:content");
                var urlToOpen = Granite.HTTP.externalize("/editor.html"+url[0]+".html");
				window.open(urlToOpen,"_blank");

            },
            condition: function (editable) {
               return true;
            }    
        },
        DELETE: {
            icon: "coral-Icon--delete",
            text: Granite.I18n.getMessage("Delete"),
            handler: function (editable, param, target) {
                ns.selection.deselectAll();
                ns.edit.actions.doDelete([editable]);
            },
            condition: function (editable) {
                return (CQ.TargetedContentManager.isInParsys(editable)
                && editable["type"] !== "foundation/components/parsys"
                && editable["type"] !== "foundation/components/parsys/new");
            }

        },
        'TARGET_COMPONENT_OPTIONS': {
            icon: "coral-Icon--gear",
            text: Granite.I18n.getMessage("Target component settings"),
            handler: function (editable) {
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                ns.edit.actions.doConfigure(targetEditable);
            },
            condition: function (editable) {
                if (CQ.TargetedContentManager.isInParsys(editable)) {
                    return;
                }
                var targetEditable = CQ.TargetedContentManager.getTargetParent(editable);
                return (typeof targetEditable !== 'undefined');
            }
        }
    };

    ns.TargetingActions = {};

    ns.TargetingActions[CQ.TargetingConstants.TARGET_PARSYS_RTYPE] = targetParsysActions;
    ns.TargetingActions[CQ.TargetingConstants.TARGET_COMPONENT_RTYPE] = targetComponentActions;
    ns.TargetingActions["default"] = defaultEditableActions;


}(jQuery, Granite.author, jQuery(document), this));