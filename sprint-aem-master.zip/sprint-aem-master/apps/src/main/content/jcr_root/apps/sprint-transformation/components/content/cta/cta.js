"use strict";
use(['../../utils/utils.js'], function(utils) {
    var cta = {};

    var urlTarget = granite.resource.properties["urlTarget"];

    if (urlTarget) {
    	cta.urlTarget = utils.resolveURL(urlTarget);
    }

    var urlTargetSecondary = granite.resource.properties["urlTargetSecondary"];

    if (urlTargetSecondary) {
    	cta.urlTargetSecondary = utils.resolveURL(urlTargetSecondary);
    }

    return cta;
});