var logsdata;
var xmlHttp = new XMLHttpRequest();


var syncData ;
        var xmlHttpp = new XMLHttpRequest();
            xmlHttpp.open( "GET", '/bin/sync/BCCData/analytics.getData.syncHistory.json', false );
            xmlHttpp.send( null );
            syncData = JSON.parse(this.xmlHttpp.responseText);

