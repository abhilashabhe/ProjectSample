'use strict';
/*eslint-disable */
use(function () {
    var devicePaymentOptionsArray = [];
    var devicePaymentOptionsAdminPath = pageManager.getPage('/content/sprint/sprint_com/admin/en-us/device-payment-options');

    if (devicePaymentOptionsAdminPath) {
        var pageContentResource                 = devicePaymentOptionsAdminPath.getContentResource();
        var pageContentParsys                   = pageContentResource.listChildren()[0];
        var pageContent                         = pageContentParsys.listChildren();

        for (var i = 0; i < pageContent.length; i++) {
            var isRecommendedDevice = (pageContent[i].getResourceType().indexOf('paymentoption') > 0);

            if (isRecommendedDevice) {
                var deviceValueMap = pageContent[i].adaptTo(org.apache.sling.api.resource.ValueMap);

                devicePaymentOptionsArray.push(deviceValueMap);
            }
        }
    }

    return devicePaymentOptionsArray;
});
/*eslint-enable */