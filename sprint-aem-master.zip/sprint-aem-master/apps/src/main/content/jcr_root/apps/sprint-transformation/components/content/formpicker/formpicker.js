"use strict";
(function() {

  var dataItems = [];

  var items = granite.resource.properties['pickerListOptions'];

  if(items) {
    if (items.length > 1) {
      for(var i=0; i < items.length; i++){
        dataItems.push(JSON.parse(items[i]));
      }
    }
    else {
      dataItems.push( JSON.parse(items) );
    }
  }

  return {
    data: dataItems
  };
})();
