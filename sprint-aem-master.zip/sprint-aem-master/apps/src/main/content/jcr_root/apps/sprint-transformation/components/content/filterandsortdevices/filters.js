'use strict';
use(function () {
  var deepLinks = granite.resource.properties['deepLinks'];
  var filters = granite.resource.properties['filters'];
  var parsedDeepLinks = [];
  var parsedFilters = [];

  if(deepLinks) {
    if (deepLinks.length > 1) {
      for(var i=0; i < deepLinks.length; i++){
        var deepLink = JSON.parse(deepLinks[i]);
        if(deepLink.deeplinkValue){
          deepLink.deeplinkValue = deepLink.deeplinkValue.split('/').pop();
        }
        parsedDeepLinks.push(deepLink);
      }
    }
    else {
      var deepLink = JSON.parse(deepLinks);
      if(deepLink.deeplinkValue){
        deepLink.deeplinkValue = deepLink.deeplinkValue.split('/').pop();
      }
      parsedDeepLinks.push( JSON.parse(deepLink) );
    }
  }

  if(filters) {
    if (filters.length > 1) {
      for(var i=0; i < filters.length; i++){
        var filter = JSON.parse(filters[i]);
        if(filter.filterValue){
          filter.filterValue = filter.filterValue.split('/').pop();
        }
        parsedFilters.push(filter);
      }
    }
    else {
      var filter = JSON.parse(filters);
      if(filter.filterValue){
        filter.filterValue = filter.filterValue.split('/').pop();
      }
      parsedFilters.push( JSON.parse(filters) );
    }
  }

  return {
    deepLinks:parsedDeepLinks,
    filters: parsedFilters
  };
});
