'use strict';
(function() {
  var deviceSkus = granite.resource.properties['devices'];
  var deviceList = [];
  var deviceSkuidsList = [];

  if(deviceSkus) {
    if (deviceSkus.length > 1) {
      for (var i = 0; i < deviceSkus.length; i++) {
        var device = JSON.parse(deviceSkus[i]);
        deviceSkuidsList.push(device.skuid);
        deviceList.push(device);
      }
    }
    else {
      deviceSkuidsList.push(JSON.parse(deviceSkus).skuid);
      deviceList.push(JSON.parse(deviceSkus));
    }
  }

  return {
    deviceSkus: deviceSkus,
    deviceList: deviceList,
    deviceSkuidsList: deviceSkuidsList
  };
})();
