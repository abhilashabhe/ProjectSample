"use strict";
(function(utils) {
  var devices = granite.resource.properties["devices"];

  var deviceList = [];
  var deviceSkuidsList = [];
  var deviceCount = 0;

  if(devices) {
    deviceCount = devices.length;

    if (deviceCount > 1) {
      for (var i = 0; i < deviceCount; i++) {
        var device = JSON.parse(devices[i]);
        deviceSkuidsList.push(device.ensembleid);
        deviceList.push(device);
      }
    }
    else {
      deviceSkuidsList.push(JSON.parse(devices).ensembleid);
      deviceList.push(JSON.parse(devices));
    }
  }

  return {
    deviceList: deviceList,
    deviceSkuidsList: deviceSkuidsList,
    deviceCount: deviceCount
  };
})();
