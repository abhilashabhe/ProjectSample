
//manual Update
document.addEventListener("DOMContentLoaded", function(event) {
       $("#ManualImport").click(function(){
           var x = document.getElementById("skuid").value;
        var synchendpoint;
        if (x.startsWith("dvc") && x.endsWith("prd")) {
            synchendpoint = "/bin/sync/BCCData/APIDevices?id=" + x + "&manual=true";
			$.get(synchendpoint, function(data, status) {})
            alert("Request Submitted for " + x + ". Please check status after sometime.");
        } else if (x.startsWith("access") && x.endsWith("prd")) {
            synchendpoint = "/bin/sync/BCCData/APIAccessories?id=" + x + "&manual=true";
            $.get(synchendpoint, function(data, status) {})
            alert("Request Submitted for " + x + ". Please check status after sometime.");
        } else if (x.startsWith("pln") && x.endsWith("prd")) {
            synchendpoint = "/bin/sync/BCCData/APIPlans?id=" + x + "&manual=true";
            $.get(synchendpoint, function(data, status) {})
            alert("Request Submitted for " + x + ". Please check status after sometime.");
        } else if (x.startsWith("srvc") && x.endsWith("prd")) {
            synchendpoint = "/bin/sync/BCCData/APIServices?id=" + x + "&manual=true";
            $.get(synchendpoint, function(data, status) {})
            alert("Request Submitted for " + x + ". Please check status after sometime.");
        } else {
            alert("Enter valid Product ID");
        };
           document.getElementById('skuid').value = ""; 
    });

  });