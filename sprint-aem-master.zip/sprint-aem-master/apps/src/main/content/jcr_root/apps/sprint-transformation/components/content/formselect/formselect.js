"use strict";
(function() {

  var data;
  var i;

  var dataList = {
    optionsList: granite.resource.properties["itemsOptions"]
  };

  var itemSet = {
    optionsList:  []
  };

  if (dataList.optionsList) {

    if(dataList.optionsList.length > 1) {

      for (i = 0; i < dataList.optionsList.length; i++) {
        data = JSON.parse(dataList.optionsList[i]);
        itemSet.optionsList.push(data);
      }
    }
    else {

      itemSet.optionsList[0] = JSON.parse(dataList.optionsList);

    }
  }

  return itemSet;

})();
