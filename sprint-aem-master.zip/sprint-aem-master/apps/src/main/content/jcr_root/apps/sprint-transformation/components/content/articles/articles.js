'use strict';
use(function () {
    var article = {};

    var pageModified = pageProperties.get('cq:lastModified');
    var jsDate = new Date(pageModified.time);
    article.pageModified= jsDate.toDateString();

    return article;
});
