'use strict';
use(function () {
    var columncontrol = {};

    columncontrol.numberOfColumns = (Number(granite.resource.properties['numberofcolumns']) || 2);

    columncontrol.columnList = [];
    
    for (var i = 0; i < columncontrol.numberOfColumns; i++) {
    	var columnData = {};
    	columnData.name = 'column_' + i;
    	columncontrol.columnList.push(columnData);
    }

    return columncontrol;
});