//Get Dates 
document.addEventListener("DOMContentLoaded", function(event) {
var today = new Date().toISOString().split('T')[0];
    var d = new Date();
    d.setDate(d.getDate() - 29);
    var predate = d.toISOString().split('T')[0];
    document.getElementsByName("logdate")[0].setAttribute('max', today);
    document.getElementsByName("logdate")[0].setAttribute('min', predate);

     });
