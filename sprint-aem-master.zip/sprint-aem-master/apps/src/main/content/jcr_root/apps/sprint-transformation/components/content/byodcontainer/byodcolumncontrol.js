'use strict';
use(function () {
   var columncontrol = {};
   var eligibityText;
   var ineligibityText;
   granite.resource.properties[CONST.TITLETXT];

   columncontrol.numberOfColumns = 2;

   columncontrol.columnList = [];
   
   for (var i = 0; i < columncontrol.numberOfColumns; i++) {
       var columnData = {};
       columnData.name = 'column_' + i;
       if(i== 0){
           columnData.colval = "6";
       }else{
           columnData.colval = "18";
       }
       columncontrol.columnList.push(columnData);
   }

   return columncontrol;
});