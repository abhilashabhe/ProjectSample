'use strict';
use(function () {
  var messages = currentStyle.get('flowmessages');
  var parsedmessages = [];

  if(messages) {
    if (messages.length > 1) {
      for(var i=0; i < messages.length; i++){
        var message = JSON.parse(messages[i]);
        parsedmessages.push(message);
      }
    }
    else {
      parsedmessages.push( JSON.parse(messages) );
    }
  }

  return {
    messages: parsedmessages
  };
});
