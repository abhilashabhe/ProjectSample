"use strict";
(function() {

    var dataItems = [];

    var items = granite.resource.properties['formRows'];

    if(items) {
        if (items.length > 1) {
            for(var i=0; i < items.length; i++){
                dataItems.push(JSON.parse(items[i]));
            }
        }
        else {
            dataItems.push( JSON.parse(items) );
        }
    }

    for(var i=0; i<dataItems.length; i++){
      switch(dataItems[i].formBuilder){
        case 'single':
          dataItems[i].columns = [{
            parsys: i+'-singleparsys1',
            class: 'col-xs-24'
          }];
          break;
        case 'double':
          dataItems[i].columns = [{
            parsys: i+'-doubleparsys1',
            class: 'col-xs-24 col-sm-12'
          },
          {
            parsys: i+'-doubleparsys2',
            class: 'col-xs-24 col-sm-12'
          }];
          break;
        case 'triple':
          dataItems[i].columns = [{
            parsys: i+'-tripleparsys1',
            class: 'col-xs-24 col-sm-8'
          },
          {
            parsys: i+'-tripleparsys2',
            class: 'col-xs-24 col-sm-8'
          },
          {
            parsys: i+'-tripleparsys3',
            class: 'col-xs-24 col-sm-8'
          }];
          break;
        case 'double-20-4':
          dataItems[i].columns = [{
            parsys: i+'-longparsys1',
            class: 'col-xs-24 col-sm-20'
          },
          {
            parsys: i+'-longparsys2',
            class: 'col-xs-24 col-sm-4'
          }];
          break;
        case 'triple-5-5-14':
          dataItems[i].columns = [{
            parsys: i+'-smallparsys1',
            class: 'col-xs-24 col-sm-5'
          },
          {
            parsys: i+'-smallparsys2',
            class: 'col-xs-24 col-sm-5'
          },
          {
            parsys: i+'-smallparsys3',
            class: 'col-xs-24 col-sm-14'
          }];
          break;
      }
    }

    return {
        data: dataItems
    };
})();
