"use strict";
(function(utils) {
    var titleRes = granite.resource.properties["title"];
    var subtitleRes = granite.resource.properties["subtitle"];
    var heading = {title:'',subtitle:''};
    if (titleRes) {
        heading.title = titleRes;
    }
    if(subtitleRes){
        heading.subtitle = subtitleRes;
    }
    return heading;
})();