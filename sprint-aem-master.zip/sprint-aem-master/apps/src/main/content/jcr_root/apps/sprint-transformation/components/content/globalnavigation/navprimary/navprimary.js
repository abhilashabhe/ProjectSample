'use strict';
use(['../../../utils/utils.js'], function (utils) {
    var navigationContent                   = {};
    var navAdminParent                      = pageManager.getPage(currentStyle.get('globalnavadminpath'));

    if (!navAdminParent || !navAdminParent.isValid()) { return {} };

    var navAdminHomePath                    = navAdminParent.getProperties().get('redirectTarget');

    navigationContent.homePath              = utils.resolveURL(navAdminHomePath);

    navigationContent.primaryPagesList      = navAdminParent.listChildren();
    navigationContent.primaryPagesArray     = [];

    while (navigationContent.primaryPagesList.hasNext()) {
        var primaryPage = navigationContent.primaryPagesList.next();

        var primaryPageContent = {};

        primaryPageContent.page = primaryPage;
        primaryPageContent.subnavItems = [];

        var pageContentResource = primaryPage.getContentResource();
        var pageContentParsys = pageContentResource.listChildren()[0];
        var pageContent = pageContentParsys.listChildren();

        for (var i = 0; i < pageContent.length; i++) {
            var isMenuItem = (pageContent[i].getResourceType().indexOf('navsubmenu') > 0);
            var isRichTextItem = (pageContent[i].getResourceType().indexOf('text') > 0);

            if (isMenuItem) {
                var submenuItem = {};

                submenuItem.itemData = pageContent[i].adaptTo(org.apache.sling.api.resource.ValueMap);

                submenuItem.submenuurl = utils.resolveURL(submenuItem.itemData.get('submenuurl'));

                if (pageContent[i].listChildren()[0]) {
                    submenuItem.children = pageContent[i].listChildren()[0].listChildren();

                    submenuItem.childItems = [];

                    for (var s = 0; s < submenuItem.children.length; s++) {
                        var submenuChildItem = {};
                        submenuChildItem.itemData = submenuItem.children[s].adaptTo(org.apache.sling.api.resource.ValueMap);

                        submenuChildItem.submenuchildurl = utils.resolveURL(submenuChildItem.itemData.get('submenuchildurl'));

                        submenuItem.childItems.push(submenuChildItem);
                    }
                }

                primaryPageContent.subnavItems.push(submenuItem);
            } else if (isRichTextItem) {
                primaryPageContent.extraContent = pageContent[i].adaptTo(org.apache.sling.api.resource.ValueMap).get('text');
            }
        }

        navigationContent.primaryPagesArray.push(primaryPageContent);
    }

    return navigationContent;

});
