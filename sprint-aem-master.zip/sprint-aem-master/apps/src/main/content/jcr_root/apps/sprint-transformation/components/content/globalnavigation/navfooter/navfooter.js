'use strict';
use(['../../../utils/utils.js'], function (utils) {
    var navigationContent                   = {};
    var navAdminParent                      = pageManager.getPage(currentStyle.get('globalfooteradminpath'));

    if (!navAdminParent || !navAdminParent.isValid()) { return {} };

    navigationContent.subnavTopItems        = [];
    navigationContent.subnavBottomItems     = [];
    navigationContent.socialItems           = [];
    navigationContent.cta                   = {};

    var pageContentResource                 = navAdminParent.getContentResource();
    var pageContentParsys                   = pageContentResource.listChildren()[0];
    var pageContent                         = pageContentParsys.listChildren();

    for (var i = 0; i < pageContent.length; i++) {
        var isCTA = (pageContent[i].getResourceType().indexOf('containercomponent') > 0);
        var isTopMenuItem = (pageContent[i].getResourceType().indexOf('navsubmenu') > 0);
        var isBottomMenuItem = (pageContent[i].getResourceType().indexOf('navsubmenuchild') > 0);
        var isSocialItem = (pageContent[i].getResourceType().indexOf('navfootersocial') > 0);
        var isLegalItem = (pageContent[i].getResourceType().indexOf('text') > 0);

        if (isCTA) {
            var ctaContent = pageContent[i].getChildren()[0].getChildren();
            for (var c = 0; c < ctaContent.length; c++) {

                var isSubText = (ctaContent[c].getResourceType().indexOf('text') > 0);
                var isSubCTA = (ctaContent[c].getResourceType().indexOf('cta') > 0);

                if (isSubText) {
                    navigationContent.cta.header = ctaContent[c].adaptTo(org.apache.sling.api.resource.ValueMap).get('text');
                }

                if (isSubCTA) {
                    navigationContent.cta.text = ctaContent[c].adaptTo(org.apache.sling.api.resource.ValueMap).get('text');
                    navigationContent.cta.alignment = ctaContent[c].adaptTo(org.apache.sling.api.resource.ValueMap).get('alignment');
                    navigationContent.cta.target = ctaContent[c].adaptTo(org.apache.sling.api.resource.ValueMap).get('urlTarget');
                }

            }
        }

        if (isTopMenuItem && !isBottomMenuItem) {
            var subnavTopItem = {};

            subnavTopItem.itemData = pageContent[i].adaptTo(org.apache.sling.api.resource.ValueMap);

            subnavTopItem.submenuurl = utils.resolveURL(subnavTopItem.itemData.get('submenuurl'));

            navigationContent.subnavTopItems.push(subnavTopItem);
        }

        if (isBottomMenuItem) {
            var subnavBottomItem = {};

            subnavBottomItem.itemData = pageContent[i].adaptTo(org.apache.sling.api.resource.ValueMap);

            subnavBottomItem.submenuurl = utils.resolveURL(subnavBottomItem.itemData.get('submenuchildurl'));

            navigationContent.subnavBottomItems.push(subnavBottomItem);
        }

        if (isSocialItem) {
            var socialItem = {};

            socialItem.itemData = pageContent[i].adaptTo(org.apache.sling.api.resource.ValueMap);

            socialItem.submenuurl = utils.resolveURL(socialItem.itemData.get('socialicondestination'));

            navigationContent.socialItems.push(socialItem);
        }

        if (isLegalItem) {
            navigationContent.legal = pageContent[i].adaptTo(org.apache.sling.api.resource.ValueMap).get('text');
        }
    }

    return navigationContent;
});
