'use strict';
use(function () {
  var formelement = {};
  var patternObject = {
    defaultName: '[a-zA-Z][a-zA-Z-_\\.\\s]{1,38}$',
    email: '^[a-zA-z]+[a-zA-Z0-9._-]+@[a-zA-Z0-9]+\\.[a-zA-Z.]{2,5}$',
    phone: '^[\\(]?\\d{3}?[\\)]?[-.\\s]?\\d{3}[-.\\s]?\\d{4}$',
    address: '^[a-zA-Z0-9\\s,.\'\\-#]*$',
    state: '^([Aa](labama|laska|rizona|rkansas|[KkLlRrZz])|[Cc](alifornia|olorado|onnecticut|[AaOoTt])|[Dd](elaware|[Ee])|[Ff](lorida|[Ll])|[Gg](eorgia|[Aa])|[Hh](awaii|[Ii])|[Ii](daho|llinois|ndiana|owa|[AaDdLlNn])|[Kk](ansas|entucky|[SsYy])|[Ll](ouisiana|[Aa])|[Mm](aine|aryland|assachusetts|ichigan|innesota|ississippi|issouri|ontana|[AaDdEeIiNnOoSsTt])|[Nn](ebraska|evada|ew ([Hh]ampshire|[Jj]ersey|[Mm]exico|[Yy]ork)|[CcDdEeHhJjMmVvYy])|[Oo](hio|klahoma|regon|[HhKkRr])|[Pp](ennsylvania|[Aa])|[Rr](hode [Ii]sland|[Ii])|(?:[Nn]orth\\s+|[Ss]outh\\s+)?[Cc]arolina|[Dd]akota|[Ss]([CcDd])|[Tt](ennessee|exas|[NnXx])|[Uu](tah|[Tt])|[Vv](ermont|irginia|[AaTt])|[Ww](ashington|est [Vv]irginia|isconsin|yoming|[AaIiVvYy]))$',
    city: '^[a-zA-Z]+(?:[a-zA-Z\\s]+)*$',
    dob: '^((0?[13578]|10|12)(-|\\/)(([1-9])|(0[1-9])|([12])([0-9]?)|(3[01]?))(-|\\/)((19)([2-9])(\\d{1})|(20)([01])(\\d{1})|([8901])(\\d{1}))|(0?[2469]|11)(-|\\/)(([1-9])|(0[1-9])|([12])([0-9]?)|(3[0]?))(-|\\/)((19)([2-9])(\\d{1})|(20)([01])(\\d{1})|([8901])(\\d{1})))$',
    zipCode: '^\\d{5}$',
    ssn: '^(?!0000)\\d{4}$',
    taxId: '^\\d{9}$',
    defaultNumber: '^\\d{1,38}$'
  }
  formelement.patternSelect = '';
  formelement.maxLength = '';
  formelement.formSelector = (granite.resource.properties['formSelector']) || 'defaultName';

  var patternSelector = {
    'firstName': function () {
      formelement.patternSelect = patternObject.defaultName;
    },
    'lastName': function () {
      formelement.patternSelect = patternObject.defaultName;
    },
    'email': function () {
      formelement.patternSelect = patternObject.email;
    },
    'phone': function () {
      formelement.patternSelect = patternObject.phone;
      formelement.maxLength = 14;
    },
    'address1': function () {
      formelement.patternSelect = patternObject.address;
    },
    'state': function () {
      formelement.patternSelect = patternObject.state;
    },
    'address2': function () {
      formelement.patternSelect = patternObject.address;
      formelement.maxLength = 10;
    },
    'city': function () {
      formelement.patternSelect = patternObject.city;
    },
    'dob': function () {
      formelement.patternSelect = patternObject.dob;
    },
    'zip': function () {
      formelement.patternSelect = patternObject.zipCode;
      formelement.maxLength = 5;
    },
    'ssn': function () {
      formelement.patternSelect = patternObject.ssn;
      formelement.maxLength = 4;
    },
    'taxId': function () {
      formelement.patternSelect = patternObject.taxId;
      formelement.maxLength = 9;
    },
    'defaultName': function () {
      formelement.patternSelect = patternObject.defaultName;
    },
    'defaultNumber': function () {
      formelement.patternSelect = patternObject.defaultNumber;
    }
  };

  (patternSelector[formelement.formSelector])();

  return formelement;
});
