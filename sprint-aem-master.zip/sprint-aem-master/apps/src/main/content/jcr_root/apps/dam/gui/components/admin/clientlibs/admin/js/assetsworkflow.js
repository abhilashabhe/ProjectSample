/*
 * ADOBE CONFIDENTIAL
 *
 * Copyright 2012 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  All information contained herein is, and remains
 * the property of Adobe Systems Incorporated and its suppliers,
 * if any.  The intellectual and technical concepts contained
 * herein are proprietary to Adobe Systems Incorporated and its
 * suppliers and may be covered by U.S. and Foreign Patents,
 * patents in process, and are protected by trade secret or copyright law.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from Adobe Systems Incorporated.
 */
(function(window, document, Granite, $) {
    "use strict";
    
	var selectBar = "div[class='coral-Popover-content']";
    var selectBar_search_result = 'div[id="aem-assets-searchresult-publishpopovercontent"]';
    var ui = $(window).adaptTo("foundation-ui");
    var WORKFLOW_ASSETS_ACTIVATOR = ".cq-damadmin-admin-actions-workflow-activator";   
    var responseText='';
    var response='';
    var successMessage = 'Workflow Started for the selected assets';
	var errorMessage = 'Some problem occurred while starting the Asset workflow';
    var emptyAssetsListMessage = "Please select at least one asset to start the Asset workflow";
    var approverMissingMessage = "One or more of the assets selected does not have Final Approver/Project Name";
    var partialSuccessMessage = "Workflow Started for the selected assets. Workflow already running for one or more of the assets";
    var partialFailureMessage = "Workflow already running for the selected assets";

	function activateCallback(response,status){
        ui.clearWait();

        if (response === "success") {
             if($(".foundation-content").length > 0){
                var contentApi = $(".foundation-content").adaptTo("foundation-content");
                contentApi.refresh();
                ui.alert(Granite.I18n.get("Info"), successMessage, "info");
             }
        }else if(response === "error"){
				var contentApi = $(".foundation-content").adaptTo("foundation-content");
                contentApi.refresh();
                ui.alert(Granite.I18n.get("Info"), approverMissingMessage, "info");
        }else if(response === "partialSuccess"){
				var contentApi = $(".foundation-content").adaptTo("foundation-content");
                contentApi.refresh();
                ui.alert(Granite.I18n.get("Info"), partialSuccessMessage, "info");
        }else if(response === "partialFailure"){
				var contentApi = $(".foundation-content").adaptTo("foundation-content");
                contentApi.refresh();
                ui.alert(Granite.I18n.get("Info"), partialFailureMessage, "info");
        }else{
                var contentApi = $(".foundation-content").adaptTo("foundation-content");
                contentApi.refresh();
				ui.alert(Granite.I18n.get("Info"), errorMessage, "info");
        }

    }

	var startWorkflowForEachAsset = function(paths){

             $.ajax({
                    url: '/content/dam/sprint.assetapprovalworkflow',
                    type: 'GET',
                    "data": {
                            "_charset_": "utf-8",
                            "paths": paths
                            },
     		      success: function(responseText){                  
                  response = encodeURI(responseText);
                  activateCallback(response,'success');
            },
                 error : function(responseText){
                  response = encodeURI(responseText);
                  activateCallback(response,'error');
            }
       });
    };


    $(document).fipo("tap" + WORKFLOW_ASSETS_ACTIVATOR, "click" + WORKFLOW_ASSETS_ACTIVATOR, ".cq-damadmin-admin-actions-workflow-activator", function(e) {       


            $(selectBar).hide();
            $(selectBar_search_result).hide();
			var selectedItems = $(".foundation-collection").find(".foundation-selections-item.card-asset");
                var childPaths = [];
       		 if(selectedItems.length == 0){
 				ui.alert(Granite.I18n.get("Info"), emptyAssetsListMessage, "info");
             }else{
				ui.wait();
                for (var i = 0; i < selectedItems.length; i++) {
                    var $item = $(selectedItems[i]);
                    var path = $item.data("path");
                    childPaths.push(path);
                }
                ui.clearWait();
				startWorkflowForEachAsset(childPaths);
             }


            });

    
})(window, document, Granite, Granite.$);