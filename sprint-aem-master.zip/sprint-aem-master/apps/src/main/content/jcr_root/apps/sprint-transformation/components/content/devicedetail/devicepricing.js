'use strict';
use(['../../utils/utils.js'], function (utils) {

    var globalSharedLinks = utils.getGlobalSharedLinks();

    return globalSharedLinks;
});