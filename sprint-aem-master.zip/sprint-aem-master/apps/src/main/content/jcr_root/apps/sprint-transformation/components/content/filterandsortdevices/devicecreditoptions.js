'use strict';
use(function () {
    var deviceCreditOptionsArray = [];
    var deviceCreditOptionsAdminPath = pageManager.getPage('/content/sprint/sprint_com/admin/en-us/device-credit-options');

    if (deviceCreditOptionsAdminPath) {
        var pageContentResource                 = deviceCreditOptionsAdminPath.getContentResource();
        var pageContentParsys                   = pageContentResource.listChildren()[0];
        var pageContent                         = pageContentParsys.listChildren();

        for (var i = 0; i < pageContent.length; i++) {
            var isRecommendedDevice = (pageContent[i].getResourceType().indexOf('creditoption') > 0);

            if (isRecommendedDevice) {
                var deviceValueMap = pageContent[i].adaptTo(org.apache.sling.api.resource.ValueMap);

                deviceCreditOptionsArray.push(deviceValueMap);
            }
        }
    }

    return deviceCreditOptionsArray;
});