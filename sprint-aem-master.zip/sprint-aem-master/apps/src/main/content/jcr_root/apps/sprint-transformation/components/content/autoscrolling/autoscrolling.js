'use strict';
(function(utils) {
  var titleList = granite.resource.properties['titleList'];

  var messageSet = {};

  messageSet.titleList = [];
  if (titleList) {
    if(titleList.length > 1)
    {
      for (var i = 0; i < titleList.length; i++) {
        var data = JSON.parse(titleList[i]);
        messageSet.titleList.push(data);
      }
    }
    else{
      messageSet.titleList[0] = JSON.parse(titleList);
    }
  }

  return messageSet;
})();