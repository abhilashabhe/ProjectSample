# Frontend Components

This repository is meant to be used as a shared collection of Angular 2 TypeScript classes that can be used in two or more Sprint.com front end Angular 2 applications. This repository does not produce and distributable files. Sprint.com front end Angular 2 applications will use NPM to pull this repository into their project as a dependency and import statements will be used to make use of individual classes.

## Quick start
**Make sure you have Node version >= 4.0 and NPM >= 3**

```bash
# clone this repo
git clone git@github.com:SprintDigital/frontend-styles.git

cd frontend-components

# install the repo with npm
npm install

# if you're in China use cnpm
# https://github.com/cnpm/cnpm
```

## File Structure
We use the component approach in our starter. This is the new standard for developing Angular apps and a great way to ensure maintainable code by encapsulation of our behavior logic. A component is basically a self contained app usually in a single file or a folder with each concern as a file: style, template, specs, e2e, and component class. This repository also groups source code based on what type of class they are.

> **This is subject to change but essentially follows **
```
frontend-components/
 |- src/
 |   |- components/
 |   |   |- example-components/
 |   |   |   |- example.component.spec.ts
 |   |   |   |- example.component.ts
 |   |   |   |- example.component.html
 |   |   |   |- example.component.scss
 |   |
 |   |
 |   |- pipes/
 |   |   |- example-pipe/
 |   |   |   |- example.pipe.spec.ts
 |   |   |   |- example.pipe.ts
 |   |
 |   |
 |   |- providers/
 |   |   |- example-provider/
 |   |   |   |- example.provider.spec.ts
 |   |   |   |- example.provider.ts
 |   |   |   |- example.model.ts
 |   |
 |   |
 |   |- directives/
 |   |   |- example-directive/
 |   |   |   |- example.directive.spec.ts
 |   |   |   |- example.directive.ts
 |   |   |   |- example.directive.html
 |   |   |   |- example.directive.scss
```

## Installing
* `clone` this repo
* `npm install` to install all dependencies
* `npm test` to run a sanity check

# Configuration
Source configuration files live in the [frontend-config](https://github.com/SprintDigital/frontend-config) repo we are currently using webpack and karma for different stages of your application. These configuration files are all gitignored to ensure that every repository shares the same configuration. 

# License
 [(c) Copyright 2016 Sprint, all rights reserved.](/LICENSE)
