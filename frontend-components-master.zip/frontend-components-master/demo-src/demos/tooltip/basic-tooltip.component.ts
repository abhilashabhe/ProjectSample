import { Component } from '@angular/core';

@Component({
  template: `
    <div class="container-xl">
      <div class="row">
        <div class="col-sm-8">
          <sprint-tooltip>Tooltip #1</sprint-tooltip>
        </div>
        <div class="col-sm-8 middle-sm">
          <sprint-tooltip>Tooltip #2</sprint-tooltip>
        </div>
        <div class="col-sm-8 end-sm">
          <sprint-tooltip>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta ipsam quidem id fugit, velit dolores hic beatae quae quis. Voluptatum voluptas iure in debitis maxime porro odio id, delectus, alias?</sprint-tooltip>
        </div>
      </div>
    </div>
  `
})
export class BasicTooltipDemoComponent {
  static demoName = 'Basic Tooltip';
  static demoTopic = 'Tooltip';
  static demoDescription = 'Angular tooltip component.';
}
