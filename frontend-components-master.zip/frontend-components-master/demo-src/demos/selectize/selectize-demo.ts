import { Component, OnInit, AfterViewInit, ViewChild} from '@angular/core';
import { SprintSelectizeDirective, ISelectize, ISelectizeOptions } from '../../../src/sprint-angular-modules';
import { ISelectizeEvent } from '../../../src/sprint-angular-modules/directives/selectize/selectize.interface';

@Component({
  template: `
    <div class="sprint-select">
      <select class="sprint-select__element"
        placeholder="Select one...{{testLabel}}"
        [sprintSelectize]="selectizeOptions"
        (selectizeOnInitialize)="eventHandler($event)"
        (selectizeOnChange)="eventHandler($event)"
        (selectizeOnFocus)="eventHandler($event)"
        (selectizeOnBlur)="eventHandler($event)"
        (selectizeOnItemAdd)="eventHandler($event)"
        (selectizeOnItemRemove)="eventHandler($event)"
        (selectizeOnClear)="eventHandler($event)"
        (selectizeOnOptionAdd)="eventHandler($event)"
        (selectizeOnOptionRemove)="eventHandler($event)"
        (selectizeOnOptionClear)="eventHandler($event)"
        (selectizeOnOptionGroupAdd)="eventHandler($event)"
        (selectizeOnOptionGroupRemove)="eventHandler($event)"
        (selectizeOnOptionGroupClear)="eventHandler($event)"
        (selectizeOnDropdownOpen)="eventHandler($event)"
        (selectizeOnDropdownClose)="eventHandler($event)"
        (selectizeOnType)="eventHandler($event)"
        (selectizeOnLoad)="eventHandler($event)"
        (selectizeOnDestroy)="eventHandler($event)">
        <option value="" selected></option>
        <option value="1">One</option>
        <option value="2">Two</option>
        <option value="3">Three</option>
      </select>
      <button type="button" class="button button--link" (click)="toggleSelectDisable()">Toggle Select Disable</button>
    </div>
    <!-- Debugging info below -->
    <ul>
      <li *ngFor="let e of events">
        {{ e.type }}
      </li>
    </ul>
  `
})
export class SelectizeDemoComponent implements OnInit, AfterViewInit {
  static demoName = 'Selectize';
  static demoTopic = 'Forms';
  static demoDescription = 'Selectize drop down example';

  private disabled: boolean = false;
  @ViewChild(SprintSelectizeDirective)
  private sprintSelectize: ISelectize;

  public selectizeOptions: ISelectizeOptions;
  public events: ISelectizeEvent[] = [];
  public testLabel = 'test';

  ngOnInit() {
    // Set your selectize options here
    // You can just use the markup to set your options up
    this.selectizeOptions = {
      addSelectLabel: true
    };
  }

  ngAfterViewInit() {
    // We now have a reference to the selectize instance thanks to viewchild
    // We can do things here if we want
  }

  eventHandler($event: ISelectizeEvent) {
    this.events.push($event);
  }

  toggleSelectDisable() {
    if (this.sprintSelectize) {
      this.disabled = !this.disabled;
      if (this.disabled) {
        this.sprintSelectize.disable();
      } else {
        this.sprintSelectize.enable();
      }
    }
  }

  exampleScript = `
    class DemoComponent implements OnInit, AfterViewInit {
      private disabled: boolean = false;
      @ViewChild(SprintSelectizeDirective) sprintSelectize: ISelectize;
      selectizeOptions: ISelectizeOptions;
      events = [];
      testLabel: string = 'test';

      ngOnInit() {
        // Set your selectize options here
        // You can just use the markup to set your options up
        this.selectizeOptions = {
          addSelectLabel: true
        };
      }

      ngAfterViewInit() {
        // We now have a reference to the selectize instance thanks to viewchild
        // We can do things here if we want
      }

      eventHandler($event) {
        this.events.push($event);
      }

      toggleSelectDisable() {
        if (this.sprintSelectize) {
          this.disabled = !this.disabled;
          if (this.disabled) {
            this.sprintSelectize.disable();
          } else {
            this.sprintSelectize.enable();
          }
        }
      }
    }
  `;
}
