import { Component, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { SprintFormValidators } from '../../../src/sprint-angular-modules';

@Component({
  templateUrl: './form-masks.demo.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FormMaskDemoComponent {
  static demoName = 'Form Masks';
  static demoTopic = 'Forms';
  static demoDescription = 'Demo of the form masks';

  maskForm: FormGroup;

  constructor(
    private fb: FormBuilder,
    private formValidators: SprintFormValidators
  ) {
    const ssnValidator = Validators.compose([Validators.required, this.formValidators.ssnValidator]);
    this.maskForm = this.fb.group({
      ssn: [null, ssnValidator],
      ssnPrefilled: ['987654321', ssnValidator],
      phoneNumber: [null, Validators.required],
      phoneNumberPrefilled: ['8168052288', Validators.required],
      cardNumber: [null, Validators.required],
      cardNumberPrefilled: ['4123456789012345', Validators.required],
      expirationDate: [null, Validators.required],
      expirationDatePrefilled: ['Fri, 01 Feb 2019 00:00:00 GMT', Validators.required],
      dob: [null, [Validators.required, this.formValidators.dobValidator]],
      dobPrefilled: ['Fri, 22 Feb 1991 06:00:00 GMT', [Validators.required, this.formValidators.dobValidator]]
    });
  }
}
