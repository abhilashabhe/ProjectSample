import { Observable } from 'rxjs/Observable';
import { Component, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { IOrderCreditCard } from '../../../src/aem-components/interfaces/service-layer/schemas';
import { SprintFormUtils } from '../../../src/sprint-angular-modules';

@Component({
  templateUrl: './generic-forms.demo.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class GenericFormDemoComponent {
  static demoName = 'Generic Forms';
  static demoTopic = 'Forms';
  static demoDescription = 'Demo of the generic forms';

  public demoForm: FormGroup;
  public demoFormValue$: Observable<IOrderCreditCard>;
  public demoFormModel$: Observable<any>;
  public demoFormStatus$: Observable<string>;

  public formsDestroyed = false;
  public addressFormDisabled = true;
  public includeZipCode = false;
  public nestedFormDestroyed = false;

  constructor(
    private fb: FormBuilder,
    private changeDetector: ChangeDetectorRef,
    private formUtils: SprintFormUtils
  ) {
    console.log('constructing form demo');
    window['demo'] = this;


    this.demoForm = this.fb.group({
      nestedName: this.fb.group({
        age: null
      }),
      address: this.fb.group({}),
      urbanizationDisabled: this.fb.group({}),
      disabledAddress: this.fb.group({}),
      nameOnCard: [null, Validators.required],
      creditCardFormPrefilled: this.fb.group({}),
      creditCardForm: this.fb.group({}),
      shortCreditCardFormPrefilled: this.fb.group({}),
      shortCreditCardForm: this.fb.group({})
    });


    this.demoFormStatus$ = this.demoForm.statusChanges.startWith(this.demoForm.status);
    this.demoFormValue$ = this.demoForm.valueChanges.startWith(this.demoForm.value);
    this.demoFormModel$
      = Observable.of({
          cardNumber: '4111234567891234',
          nameOnCard: 'Test Test',
          securityCode: 123,
          ignored: `Filter test`,
          lastName: 'Eden',
          email: 'test@test.com',
          phone: null,
          // zipCode: 64105,
          // zip: 64105,
          expirationDate: 'Fri, 01 Feb 2019 00:00:00 GMT',
          // state: 'MO',
          nestedNameModel: {
            firstName: 'Alex'
          }
        });
  }

  showRemainingErrors() {
    this.formUtils.formControlsAsList(this.demoForm)
      .map(control => {
        control.markAsDirty();
        control.markAsTouched();
        control.updateValueAndValidity({ onlySelf: true });
      });

    this.changeDetector.detectChanges();
  }

  toggleAddressFormDisabled() {
    this.addressFormDisabled = !this.addressFormDisabled;
  }
  toggleCreditCardFormDestroyed() {
    this.formsDestroyed = !this.formsDestroyed;
  }
  toggleNestedFormDestroyed() {
    this.nestedFormDestroyed = !this.nestedFormDestroyed;
  }
  toggleIncludeZipCode() {
    this.includeZipCode = !this.includeZipCode;
  }
}
