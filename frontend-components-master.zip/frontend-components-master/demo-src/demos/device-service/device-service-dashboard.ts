import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import * as Schemas from '../../../src/aem-components/interfaces/service-layer/schemas';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import {
  IDeviceService, IDeviceServiceFactory,
  DeviceInfo, DeviceContractInfo, DeviceCreditInfo
} from '../../../src/aem-components/interfaces/device-service/index';
import { IServiceLayerFactory } from '../../../src/aem-components/interfaces/service-layer/index';

declare var sprintApp: ISprintApp;

@Component({
  templateUrl: './device-service-dashboard.html'
})
export class DeviceServiceDashboardComponent implements OnInit {
  static demoName = 'Device Service Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Device Service demo page.';

  private deviceService: IDeviceService;

  ngOnInit() {
    /**
     * TODO: Need to call sprintApp.getComponentFactory to get a reference to the service layer component
     */
    sprintApp.getComponentFactory('DeviceService').then((deviceServiceFactory: IDeviceServiceFactory) => {
      this.deviceService = deviceServiceFactory();

      this.deviceService.deviceInfo$.subscribe( (info: DeviceInfo) => {
        console.log('DEVICE INFO: ', info);

        this.deviceService.getDevicePricing()
          .subscribe(
            (prices: Schemas.DevicePrices) => {
              console.log('DEVICE PRICES: ', prices);

              // const purchaseType = prices.purchaseTypes.pop();
              // this.deviceService.setDeviceContract(purchaseType);
              this.deviceService.getDevicePlans()
                .subscribe(
                  (plans: Schemas.Plan[]) => {
                    console.log('PLANS: ', plans);

                    const plan = plans.pop();
                    this.deviceService.setDevicePlan(plan);

                    this.deviceService.getDeviceServices('GROSS_ADD', 'Insurance', 'LEASE')
                      .subscribe((services: Schemas.Service[]) => {
                        console.log('SERVICES: ', services);

                        // const service = services.pop();
                        // this.deviceService.setDeviceServices([service]);
                      });
                  },
                  (err: any) => console.warn(err)
                );
            },
            (err: any) => console.warn(err)
          );
        });

      this.deviceService.deviceContract$.subscribe( (contract: DeviceContractInfo) => {
        console.log('DEVICE CONTRACT: ', contract)
      });

      this.deviceService.devicePlan$.subscribe( (plan: Schemas.BaseRequestPlan) => {
        console.log('DEVICE PLAN: ', plan);
      });

      this.deviceService.services$.subscribe( (services: Schemas.BaseRequestService[]) => {
        console.log('DEVICE SERVICES: ', services)
      });

      this.deviceService.deviceCredit$.subscribe( (credit: DeviceCreditInfo) => {
        console.log('DEVICE CREDIT: ', credit);
      })

      this.deviceService.setDeviceInfo({
        color: 'Silver',
        storage: '32',
        ensembleId: '190198157430'
      });

      this.deviceService.setDeviceCreditInfo({
        value: 'A',
        display: 'Good Credit'
      });

      this.deviceService.setDeviceContract({
        contractInfo: {
          contractId: '0-yr-lb-18months'
        },
        deviceSaleType: 'EASYPAY'
      });

      this.deviceService.getAccountPlans().subscribe(plans => console.log(plans));
    });

    const serviceLayer$ = Observable.fromPromise(sprintApp.getComponentFactory('SprintStreams'))
      .map((serviceLayerFactory: IServiceLayerFactory) => serviceLayerFactory());

    serviceLayer$.mergeMap(serviceLayer => serviceLayer.getStreamRunnerWithCache('lookupDevices')({
      queryParams: {
        defaultSKUPrice: 'NO_PRICING',
        deviceType: 'PHONES',
        flow: 'GROSS_ADD'
      }
    }))
      .map(res => res.data)
      .subscribe(data => {
        console.log('lookupDevices', data);
      });

    serviceLayer$.mergeMap(serviceLayer => serviceLayer.getStreamRunnerWithCache('lookupDevicesByItemId')({
      pathParams: {
        itemId: '190198072214'
      },
      queryParams: {
        defaultSKUPrice: 'ALL_PRICING',
        deviceType: 'PHONES',
        flow: 'GROSS_ADD'
      }
    }))
      .map(res => res.data)
      .subscribe(data => {
        console.log('lookupDevicesByItemId', data);
      });

    serviceLayer$.mergeMap(serviceLayer => serviceLayer.getStreamRunnerWithCache('getFlowEligibility')({
      queryParams: {
        type: 'GROSSADD'
      }
    }))
      .map(res => res.data)
      .subscribe(data => {
        console.log('getFlowEligibility', data);
      });
  }
}
