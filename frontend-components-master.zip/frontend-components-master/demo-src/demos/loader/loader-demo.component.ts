import { Component } from '@angular/core';
import { GlobalLoaderComponent } from '../../../src/sprint-angular-modules';

@Component({
    template: `<sprint-global-loader></sprint-global-loader>`,
    entryComponents: [ GlobalLoaderComponent ]
})
export class LoaderDemoComponent {
  static demoName = 'Global Loader';
  static demoTopic = 'General';
  static demoDescription = 'a line of waving dots';
}
