import { Component} from '@angular/core';

@Component({
  template: `<div id="foobar" class="sprint-bing-map" sprintBingMap></div>`,
  styles: [`
    .sprint-bing-map {
      width: 100%;
      min-height: 500px;
    }
  `]
})
export class BingMapDemoComponent {
  static demoName = 'Basic BingMap';
  static demoDescription = 'Basic bing map example.';
  static demoTopic = 'Bing Maps';
}
