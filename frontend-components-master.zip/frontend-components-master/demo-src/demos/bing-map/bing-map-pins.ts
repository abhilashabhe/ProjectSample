import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { ConnectableObservable } from 'rxjs/observable/ConnectableObservable';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import { AddressAutocompleteSuggestion, BING_MAPS_SERVICE, SprintPushpinIcon } from '../../../src/aem-components/bing-maps';
import * as BingTypes from '../../../src/aem-components/bing-maps';

declare const sprintApp: ISprintApp;

type PushpinUpdate = (pins: BingTypes.Pushpin[], bingMapsService: BingTypes.BingMapsService) => BingTypes.Pushpin[];

@Component({
  templateUrl: './bing-map-pins.html',
  styleUrls: ['bing-map-pins.scss']
})
export class BingMapPinsDemoComponent implements OnInit {
  static demoName = 'Bing Maps Mini-App';
  static demoDescription = 'Full-featured bing map example.';
  static demoTopic = 'Bing Maps';

  sprintBingMapOptions: BingTypes.MapOptions | BingTypes.ViewOptions;
  private pushpinUpdates$ = new ReplaySubject<PushpinUpdate>();
  mapCenter$ = new ReplaySubject<BingTypes.Location>(1);
  pushpins$: ConnectableObservable<BingTypes.Pushpin[]>;
  addressSearchControl: FormControl;
  center: BingTypes.Location;
  hoveredPin: BingTypes.Pushpin;
  selectedPin: BingTypes.Pushpin;
  showMap = true;
  mapCenter: BingTypes.Coordinates = BingTypes.defaultLocation;
  mapOptionsForm: FormGroup;
  mapOptions$: Observable<BingTypes.MapOptions>;
  viewOptionsForm: FormGroup;
  viewOptions$: Observable<BingTypes.ViewOptions>;


  constructor() {
    this.mapOptionsForm = new FormGroup({
      showZoomButtons: new FormControl(true),
      disablePanning: new FormControl(false),
      disableScrollWheelZoom: new FormControl(false),
      disableZooming: new FormControl(false)
    });

    this.mapOptions$ = this.mapOptionsForm.valueChanges.startWith(this.mapOptionsForm.value);

    this.viewOptionsForm = new FormGroup({
      zoom: new FormControl(10)
    });

    this.viewOptions$ = this.viewOptionsForm.valueChanges.startWith(this.viewOptionsForm.value);

    this.addressSearchControl = new FormControl();
    this.sprintBingMapOptions = {};
    this.pushpins$
      = this.bingMapsService$.mergeMap(bingService =>
          this.pushpinUpdates$.scan(
            (pushpins, update) => update(pushpins, bingService),
            [] as BingTypes.Pushpin[]
          )
        )
        .publishReplay(1);
  }

  ngOnInit() {
    const pins: BingTypes.PushpinMetadata[] = [
      {
        location: {
          latitude: 38.9170822,
          longitude: -94.6587262
        },
        options: {
          subTitle: 'Store A',
          icon: SprintPushpinIcon.of({ text: '1' }).toString()
        }
      },
      {
        id: 'storeB',
        location: {
          latitude: 38.9124491,
          longitude: -94.6412194
        },
        options: {
          subTitle: 'Store B',
          icon: SprintPushpinIcon.of({ text: '2' }).toString()
        }
      },
      {
        id: 'storeC',
        location: {
          latitude: 38.9124074,
          longitude: -94.6610248
        },
        options: {
          subTitle: 'Store C',
          icon: SprintPushpinIcon.of({ text: '3' }).toString()
        }
      }
    ];


    this.pushpinUpdates$.next((pushpins, bingService) => {
      return pins.map(pin => bingService.createPushpin(pin));
    });

    this.pushpins$.connect();
  }

  suggestionSelected(autocomplete: AddressAutocompleteSuggestion) {
    this.pushpinUpdates$.next((pins, bingService) => {
      const pin = bingService.createPushpin({
        id: autocomplete.suggestion.entityId,
        location: autocomplete.location,
        options: {
          subTitle: autocomplete.formatted
        }
      });
      this.selectedPin = pin;
      return [ pin, ...pins ];
    });
  }

  get hoveredPinId(): string|null {
    return !!this.hoveredPin ? this.hoveredPin.metadata.id : null;
  }

  get selectedPinId(): string|null {
    return !!this.selectedPin ? this.selectedPin.metadata.id : null;
  }

  isPinHovered(pin: BingTypes.Pushpin) {
    return this.hoveredPinId === (pin.metadata && pin.metadata.id);
  }

  isPinSelected(pin: BingTypes.Pushpin) {
    return this.selectedPinId === (pin.metadata && pin.metadata.id);
  }

  selectPin(pin: BingTypes.Pushpin) {
    if (this.selectedPinId === pin.metadata.id) {
      return;
    }
    if (this.selectedPin) {
      this.selectedPin.setOptions({
        icon: SprintPushpinIcon.fromPin(this.selectedPin).yellow().toString()
      });
    }
    pin.setOptions({
      icon: SprintPushpinIcon.fromPin(pin).green().toString()
    });
    this.selectedPin = pin;

  }

  pinClick(pin: BingTypes.Pushpin) {
    this.selectPin(pin);
  }

  pinMouseOver(pin: BingTypes.Pushpin) {
    if (!this.isPinSelected(pin)) {
      pin.setOptions({
        icon: SprintPushpinIcon.fromPin(pin).blue().toString()
      });
    }

    this.hoveredPin = pin;
  }

  pinMouseOut(pin: BingTypes.Pushpin) {
    this.hoveredPin = null;

    if (!this.isPinSelected(pin)) {
      pin.setOptions({
        icon: SprintPushpinIcon.fromPin(pin).yellow().toString()
      });
    }
  }

  clearPushpins() {
    this.pushpinUpdates$.next(() => []);
  }

  removePushpin(pin: BingTypes.Pushpin) {
    this.pushpinUpdates$.next(pins =>
      pins.filter(p => p !== pin)
    );
  }

  createPinAtMapCenter() {
    this.mapCenter$
      .take(1)
      .subscribe(location =>
        this.pushpinUpdates$.next((pins, bingService) => {
          const pin = bingService.createPushpin({
            location: location,
            options: { subTitle: 'Center' }
          });
          this.selectedPin = pin;
          return [ pin, ...pins ];
        })
      );
  }

  private get bingMapsService$(): Observable<BingTypes.BingMapsService> {
    return Observable.fromPromise(
      sprintApp.getComponentFactory(BING_MAPS_SERVICE)
        .then((factory: BingTypes.BingMapsServiceFactory) => factory())
    );
  }


}
