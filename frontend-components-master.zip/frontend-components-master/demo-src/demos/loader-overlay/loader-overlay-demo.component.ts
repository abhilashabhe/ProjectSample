import { Component } from '@angular/core';
import { GlobalLoaderOverlayComponent } from '../../../src/sprint-angular-modules';

@Component({
  template: `<sprint-global-loader-overlay [title]="'test'" [visible]="'true'"></sprint-global-loader-overlay>`,
  entryComponents: [ GlobalLoaderOverlayComponent ]
})
export class LoaderOverlayDemoComponent {
  static demoName = 'Global Loader Overlay';
  static demoTopic = 'General';
  static demoDescription = 'an overlay with a line of waving dots and a title';
}
