import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

/*
  https://www.sprint.com/api/digital/catalog/device-prices/190198072221?accountType=I&accountSubType=I&creditClass=A
  https://www.sprint.com/api/digital/catalog/device-prices/190198072290?accountType=I&accountSubType=I&creditClass=A
  https://www.sprint.com/api/digital/catalog/device-prices/190198072344?accountType=I&accountSubType=I&creditClass=A
*/
@Component({
  templateUrl: './services-streams-dashboard.html'
})
export class ServicesStreamsDashboardComponent {
  static demoName = 'Services Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Streams dashboard to list and test the services service layer streams.';

  lookupServicesStreamInputForm: FormGroup;

  constructor() {
    const fb = new FormBuilder();
    this.lookupServicesStreamInputForm
      = fb.group({
          queryParams: fb.group({
            applicationId: 'SHOP',
            salesChannelCode: 'H',
            accountType: 'I',
            accountSubType: 'I',
            corpId: 'null',
            creditClass: 'A',
            zipCode: '66213',
            filter: 'FILTER_DOWNLOADABLE_APP_ID',
            lineDetail: fb.group({
              lineType: 'GROSS_ADD',
              itemID: '190198072214',
              contractId: '0-yr-lb-17months',
              newPlanSOC: 'LPDSA0063'
            })
          })
        });
  }
}
