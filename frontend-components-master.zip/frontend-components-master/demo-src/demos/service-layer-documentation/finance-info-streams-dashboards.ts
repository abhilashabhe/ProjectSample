import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  templateUrl: './finance-info-streams-dashboard.html'
})
export class FinanceInfoStreamsDashboardComponent {
  static demoName = 'Finance-Info Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Streams dashboard to list and test the finance-info service layer streams.';

  postFinanceInfoStreamInputForm: FormGroup;
  creditCheckInfo: FormGroup;
  contactInfo: FormGroup;

  constructor() {

    const fb = new FormBuilder();
    this.contactInfo = fb.group({
      name: fb.group({
        firstName: 'Test',
        lastName: 'Test'
      }),
      contact: fb.group({
        phone: '4102349872',
        email: 'abdd.dccd@sprint.com'
      }),
      address: fb.group({
        address1: '12000 Sunrise Valley Dr',
        address2: '',
        urbanization: 'null',
        zip: '20191',
        city: 'Reston',
        state: 'VA'
      })
    });

    this.creditCheckInfo = fb.group({
      doNotValidateSSNInBillingSystem: false,
      ssn: 'null',
      dateOfBirth: 'null',
      fein: '213121211',
      companyName: 'Test',
      creditCheckType: 'CREDIT_CHECK_TYPE_FEIN',
      applicationNumber: 'null',
      doFinanceChatCheck: true
    });

    this.postFinanceInfoStreamInputForm
      = fb.group({
      data:  fb.group({
          creditCheckInfo: this.creditCheckInfo,
          contactInfo: this.contactInfo
      })
    });
  }
}
