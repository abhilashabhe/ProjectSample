import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  templateUrl: './nba-streams-dashboard.html'
})
export class NBAStreamsDashboardComponent {
  static demoName = 'NBA Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Streams dashboard to list and test the NBA service layer streams.';

  putProfileOffersInputForm: FormGroup;
  putOfferDispositionInputForm: FormGroup;

  constructor() {
    const fb = new FormBuilder();

    this.putProfileOffersInputForm
      = fb.group({
      pathParams: fb.group({
        accountId: '120935560',
        subscriptionId: '71462884121'
      }),
      data: fb.group({
        profileOffersRequest: {
          intentId: "IR21",
        }
      })
    });
    
    this.putOfferDispositionInputForm
      = fb.group({
      pathParams: fb.group({
        accountId: '120935560',
        subscriptionId: '71462884121'
      }),
      data: fb.group({
        offerDispositionRequest: {
          intentId: "IR21",
          offerList: {
            offerInfo: [
              {
                offerId: 15839,
                pyOutcome: "Accepted"
              }
            ]
          }
        }
      })
    });
  }
}
