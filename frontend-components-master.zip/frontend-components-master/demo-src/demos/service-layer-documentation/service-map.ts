/*
  NOTE for devleopers

  This page serves as more of a reference than a demo.
  Almost all of the interfaces we import and use below are internal
  to the service layer's functionality and should NOT be imported
  as part of regular development.
*/

import { Component, ViewEncapsulation } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import { IServiceLayer, IServiceLayerFactory } from '../../../src/aem-components/interfaces/service-layer';
import { IServiceDefinition } from '../../../src/aem-components/service-layer/lib';
import { SprintResourceForest } from '../../../src/aem-components/service-layer/resources/resource.globals';
import { IResourceForest } from '../../../src/aem-components/service-layer/lib';
import { streamLog } from '../../../src/sprint-angular-modules/service-layer/debug/stream-log';

declare var sprintApp: ISprintApp;

@Component({
  templateUrl: './service-map.html',
  encapsulation: ViewEncapsulation.None
})
export class DemoServiceMapComponent {
  static demoName = 'Service Map';
  static demoTopic = 'Service Layer';
  static demoDescription = 'API-level service mapping or all resource trees.';

  serviceList: IServiceDefinition[] = [];
  serviceLayer: IServiceLayer;
  resourceForest: IResourceForest = SprintResourceForest;

  constructor() {
    sprintApp.getComponentFactory('SprintStreams')
      .then((serviceLayerFactory: IServiceLayerFactory) => {
        const serviceLayer: IServiceLayer = serviceLayerFactory();
        window['serviceLayer'] = serviceLayer;
        window['streamLog'] = streamLog;

        window['getCheckEligibility']
          = Observable.of(serviceLayer.getStreamRunner('getCheckEligibility'))
             .mergeMap(runner => runner({
               pathParams: {
                 accountId: '100656189',
                 subscriberId: '76087286121'
               },
               queryParams: {
                 flow: 'changeService'
               }
             }));

        this.serviceList = serviceLayer.sprintServiceList;
      });

  }
}
