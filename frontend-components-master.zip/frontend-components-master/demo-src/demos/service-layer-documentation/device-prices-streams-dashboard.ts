import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

/*
  https://www.sprint.com/api/digital/catalog/device-prices/190198072221?accountType=I&accountSubType=I&creditClass=A
  https://www.sprint.com/api/digital/catalog/device-prices/190198072290?accountType=I&accountSubType=I&creditClass=A
  https://www.sprint.com/api/digital/catalog/device-prices/190198072344?accountType=I&accountSubType=I&creditClass=A
*/
@Component({
  templateUrl: './device-prices-streams-dashboard.html'
})
export class DevicePricesStreamsDashboardComponent {
  static demoName = 'Device-Prices Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Streams dashboard to list and test the device-prices service layer streams.';

  getDeviceStreamInputForm: FormGroup;
  getDevicePricesStreamInputForm: FormGroup;

  constructor() {
    const fb = new FormBuilder();

    this.getDeviceStreamInputForm
      = fb.group({
          pathParams: fb.group({
            deviceId: '888462500739'
          })
        });

    this.getDevicePricesStreamInputForm
      = fb.group({
          pathParams: fb.group({
            deviceId: '190198072221'
          }),
          queryParams: fb.group({
            accountType: 'I',
            accountSubType: 'I',
            creditClass: 'A'
          })
        });
  }
}
