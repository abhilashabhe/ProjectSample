import { Component, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormArray } from '@angular/forms';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import * as AEMServletServiceInterfaces from '../../../src/aem-components/interfaces/aem-servlet-service';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';

declare const sprintApp: ISprintApp;

interface Tab {
  name: string;
  active: boolean;
}

@Component({
  templateUrl: './aem-servlet-services.html'
})
export class AEMServletServicesComponent {
  static demoName = 'AEM Servlet Services';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Examples for using the AEM Servlet service. The AEMServletService takes in any number of calls to the AEM Servlet service for content data. It will then batch those calls using a timing interval and then execute them. If the call fails or no data is returned for a specific service, it will be requeued for retry up to a maximum number of retries. Once the data is returned, it is cached and can be called for again at any time without requiring another network request.';

  /* UI tabs */
  tabs$ =
    new BehaviorSubject<Tab[]>([
      { name: 'Services', active: true },
      { name: 'Service Categories', active: false },
      { name: 'Devices',  active: false },
      { name: 'Plans',  active: false }
    ]);

  activeTabName$: Observable<string>;

  /* AEM Servlet - Get Service Details Params */
  private aemServletService: Observable<AEMServletServiceInterfaces.AEMServletService>;
  private serviceDetailsSubject = new BehaviorSubject<any>(null);
  private serviceCategoryDetailsSubject = new BehaviorSubject<any>(null);
  private deviceDetailsSubject = new BehaviorSubject<any>(null);
  private planDetailsSubject = new BehaviorSubject<any>(null);
  serviceDetails$: Observable<any>;
  serviceCategoryDetails$: Observable<any>;
  deviceDetails$: Observable<any>;
  planDetails$: Observable<any>;

  serviceIds = [
    'ENABLEIDR',
    'LSALLU',
    'PREMRESAM',
    'PRIMEATCH',
    'ENABLEIDR',
    'PDSINT1D'
  ];
  serviceCategoryIds = [
    'srvc1018000cat',
    'srvc1002002cat',
    'srvc895007cat',
    'srvc888002cat'
  ];
  itemIds = [
    'RCCIP6S16GLD',
    '190198360922',
    '190198047908',
    '190198072290',
    '888462501774',
    'RCCI6SP128RS'
  ];
  planIds = [
    'LPDSA0500',
    'LSD134AS',
    'PDSI3PP'
  ];


  serviceIdsForm: FormArray;
  serviceCategoryIdsForm: FormArray;
  itemIdsForm: FormArray;
  planIdsForm: FormArray;

  static toFormArray<T>(fb: FormBuilder, list: T[]): FormArray {
    return list
      .map(() => fb.control(Math.round(Math.random()) === 0))
      .reduce((array, control) => array.push(control) || array, fb.array([]));
  }

  constructor(
    private fb: FormBuilder,
    private changeDetector: ChangeDetectorRef
  ) {
    this.serviceIdsForm = AEMServletServicesComponent.toFormArray(this.fb, this.serviceIds);
    this.serviceCategoryIdsForm = AEMServletServicesComponent.toFormArray(this.fb, this.serviceCategoryIds);
    this.itemIdsForm = AEMServletServicesComponent.toFormArray(this.fb, this.itemIds);
    this.planIdsForm = AEMServletServicesComponent.toFormArray(this.fb, this.planIds);

    this.activeTabName$
      = this.tabs$
          .map(tabs => {
            const activeTab = tabs.find(t => t.active === true);
            return !!activeTab && activeTab.name;
          });

    this.serviceDetails$
      = this.serviceDetailsSubject.asObservable()
          .do(_ => this.changeDetector.detectChanges());

    this.serviceCategoryDetails$
      = this.serviceCategoryDetailsSubject.asObservable()
          .do(_ => this.changeDetector.detectChanges());

    this.deviceDetails$
      = this.deviceDetailsSubject.asObservable()
          .do(_ => this.changeDetector.detectChanges());

    this.planDetails$
      = this.planDetailsSubject.asObservable()
          .do(_ => this.changeDetector.detectChanges());

    this.aemServletService = Observable.fromPromise(
      sprintApp
        .getComponentFactory<AEMServletServiceInterfaces.AEMServletServiceFactory>(AEMServletServiceInterfaces.aemServletServiceKey)
        .then((factory: AEMServletServiceInterfaces.AEMServletServiceFactory) => factory())
    );

  }

  setActiveTab(index: number) {
    this.tabs$.take(1)
      .subscribe(tabs =>
        this.tabs$.next(
          tabs.map((tab, i) => ({
            ...tab,
            active: i === index
          }))
        )
      );
  }

  getServicesFromAEM() {
    const serviceIds = this.serviceIds.filter((id, i) => this.serviceIdsForm.value[i]);
    this.aemServletService
      .mergeMap((aemServletService: AEMServletServiceInterfaces.AEMServletService) =>
        aemServletService.getServicesFromAEM(serviceIds)
      )
      .take(1)
      .subscribe(
        data => this.serviceDetailsSubject.next(data),
        error => console.log(error)
      );
  }

  getServiceCategoriesFromAEM() {
    const serviceCategoryIds = this.serviceCategoryIds.filter((id, i) => this.serviceCategoryIdsForm.value[i]);
    this.aemServletService
      .mergeMap((aemServletService: AEMServletServiceInterfaces.AEMServletService) =>
        aemServletService.getServiceCategoriesFromAEM(serviceCategoryIds)
      )
      .take(1)
      .subscribe(
        data => this.serviceCategoryDetailsSubject.next(data),
        error => console.log(error)
      );
  }

  getDevicesFromAEM() {
    const itemIds = this.itemIds.filter((id, i) => this.itemIdsForm.value[i]);
    this.aemServletService
      .mergeMap((aemServletService: AEMServletServiceInterfaces.AEMServletService) =>
        aemServletService.getDevicesFromAEM(itemIds)
      )
      .take(1)
      .subscribe(
        data => this.deviceDetailsSubject.next(data),
        error => console.log(error)
      );
  }

  getPlansFromAEM() {
    const planIds = this.planIds.filter((id, i) => this.planIdsForm.value[i]);
    this.aemServletService
      .mergeMap((aemServletService: AEMServletServiceInterfaces.AEMServletService) =>
        aemServletService.getPlansFromAEM(planIds)
      )
      .take(1)
      .subscribe(
        data => this.planDetailsSubject.next(data),
        error => console.log(error)
      );
  }
}
