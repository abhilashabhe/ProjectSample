import { Component, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import * as ServiceLayerInterfaces from '../../../src/aem-components/interfaces/service-layer';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import * as _ from 'lodash';

declare var sprintApp: ISprintApp;

@Component({
  templateUrl: './cache-streams.html'
})
export class CacheStreamsComponent implements OnInit {
  static demoName = 'Cache Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Examples for using the caching mechanisms of the service layer.';

  /* AEM Servlet - Get Service Details Params */
  private serviceLayer: Observable<ServiceLayerInterfaces.IServiceLayer>;
  private cachedServiceDetailsResultSubject = new BehaviorSubject<any>(null);
  public cachedServiceDetailsResult: Observable<any>;
  public serviceIds: string;

  ngOnInit() {
    this.cachedServiceDetailsResult = this.cachedServiceDetailsResultSubject.asObservable();
    this.serviceLayer = Observable.fromPromise(
      sprintApp
        .getComponentFactory<ServiceLayerInterfaces.IServiceLayerFactory>(ServiceLayerInterfaces.SERVICE_LAYER)
        .then((factory: ServiceLayerInterfaces.IServiceLayerFactory) => factory())
    );
  }

  dispatchServiceDetailsCachedCall() {
    this.serviceLayer
      .mergeMap((serviceLayer: ServiceLayerInterfaces.IServiceLayer) =>
        serviceLayer.getStreamRunnerWithCache('getAEMServiceData')({
          pathParams: {
            searchKey: 'ensembleId',
            searchValue: this.serviceIds
          }
        })
      )
      .map(res => {
        if (!res || !res.data || _.isEmpty(res.data)) {
          throw new Error('Empty response from AEM servlet for service data.');
        } else {
          return res.data;
        }
      })
      .retry(1)
      .take(1)
      .subscribe(
        data => this.cachedServiceDetailsResultSubject.next(data),
        error => console.log(error)
      );
  }

  clearServiceDetailsCache() {
    this.serviceLayer
      .map((serviceLayer: ServiceLayerInterfaces.IServiceLayer) =>
        serviceLayer.clearStreamRunnerCache('getAEMServiceData', {
          pathParams: {
            searchKey: 'ensembleId',
            searchValue: this.serviceIds
          }
        })
      )
      .take(1)
      .subscribe(
        () => console.log(`AEM services data cache cleared for serviceIds: ${this.serviceIds}`),
        error => console.log(error)
      );
  }

  clearAllServiceDetailsCache() {
    this.serviceLayer
      .map((serviceLayer: ServiceLayerInterfaces.IServiceLayer) =>
        serviceLayer.clearStreamRunnerCache('getAEMServiceData')
      )
      .take(1)
      .subscribe(
        () => console.log('All AEM services data ache cleared.'),
        error => console.log(error)
      );
  }
}
