import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  templateUrl: './user-info-streams-dashboard.html'
})
export class UserInfoStreamsDashboardComponent {
  static demoName = 'User-Info Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Streams dashboard to list and test the user-info service layer streams.';

  getCorpInfoStreamInputForm: FormGroup;
  postUserInfoStreamInputForm: FormGroup;

  constructor() {
    const fb = new FormBuilder();

    this.getCorpInfoStreamInputForm
      = fb.group({
      queryParams: fb.group({
        emailDomain: 'aaa.com'
      })
    });

    this.postUserInfoStreamInputForm
      = fb.group({
      data: fb.group({
        accountType: 'B',
        accountSubType: 'B',
        corpID: null
      })
    });
  }
}
