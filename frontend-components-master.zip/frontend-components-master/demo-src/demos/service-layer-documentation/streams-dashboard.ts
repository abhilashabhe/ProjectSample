import { Observable } from 'rxjs/Observable';
import { Component } from '@angular/core';
import { Plan } from '../../../src/aem-components/interfaces/service-layer/schemas';
import { IServiceLayer, IServiceLayerFactory } from '../../../src/aem-components/interfaces/service-layer';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import { IServiceInput } from '../../../src/aem-components/service-layer/lib';
import { AccountRequest } from '../../../src/aem-components/interfaces/service-layer/schemas/orders/account-request.interface';
import { Orders } from '../../../src/aem-components/interfaces/service-layer/schemas/orders/orders.interface';
import { Order } from '../../../src/aem-components/interfaces/service-layer/schemas/orders/order.interface';
import { OrderStatus } from '../../../src/aem-components/interfaces/service-layer/schemas/orders/orderStatus.interface';
import { CreditCheckOptions, CreditClass } from '../../../src/aem-components/interfaces/service-layer/schemas/orders/creditCheck.interface';
import { CustomerServiceArea } from '../../../src/aem-components/interfaces/service-layer/schemas/customer-service-areas/customer-service-areas.interface';
import { ILocationServiceFactory, ILocationService } from '../../../src/aem-components/interfaces/location-service/index';
import { BingResult } from '../../../src/aem-components/interfaces/service-layer/schemas/bing/bing-result.interface';
import { BingLocationResource } from '../../../src/aem-components/interfaces/service-layer/schemas/bing/bing-location-resource.interface';
import { IGetBingLocationsRequest, IGetBingLocationByPointRequest } from '../../../src/aem-components/interfaces/service-layer/schemas/bing/bing.api-requests.interface';

declare const sprintApp: ISprintApp;
declare let globalError: string;

@Component({
  templateUrl: './streams-dashboard.html'
})
export class StreamsDashboardComponent {
  static demoName = 'Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Streams dashboard to list and test the service layer streams.';

  public orderId = '12345';
  private serviceLayer$: Observable<IServiceLayer>;
  deviceId = '888462500739';
  getDeviceStream: Observable<any>;
  getDevicePricesStream: Observable<any>;
  getDeviceErrorStream: Observable<any>;
  getDeviceLoadingStream: Observable<any>;
  getDevicesStream: Observable<any>;
  getAccessoriesStream: Observable<any>;
  getAccessoryStream: Observable<any>;
  getDevicesPricesStream: Observable<any>;
  getDeviceStreamRunner: (input: any) => Observable<any>;
  getServicesStream: Observable<any>;
  getPlanStream: Observable<Plan>;
  getAccountInfoStream: Observable<AccountRequest>;
  updateAccountInfoStream: Observable<AccountRequest>;
  getOrdersStream: Observable<Orders>;
  getOrderStream: Observable<Order>;
  createOrderStream: Observable<Order>;
  getOrderStatusStream: Observable<OrderStatus>;
  getCreditCheckStream: Observable<any>;
  updateCreditCheckStream: Observable<any>;
  getCreditCheckOptionsStream: Observable<CreditCheckOptions>;
  getCreditClassStream: Observable<CreditClass>;
  getCustomerServiceArea: Observable<CustomerServiceArea>;
  getBingLocations: Observable<BingResult<BingLocationResource>>;
  getBingLocationByPoint: Observable<BingResult<BingLocationResource>>;
  private locationService: ILocationService;

  getDevicesInput: IServiceInput = {};

  getDevicesPricesInput: IServiceInput = {
    queryParams: {
      accountType: 'I',
      accountSubType: 'I',
      creditClass: 'A'
    }
  };

  getDevicePricesInput: IServiceInput = {
    pathParams: {
      deviceId: this.deviceId
    },
    queryParams: {
      accountType: 'I',
      accountSubType: 'I',
      creditClass: 'A',
      subscriptionId: '76512541121',
      flow: 'UPGRADE'
    }
  };

  getPlansInput: IServiceInput = {
    queryParams: {
      deviceId: `888462500845`,
      csa: 'DETKAL616',
      accountType: 'I',
      accountSubType: 'I'
    }
  };
  getServicesInput: IServiceInput = {
    queryParams: {
      deviceId: `888462500845`,
      csa: 'DETKAL616',
      accountType: 'I',
      accountSubType: 'I',
      flow: 'GROSS_ADD',
      creditClass: 'A',
      planSoc: 'LSD92AS'
    }
  };

  getAccessoriesInput: IServiceInput = {
    queryParams: {
      deviceId: this.deviceId
    }
  };

  getAccessoryInput: IServiceInput = {
    pathParams: {
      accessoryId: 'this.accessoryId'
    }
  };

  getOrderStatusInput: IServiceInput = {
    pathParams: {
      orderId: '12345'
    }
  };
  getAccountInfoInput: IServiceInput = {
    pathParams: {
      orderId: '12345'
    }
  };
  updateAccountInfoInput: IServiceInput = {
    pathParams: {
      orderId: '12345'
    },
    data: {
      name: {
        firstName: 'Test',
        lastName: 'Test'
      },
      contact: {
        phone: '8169167150',
        email: 'test@test.com'
      },
      address: {
        address1: '1529 NE Jade St',
        address2: null,
        urbanization: null,
        zip: '64086',
        city: 'lees summit',
        state: 'MO'
      }
    }
  };
  updateCreditCheckInput: IServiceInput = {
    pathParams: {
      orderId: '12345'
    },
    data: {
      doNotValidateSSNInBillingSystem: 'true',
      ssn: '999999906',
      dateOfBirth: 'Sun, 06 Nov 1994 00:00:00 GMT',
      fein: '',
      companyName: '',
      creditCheckType: 'CREDIT_CHECK_TYPE_SSN_DOB'
    }
  };

  getCustomerServiceAreaInput: IServiceInput = {
    queryParams: {
      latitude: '',
      longitude: ''
    }
  };

  getBingLocationsInput: IGetBingLocationsRequest = {
    queryParams: {
      query: '1 Microsoft Way Redmond, WA 98052'
    }
  };

  getBingLocationByPointInput: IGetBingLocationByPointRequest = {
    queryParams: {},
    pathParams: {
      lat: 0,
      long: 0
    }
  };

  constructor() {
    const serviceLayerPromise: Promise<IServiceLayer>
      = new Promise<IServiceLayer>(resolve =>
          sprintApp.getComponentFactory('SprintStreams')
            .then((serviceLayerFactory: IServiceLayerFactory) => resolve(serviceLayerFactory()))
        );

    this.serviceLayer$ = Observable.fromPromise(serviceLayerPromise);

    this.serviceLayer$
      .subscribe(serviceLayer => {
        this.getDeviceStream = serviceLayer.getStream('getDevice').pluck('data');
        this.getDevicePricesStream = serviceLayer.getStream('getDevicePrices').pluck('data');
        this.getDeviceErrorStream = serviceLayer.getErrorStream('getDevice')
          .pluck('response', 'data')
          .do((error: string) => globalError = error);
        this.getDeviceStreamRunner = serviceLayer.getStreamRunner('getDevice');
        this.getDeviceLoadingStream = serviceLayer.getLoadingStream('getDevice');
        this.getDevicesStream = serviceLayer.getStream('getDevices').pluck('data');
        this.getAccessoriesStream = serviceLayer.getStream('getAccessories').pluck('data');
        this.getAccessoryStream = serviceLayer.getStream('getAccessory').pluck('data');
        this.getDevicesPricesStream = serviceLayer.getStream('getDevicesPrices').pluck('data');
        this.getPlanStream = serviceLayer.getStream('getPlans').pluck('data');
        this.getServicesStream = serviceLayer.getStream('getServices').pluck('data');

        this.getAccountInfoStream = serviceLayer.getStream('getAccountInfo').pluck('data');
        this.updateAccountInfoStream = serviceLayer.getStream('updateAccountInfo').pluck('data');
        this.getOrdersStream = serviceLayer.getStream('getOrders').pluck('data');
        this.getOrderStream = serviceLayer.getStream('getOrder').pluck('data');
        this.getOrderStatusStream = serviceLayer.getStream('getOrderStatus').pluck('data');
        this.createOrderStream = serviceLayer.getStream('createOrder').pluck('data');

        this.getCreditCheckStream = serviceLayer.getStream('getCreditCheck').pluck('data');
        this.updateCreditCheckStream = serviceLayer.getStream('updateCreditCheck').pluck('data');

        this.getCreditCheckOptionsStream = serviceLayer.getStream('getCreditCheckOptions').pluck('data');
        this.getCreditClassStream = serviceLayer.getStream('getCreditClass').pluck('data');

        this.getCustomerServiceArea = serviceLayer.getStream('getCustomerServiceArea').pluck('data');
        this.getBingLocations = serviceLayer.getStream('getBingLocations');
        this.getBingLocationByPoint = serviceLayer.getStream('getBingLocationByPoint');
      });

    sprintApp.getComponentFactory('LocationService').then((locationServiceFactory: ILocationServiceFactory) => {
      this.locationService = locationServiceFactory();
    });
  }


  get getDeviceInput() {
    return {
      pathParams: {
        deviceId: this.deviceId
      }
    };
  }

  setOrderId(event: Event) {
    this.orderId = (<HTMLInputElement>event.target).value;

    this.getOrderStatusInput.pathParams = {
      orderId: this.orderId
    };
    this.getAccountInfoInput.pathParams = {
      orderId: this.orderId
    };
    this.updateAccountInfoInput.pathParams = {
      orderId: this.orderId
    };
  }

  dispatchGetDevices() {
    this.createEvent('getDevices', {});
    return false;
  }
  dispatchGetDevice() {
    this.createEvent('getDevice', this.getDeviceInput);
    return false;
  }
  dispatchGetAccessories() {
    this.createEvent('getAccessories', this.getAccessoriesInput);
    return false;
  }
  dispatchGetAccessory() {
    this.createEvent('getAccessory', this.getAccessoryInput);
    return false;
  }
  dispatchGetDevicesPrices() {
    this.createEvent('getDevicesPrices', this.getDevicesPricesInput);
    return false;
  }
  dispatchGetDevicePrices() {
    this.createEvent('getDevicePrices', this.getDevicePricesInput);
    return false;
  }

  runGetDevice() {
    this.getDeviceStreamRunner(this.getDeviceInput)
      .subscribe(
        output => console.log('get device runner output: ', output),
        error => console.log('get device runner error: ', error),
        () => console.log('get device runner completed')
      );
  }

  runGetDeviceWithCache() {
    this.serviceLayer$
      .mergeMap(serviceLayer => serviceLayer.getStreamRunnerWithCache('getDevice')(this.getDeviceInput))
      .subscribe(
        output => console.log('get device runner output: ', output),
        error => console.log('get device runner error: ', error),
        () => console.log('get device runner completed')
      );
  }

  dispatchGetServices() {
    this.createEvent('getPlans', this.getServicesInput);
    return false;
  }
  dispatchGetPlans() {
    this.createEvent('getPlans', this.getPlansInput);
    return false;
  }

  dispatchCreateOrder() {
    this.createEvent('createOrder', {});
    return false;
  }

  dispatchGetOrder() {
    this.createEvent('getOrder', this.getOrderStatusInput);
    return false;
  }
  dispatchGetOrders() {
    this.createEvent('getOrders', {});
    return false;
  }
  dispatchGetOrderStatus() {
    this.createEvent('getOrderStatus', this.getOrderStatusInput);
    return false;
  }
  dispatchGetAccountInfo() {
    this.createEvent('getAccountInfo', this.getAccountInfoInput);
    return false;
  }
  dispatchUpdateAccountInfo() {
    this.createEvent('updateAccountInfo', this.updateAccountInfoInput);
    return false;
  }

  dispatchGetCreditCheck() {
    this.createEvent('getCreditCheck', this.getOrderStatusInput);
    return false;
  }

  dispatchUpdateCreditCheck() {
    this.createEvent('updateCreditCheck', this.updateCreditCheckInput);
    return false;
  }

  dispatchGetCreditCheckOptions() {
    this.createEvent('getCreditCheckOptions', this.getOrderStatusInput);
    return false;
  }

  dispatchGetCreditClass() {
    this.createEvent('getCreditClass', this.getOrderStatusInput);
    return false;
  }

  dispatchGetCustomerServiceArea() {
    window.navigator.geolocation.getCurrentPosition((position: Position) => {
      this.getCustomerServiceAreaInput.queryParams = {
        latitude: '' + position.coords.latitude,
        longitude: '' + position.coords.longitude
      };
      this.createEvent('getCustomerServiceArea', this.getCustomerServiceAreaInput);
    });
  }

  dispatchLocationService() {
    this.locationService.getCSA()
      .subscribe( CSA => {
        console.log('CSA', CSA);
    });
  }

  dispatchGetBingLocations() {
    this.createEvent('getBingLocations', this.getBingLocationsInput);
    return false;
  }

  dispatchGetBingLocationByPoint() {
    this.createEvent('getBingLocationByPoint', this.getBingLocationByPointInput);
    return false;
  }

  private createEvent(name: string, payload: any) {
    const event: any = new Event(name);
    event['payload'] = payload;
    window.dispatchEvent(event);
  }
}
