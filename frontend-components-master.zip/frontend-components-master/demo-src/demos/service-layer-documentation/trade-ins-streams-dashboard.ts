import { Observable } from 'rxjs/Observable';
import { Component } from '@angular/core';
import { IServiceLayer, IServiceLayerFactory } from '../../../src/aem-components/interfaces/service-layer';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import { IServiceInput } from '../../../src/aem-components/service-layer/lib';

declare var sprintApp: ISprintApp;

@Component({
  templateUrl: './trade-ins-streams-dashboard.html'
})
export class TradeInStreamsDashboardComponent {
  static demoName = 'TradeIns Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'TradeIns Streams dashboard to list and test the tradeins service layer streams.';

  public orderId = '12345';
  getTradeInsCarriers: Observable<any>;
  getTradeInsCarrierManufacturers: Observable<any>;
  getTradeInsCarrierManufacturerProducts: Observable<any>;
  getTradeInsEligibility: Observable<any>;

  constructor() {
    /**
     * TODO: Need to call sprintApp.getComponentFactory to get a reference to the service layer component
     */
    sprintApp.getComponentFactory('SprintStreams').then((serviceLayerFactory: IServiceLayerFactory) => {
      const serviceLayer: IServiceLayer = serviceLayerFactory();

      this.getTradeInsCarriers = serviceLayer.getStream('getTradeInsCarriers').pluck('data');
      this.getTradeInsCarrierManufacturers = serviceLayer.getStream('getTradeInsCarrierManufacturers').pluck('data');
      this.getTradeInsCarrierManufacturerProducts = serviceLayer.getStream('getTradeInsCarrierManufacturerProducts').pluck('data');
      this.getTradeInsEligibility = serviceLayer.getStream('getTradeInsEligibility').pluck('data');
    });
  }

  getTradeInsCarrierManufacturersInput: IServiceInput = {
    pathParams: {
      carrierId: 'TEST'
    }
  };

  getTradeInsCarrierManufacturerProductsInput: IServiceInput = {
    pathParams: {
      carrierId: 'TEST',
      manufacturerId: 'TEST'
    }
  };

  // trade-in data for iphone se in st2
  getTradeInsEligibilityInput: IServiceInput = {
    queryParams: {
      tradeInESN: '089253965503481880',
      tradeInProductId: 'CUIP732--USPBXATT1WR',
      purchaseDeviceId: '888462734905',
      offerGroupCode: 'TEST1173TSTEQ200L',
      promoCode: 'LG494',
      accountType: 'I',
      accountSubType: 'I',
      offerSaleType: 'L'
    }
  };

  dispatchGetTradeInsCarriers($event: Event) {
    $event.preventDefault();
    this.createEvent('getTradeInsCarriers', {});
    return false;
  }

  dispatchGetTradeInsCarrierManufacturers($event: Event) {
    $event.preventDefault();
    this.createEvent('getTradeInsCarrierManufacturers', this.getTradeInsCarrierManufacturersInput);
    return false;
  }

  dispatchGetTradeInsCarrierManufacturerProducts($event: Event) {
    $event.preventDefault();
    this.createEvent('getTradeInsCarrierManufacturerProducts', this.getTradeInsCarrierManufacturerProductsInput);
    return false;
  }

  dispatchGetTradeInsEligibility($event: Event) {
    $event.preventDefault();
    this.createEvent('getTradeInsEligibility', this.getTradeInsEligibilityInput);
    return false;
  }

  private createEvent(name: string, payload: any) {
    const event: any = new Event(name);
    event['payload'] = payload;
    window.dispatchEvent(event);
  }
}
