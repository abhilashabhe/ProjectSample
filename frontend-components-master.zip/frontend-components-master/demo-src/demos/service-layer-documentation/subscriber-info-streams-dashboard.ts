import { Observable } from 'rxjs/Observable';
import { Component } from '@angular/core';
import { IServiceLayer, IServiceLayerFactory } from '../../../src/aem-components/interfaces/service-layer';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import { IServiceInput } from '../../../src/aem-components/service-layer/lib';

declare var sprintApp: ISprintApp;

@Component({
  templateUrl: './subscriber-info-streams-dashboard.html'
})
export class SubscriberInfoStreamsDashboardComponent {
  static demoName = 'Subscriber Info Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Subscriber Info Streams dashboard to list and test the Subscriber Info service layer streams.';

  getSubscriberUpgradeInfo: Observable<any>;

  accountId: string;
  subscriberId: string;


  getSubscriberUpgradeInfoInput: IServiceInput = {
    pathParams: {
      accountId: '12345'
    },
    queryParams: {

    }
  };


  constructor() {
    /**
     * TODO: Need to call sprintApp.getComponentFactory to get a reference to the service layer component
     */
    sprintApp.getComponentFactory('SprintStreams').then((serviceLayerFactory: IServiceLayerFactory) => {
      const serviceLayer: IServiceLayer = serviceLayerFactory();

      this.getSubscriberUpgradeInfo = serviceLayer.getStream('getSubscriberUpgrades');

      serviceLayer.getErrorStream('getSubscriberUpgrades').subscribe((err) => {
        console.log(err);
      });

      this.getSubscriberUpgradeInfo
        .map( res => res.data)
        .subscribe(data => {
          console.log(data);
        });
    });
  }

  dispatchGetSubscriberUpgradeInfo() {
    this.createEvent('getSubscriberUpgrades', this.getSubscriberUpgradeInfoInput);
    return false;
  }

  accountIdChange($event: Event) {
    this.accountId = (<HTMLInputElement>$event.target).value;
    this.getSubscriberUpgradeInfoInput.pathParams.accountId = this.accountId;
  }

  subscriberIdChange($event: Event) {
    this.subscriberId = (<HTMLInputElement>$event.target).value;
  }

  private createEvent(name: string, payload: any) {
    const event: any = new Event(name);
    event['payload'] = payload;
    window.dispatchEvent(event);
  }
}
