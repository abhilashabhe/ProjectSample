import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';

@Component({
  templateUrl: './marketo-streams-dashboard.html'
})
export class MarketoStreamsDashboardComponent {
  static demoName = 'Marketo Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Streams dashboard to list and test the finance-info service layer streams.';

  postMarketoStreamInputForm: FormGroup;

  constructor() {

    const fb = new FormBuilder();

    this.postMarketoStreamInputForm
      = fb.group({
      data:  fb.group({
        Unsubscribe: true,
        aARTaccountSubtype: 'C',
        aARTaccountType: 'A',
        aARTcorporationName: 'Google',
        aARTemailDomain: 'aaa.com',
        bizILCorpID: 'NAZZ_ZZZ',
        bizILOfferedCorpID: '',
        bizILVertical: 'Save',
        company: 'Google',
        country: 'United States',
        emailAddress: 'test@aaa.com',
        firstName: 'test',
        lastName: 'test',
        formVid: 4184,
        iTSourceCode: 10536,
        leadSource: 'Web',
        phone: '1231231234',
        solutionInterestBizIL: true,
        subId: 18,
        _mktoReferrer: 'https://www.sprint.com/en/shop/discounts/sprint-discount-program.html?ECID=vanity:save',
        cr: '',
        followupLpId: 9855,
        formid: 4185,
        kw: '',
        lpId: 9830,
        lpurl: '//BusinessSolutions.sprint.com/Save.html?cr={creative}&kw={keyword}',
        munchkinId: '249-GUV-713',
        q: '',
        urlparameter: 'vanity:save'
      })
    });
  }
}
