import { Component/*, ChangeDetectorRef*/ } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Parameterizer } from '../../../src/aem-components/service-layer/lib/parameterizer';
// import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';

// declare const sprintApp: ISprintApp;

@Component({
  template: `
    <div class="container pa-40">
      <div class="row">
        <div class="col-xs-12">
          <h2>Input</h2>
          <div class="soar-input">
            <textarea
              [formControl]="paramControl"
              id="objectInput"
              class="spa"></textarea>
          </div>
        </div>
        <div class="col-xs-12">
          <h2>Output</h2>
          <p>{{urlOutput$ | async}}</p>
        </div>
      </div>
    </div>
  `,
  styles: [`
    p {
      overflow-wrap: break-word;
    }
    textarea {
      min-height: 500px;
      width: 100%;
    }
  `]
})
export class ParameterizerDemoComponent {
  static demoName = 'Parameterizer';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Serializing complex objects into URL strings';

  paramControl: FormControl;
  urlOutput$: Observable<string>;

  constructor() {
    this.paramControl = new FormControl(`
      {
      "applicationId": "MYSPRINT",
      "lineDetail": [
          {
            "lineType": "CHANGE_PLAN",
            "subscriberID": "09752386121"
          },
          {
            "lineType": "CHANGE_PLAN",
            "subscriberID": 72183386121
          }
        ]
      }
    `);
    // {
    //   "latitude": 100,
    //   "longitude": 100,
    //   "type": "coordinate"
    // }

    this.urlOutput$
      = this.paramControl.valueChanges
          .startWith(this.paramControl.value)
          .map(value => {
            try {
              const obj = JSON.parse(value);
              return Parameterizer.serializeQueryParams(obj);
            } catch (err) {
              return 'Invalid JSON';
            }
          });

  }
}
