import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import * as Schemas from '../../../src/aem-components/interfaces/service-layer/schemas';
import { IServiceLayer, IServiceLayerFactory } from '../../../src/aem-components/interfaces/service-layer';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import { ICartServiceFactory, ICartService} from '../../../src/aem-components/interfaces/cart-service/index';
import { IDeviceService, IDeviceServiceFactory } from '../../../src/aem-components/interfaces/device-service/index';
import { IGetAccountPlansRequest } from '../../../src/aem-components/interfaces/service-layer/schemas/plans/plans.api-requests.interfaces';
import { IGetLookUpServicesRequest } from '../../../src/aem-components/interfaces/service-layer/schemas/lookup-services/lookup-services.api-request.interface';

declare var sprintApp: ISprintApp;

@Component({
  templateUrl: './cart-streams-dashboard.html'
})
export class CartStreamsDashboardComponent implements OnInit {
  static demoName = 'Carts Streams Dashboard';
  static demoTopic = 'Stream Dashboards';
  static demoDescription = 'Carts Streams dashboard to list and test the service layer streams.';

  private _serviceLayer: IServiceLayer;
  private cartService: ICartService;
  @ViewChild('cartId') cartId: ElementRef;
  getCartsResponse: Schemas.Cart[];

  ngOnInit() {
    sprintApp.getComponentFactory('SprintStreams').then((serviceLayerFactory: IServiceLayerFactory) => {
      this._serviceLayer = serviceLayerFactory();
      this.dispatchGetCarts();

      const plansPayload: IGetAccountPlansRequest = {
        data: {},
        queryParams: {
          lineDetail: {
            lineType: 'GROSS_ADD',
            itemID: '190198072214',
            contractId: '0-yr-lb-18months'
          }
        }
      };
      this._serviceLayer.getStreamRunnerWithCache('getAccountPlans')(plansPayload)
        .subscribe(
          (plans) => {
            console.log(plans);
          },
          (err) => {
            console.log(err)
          }
        );

      const servicesPayload: IGetLookUpServicesRequest = {
        queryParams: {
          lineDetail: {
            lineType: 'GROSS_ADD',
            itemID: '190198072214',
            contractId: '0-yr-lb-18months',
            newPlanSOC: 'LSD134AS'
          }
        }
      };

      this._serviceLayer.getStreamRunnerWithCache('getLookUpServices')(servicesPayload)
        .subscribe(
          (plans) => {
            console.log(plans);
          },
          (err) => {
            console.log(err)
          }
        );

      sprintApp.getComponentFactory('DeviceService').then((deviceServiceFactory: IDeviceServiceFactory) => {
        const deviceService: IDeviceService = deviceServiceFactory();

        deviceService.setDeviceInfo({
          color: 'Red',
          storage: '32',
          ensembleId: '888462501835'
        });

        deviceService.setDeviceContract({
          contractInfo: {
            contractId: '0-yr-ib'
          },
          deviceSaleType: 'EASYPAY'
        });

        deviceService.setDeviceCreditInfo({
          value: 'A',
          display: 'Good Credit'
        });

        deviceService.getAccountPlans().subscribe(
          (accountPlans: Schemas.AccountPlansLookup) => {
            console.log(accountPlans);
          },
          err => console.warn(err)
        );
      })
    });

    sprintApp.getComponentFactory('CartService').then((cartServiceFactory: ICartServiceFactory) => {
      this.cartService = cartServiceFactory();
      this.cartService.initializeBaseRequest({
        creditRange: 'GOOD_CREDIT'
      });

      let device: Schemas.BaseRequestDevice = {
        itemID: '190198157430',
        contractInfo: {
          contractId: '0-yr-lb-18months'
        },
        offerGroupInfo: {
          offerGroupCode: 'EUPGNTR18'
        }
      };
      let plan: Schemas.BaseRequestPlanForAddToCart = {
        planSOCSKU: 'LPDSA0511'
      };

      let service: Schemas.BaseRequestService = {
        serviceSOCSKU: 'TEPPLUS',
        serviceStatus: 'NEW'
      };

      this.cartService.addDevice(device, plan, service)
        .subscribe( (data: any) => {
          console.log(data);
        }, (err: any) => {
          console.log(err);
        });

      this.cartService.cartId$.subscribe(
        (data) => console.log('this.cartService.cartId$', data),
        (error) => console.warn('this.cartService.cartId$', error));

      this.cartService.isCartEmpty$.subscribe(
        (data) => console.log('this.cartService.isCartEmpty$', data),
        (error) => console.warn('this.cartService.isCartEmpty$', error));

      this.cartService.packages$.subscribe(
        (data) => console.log('this.cartService.packages$', data),
        (error) => console.warn('this.cartService.packages$', error));

      this.cartService.subpackages$.subscribe(
        (data) => console.log('this.cartService.subpackages$', data),
        (error) => console.warn('this.cartService.subpackages$', error));

      this.cartService.lastPackage$.subscribe(
        (data) => console.log('this.cartService.lastPackage$', data),
        (error) => console.warn('this.cartService.lastPackage$', error));

      this.cartService.lastSubPackage$.subscribe(
        (data) => console.log('this.cartService.lastSubPackage$', data),
        (error) => console.warn('this.cartService.lastSubPackage$', error));

      this.cartService.plans$.subscribe(
        (data) => console.log('this.cartService.plans$', data),
        (error) => console.warn('this.cartService.plans$', error));

      this.cartService.planIds$.subscribe(
        (data) => console.log('this.cartService.planIds$', data),
        (error) => console.warn('this.cartService.planIds$', error));

      this.cartService.AOPackage$.subscribe(
        (data) => console.log('this.cartService.AOPackage$', data),
        (error) => console.warn('this.cartService.AOPackage$', error));

      this.cartService.hasAOPackage$.subscribe(
        (data) => console.log('this.cartService.hasAOPackage$', data),
        (error) => console.warn('this.cartService.hasAOPackage$', error));

      this.cartService.AOObject$.subscribe(
        (data) => console.log('this.cartService.AOObject$', data),
        (error) => console.warn('this.cartService.AOObject$', error));
    });

  }

  dispatchGetCarts() {
    this._serviceLayer.getStreamRunner('getCarts')({}).subscribe(
      (response: Axios.AxiosXHR<Schemas.Cart[]>) => {
        this.getCartsResponse = response.data;
        this.cartId.nativeElement.value = this.getCartsResponse[0].cartId;
      },
      (err) => this.getCartsResponse = err.response
    );
  }
}
