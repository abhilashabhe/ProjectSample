import { Type } from '@angular/core';

import { BingMapDemoComponent } from './bing-map/basic-bing-map';
import { BingMapPinsDemoComponent } from './bing-map/bing-map-pins';
import { AEMServletServicesComponent } from './service-layer-documentation/aem-servlet-services';
import { CartStreamsDashboardComponent } from './service-layer-documentation/cart-streams-dashboard';
import { DemoServiceMapComponent } from './service-layer-documentation/service-map';
import { DevicePricesStreamsDashboardComponent } from './service-layer-documentation/device-prices-streams-dashboard';
import { ServicesStreamsDashboardComponent } from './service-layer-documentation/services-streams-dashboard';
import { ParameterizerDemoComponent } from './service-layer-documentation/parameterizer';
import { DeviceServiceDashboardComponent } from './device-service/device-service-dashboard';
import { DatePickerDemoComponent } from './date-picker/date-picker-demo.component';
import { GenericFormDemoComponent } from './forms/generic-forms.demo';
import { FinanceInfoStreamsDashboardComponent } from './service-layer-documentation/finance-info-streams-dashboards';
import { FormMaskDemoComponent } from './forms/form-masks.demo';
import { LoaderDemoComponent } from './loader/loader-demo.component';
import { SelectizeDemoComponent } from './selectize/selectize-demo';
import { SPABasicVanillaModalDemoComponent } from './vanilla-modal/spa-basic-vanilla-modal-demo';
import { SPAMultipleVanillaModalDemoComponent } from './vanilla-modal/spa-multiple-vanilla-modal-demo';
import { SPAToggleOpenCloseVanillaModalDemoComponent } from './vanilla-modal/spa-toggle-open-close-vanilla-modal-demo';
import { StreamsDashboardComponent } from './service-layer-documentation/streams-dashboard';
import { SubscriberInfoStreamsDashboardComponent } from './service-layer-documentation/subscriber-info-streams-dashboard';
import { TradeInStreamsDashboardComponent } from './service-layer-documentation/trade-ins-streams-dashboard';
import { VanillaModalDemoComponent } from './vanilla-modal/vanilla-modal-demo';
import { BasicTooltipDemoComponent } from './tooltip/basic-tooltip.component';
import { UserInfoStreamsDashboardComponent } from './service-layer-documentation/user-info-streams-dashboard';
import { CacheStreamsComponent } from './service-layer-documentation/cache-streams';
import { LoaderOverlayDemoComponent } from './loader-overlay/loader-overlay-demo.component';
import { MarketoStreamsDashboardComponent } from './service-layer-documentation/marketo-streams-dashboards';
import { NBAStreamsDashboardComponent } from './service-layer-documentation/nba-streams-dashboard';

export interface Demo extends Type<any> {
  demoName: string;
  demoTopic?: string;
  demoDescription?: string;
}

export const DEMO_DECLARATIONS = [
  DemoServiceMapComponent,
  BingMapDemoComponent,
  BingMapPinsDemoComponent,
  StreamsDashboardComponent,
  AEMServletServicesComponent,
  CartStreamsDashboardComponent,
  ServicesStreamsDashboardComponent,
  DevicePricesStreamsDashboardComponent,
  DeviceServiceDashboardComponent,
  ParameterizerDemoComponent,
  SubscriberInfoStreamsDashboardComponent,
  TradeInStreamsDashboardComponent,
  GenericFormDemoComponent,
  FinanceInfoStreamsDashboardComponent,
  FormMaskDemoComponent,
  DatePickerDemoComponent,
  SelectizeDemoComponent,
  SelectizeDemoComponent,
  SPABasicVanillaModalDemoComponent,
  SPAMultipleVanillaModalDemoComponent,
  SPAToggleOpenCloseVanillaModalDemoComponent,
  VanillaModalDemoComponent,
  LoaderDemoComponent,
  BasicTooltipDemoComponent,
  UserInfoStreamsDashboardComponent,
  CacheStreamsComponent,
  LoaderOverlayDemoComponent,
  MarketoStreamsDashboardComponent,
  NBAStreamsDashboardComponent
];
