import { Component, OnInit } from '@angular/core';
import * as I from '../../../src/aem-components/interfaces/date-picker/';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
declare var sprintApp: ISprintApp;

@Component({
  template: `
    <!-- Calendar Input markup from styleguide -->
    <div class="sprint-input sprint-input--date mt-40">
      <input type="text" name="" value="" placeholder="02/02/2017" id="date-picker-demo">
      <label for="date-picker-demo" class="sprint-label--indicatorless">Date</label>
      <div class="sprint-input__icon" aria-hidden="true"></div>
    </div>

    <div id="date-picker-demo-container"></div>

    <!-- Debugging info below -->
    <ul class="border-top">
      <li *ngFor="let m of messages">
        {{ m }}
      </li>
    </ul>
  `
})
export class DatePickerDemoComponent implements OnInit {
  static demoName = 'Date Picker';
  static demoTopic = 'Forms';
  static demoDescription = 'Wrapper for pikaday.js';

  private menu: I.IDatePicker;
  public messages: string[] = [];

  ngOnInit() {
    sprintApp.getComponentFactory<I.IDatePickerFactory>(I.DATE_PICKER)
      .then((factory) => {
        const field = <HTMLInputElement> document.getElementById('date-picker-demo');
        const container = <HTMLElement> document.getElementById('date-picker-demo-container');

        const options: I.IDatePickerOptions = {
          field: field,
          container: container,
          numberOfMonths: 2,
          maxDate: new Date(Date.now() + 36e8),
          minDate: new Date(Date.now() + 6e7),
          labels: [
            ['data-pika-cycle', new Date(Date.now() + 6e7)],
            ['data-pika-due', new Date(Date.now() + 16e7)]
          ]
        };

        this.menu = factory(options);
      });

  }

  addMessage (message: string) {
    this.messages.unshift(message);
  }
}
