import { Component, OnInit, AfterViewInit, ViewChildren, QueryList } from '@angular/core';
import { VanillaModalComponent } from '../../../src/sprint-angular-modules/components/vanilla-modal/vanilla-modal.component';

@Component({
  template: `
    <button type="button" class="button button--link" (click)="openFirstModal()">Open First Modal</button>
    <button type="button" class="button button--link" (click)="openSecondModal()">Open Second Modal</button>
    <sprint-vanilla-modal (onBeforeOpen)="onBeforeOpen('first')"
                          (onOpen)="onOpen('first')"
                          (onClose)="onClose('first')"
                          (onBeforeClose)="onBeforeClose('first')"
                          (onCancel)="cancelFirstModal()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="cancelFirstModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>First Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below.
          </div>
          <div class="col-xs-24 pt-10">
            Clicking the close button, clicking the cancel button, clicking outside the modal, or hitting the \`ESC\` key
            will execute the cancelCallback method. It is important to note that clicking outside the modal or using any
            of the close keys like \`ESC\` (or any you have setup in the modal options) are considered a cancellation of
            the modal. However, these two methods of closing the modal will only call your cancel method if you have
            provided it to the Vanilla Modal Component via \`(onCancel)="someMethod()"\`.
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button  button--secondary button--return" (click)="cancelFirstModal()">Cancel</button>
          </div>
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="saveFirstModal()">Save</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
    <sprint-vanilla-modal (onBeforeOpen)="onBeforeOpen('second')"
                          (onOpen)="onOpen('second')"
                          (onClose)="onClose('second')"
                          (onBeforeClose)="onBeforeClose('second')"
                          (onCancel)="cancelSecondModal()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="cancelSecondModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>Second Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below.
          </div>
          <div class="col-xs-24 pt-10">
            Clicking the close button, clicking the cancel button, clicking outside the modal, or hitting the \`ESC\` key
            will execute the cancelCallback method. It is important to note that clicking outside the modal or using any
            of the close keys like \`ESC\` (or any you have setup in the modal options) are considered a cancellation of
            the modal. However, these two methods of closing the modal will only call your cancel method if you have
            provided it to the Vanilla Modal Component via \`(onCancel)="someMethod()"\`.
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button  button--secondary button--return" (click)="cancelSecondModal()">Cancel</button>
          </div>
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="saveSecondModal()">Save</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
    <sprint-vanilla-modal (onBeforeOpen)="onBeforeOpen('third')"
                          (onOpen)="onOpen('third')"
                          (onClose)="onClose('third')"
                          (onBeforeClose)="onBeforeClose('third')"
                          (onCancel)="cancelThirdModal()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="cancelThirdModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>Third Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below.
          </div>
          <div class="col-xs-24 pt-10">
            Clicking the close button, clicking the cancel button, clicking outside the modal, or hitting the \`ESC\` key
            will execute the cancelCallback method. It is important to note that clicking outside the modal or using any
            of the close keys like \`ESC\` (or any you have setup in the modal options) are considered a cancellation of
            the modal. However, these two methods of closing the modal will only call your cancel method if you have
            provided it to the Vanilla Modal Component via \`(onCancel)="someMethod()"\`.
          </div>
          <div class="col-xs-24 pt-10">
            This modal is an example of an interim "are you sure" modal. The cancellation of this modal should re-open
            the previous modal while the OKing of this modal will simply close the modal
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button  button--secondary button--return" (click)="cancelThirdModal()">Cancel</button>
          </div>
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="closeThirdModal()">Ok</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
  `
})
export class SPAMultipleVanillaModalDemoComponent implements OnInit, AfterViewInit {
  static demoName = 'SPA: Multiple Vanilla Modals';
  static demoTopic = 'Modals';
  static demoDescription = 'Demo multiple vanilla modals.';

  private previousModal: VanillaModalComponent;
  @ViewChildren(VanillaModalComponent)
  private modals: QueryList<VanillaModalComponent>;

  public canOpen: boolean;
  public canClose: boolean;

  ngOnInit(): void {
    this.canOpen = this.canClose = true;
  }

  openFirstModal(): void {
    if (this.modals && this.modals.toArray().length > 0) {
      this.previousModal = this.modals.toArray()[0];
      this.modals.toArray()[0].open();
    }
  }

  openSecondModal(): void {
    if (this.modals && this.modals.toArray().length > 1) {
      this.previousModal = this.modals.toArray()[1];
      this.modals.toArray()[1].open();
    }
  }

  openThirdModal(): void {
    if (this.modals && this.modals.toArray().length > 2) {
      // Do not store reference to the modal, this is the 'are you sure your sure' modal
      this.modals.toArray()[2].open();
    }
  }

  saveFirstModal(): void {
    if (this.modals && this.modals.toArray().length > 0) {
      this.previousModal = null;
      this.modals.toArray()[0].close();
    }
  }

  saveSecondModal(): void {
    if (this.modals && this.modals.toArray().length > 1) {
      this.previousModal = null;
      this.modals.toArray()[1].close();
    }
  }

  closeThirdModal(): void {
    if (this.modals && this.modals.toArray().length > 2) {
      // Clear the previous modal since they were really sure they wanted to cancel
      this.previousModal = null;
      this.modals.toArray()[2].close();
    }
  }

  cancelFirstModal(): void {
    if (this.modals && this.modals.toArray().length > 2) {
      this.modals.toArray()[0].close();
      this.modals.toArray()[2].open();
    }
  }

  cancelSecondModal(): void {
    if (this.modals && this.modals.toArray().length > 1) {
      this.modals.toArray()[1].close();
      this.modals.toArray()[2].open();
    }
  }

  cancelThirdModal(): void {
    if (this.modals && this.modals.toArray().length > 2) {
      this.modals.toArray()[2].close();

      if (this.previousModal) {
        // Open the previous modal
        this.previousModal.open();
      }
    }
  }

  ngAfterViewInit(): void {
    console.log('Vanilla Modal Ready!');
  }

  onBeforeOpen(whichModal: string): void {
    console.log(`${whichModal} modal onBeforeOpen`);
  }

  onBeforeClose(whichModal: string): void {
    console.log(`${whichModal} modal onBeforeClose`);
  }

  onOpen(whichModal: string): void {
    console.log(`${whichModal} modal onOpen`);
  }

  onClose(whichModal: string): void {
    console.log(`${whichModal} modal onClose`);
  }

  exampleScript = `
@Component({
  template: \`
    <button type="button" class="button button--link" (click)="openFirstModal()">Open First Modal</button>
    <button type="button" class="button button--link" (click)="openSecondModal()">Open Second Modal</button>
    <sprint-vanilla-modal (onBeforeOpen)="onBeforeOpen('first')"
                          (onOpen)="onOpen('first')"
                          (onClose)="onClose('first')"
                          (onBeforeClose)="onBeforeClose('first')"
                          (onCancel)="cancelFirstModal()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="cancelFirstModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>First Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below.
          </div>
          <div class="col-xs-24 pt-10">
            Clicking the close button, clicking the cancel button, clicking outside the modal, or hitting the \`ESC\` key
            will execute the cancelCallback method. It is important to note that clicking outside the modal or using any
            of the close keys like \`ESC\` (or any you have setup in the modal options) are considered a cancellation of
            the modal. However, these two methods of closing the modal will only call your cancel method if you have
            provided it to the Vanilla Modal Component via \`(onCancel)="someMethod()"\`.
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button  button--secondary button--return" (click)="cancelFirstModal()">Cancel</button>
          </div>
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="saveFirstModal()">Save</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
    <sprint-vanilla-modal (onBeforeOpen)="onBeforeOpen('second')"
                          (onOpen)="onOpen('second')"
                          (onClose)="onClose('second')"
                          (onBeforeClose)="onBeforeClose('second')"
                          (onCancel)="cancelSecondModal()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="cancelSecondModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>Second Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below.
          </div>
          <div class="col-xs-24 pt-10">
            Clicking the close button, clicking the cancel button, clicking outside the modal, or hitting the \`ESC\` key
            will execute the cancelCallback method. It is important to note that clicking outside the modal or using any
            of the close keys like \`ESC\` (or any you have setup in the modal options) are considered a cancellation of
            the modal. However, these two methods of closing the modal will only call your cancel method if you have
            provided it to the Vanilla Modal Component via \`(onCancel)="someMethod()"\`.
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button  button--secondary button--return" (click)="cancelSecondModal()">Cancel</button>
          </div>
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="saveSecondModal()">Save</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
    <sprint-vanilla-modal (onBeforeOpen)="onBeforeOpen('third')"
                          (onOpen)="onOpen('third')"
                          (onClose)="onClose('third')"
                          (onBeforeClose)="onBeforeClose('third')"
                          (onCancel)="cancelThirdModal()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="cancelThirdModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>Third Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below.
          </div>
          <div class="col-xs-24 pt-10">
            Clicking the close button, clicking the cancel button, clicking outside the modal, or hitting the \`ESC\` key
            will execute the cancelCallback method. It is important to note that clicking outside the modal or using any
            of the close keys like \`ESC\` (or any you have setup in the modal options) are considered a cancellation of
            the modal. However, these two methods of closing the modal will only call your cancel method if you have
            provided it to the Vanilla Modal Component via \`(onCancel)="someMethod()"\`.
          </div>
          <div class="col-xs-24 pt-10">
            This modal is an example of an interim "are you sure" modal. The cancellation of this modal should re-open
            the previous modal while the OKing of this modal will simply close the modal
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button  button--secondary button--return" (click)="cancelThirdModal()">Cancel</button>
          </div>
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="closeThirdModal()">Ok</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
  \`
})
export class SPAMultipleVanillaModalDemoComponent implements OnInit, AfterViewInit, Demo {
  private previousModal: VanillaModalComponent;
  @ViewChildren(VanillaModalComponent)
  private modals: QueryList<VanillaModalComponent>;
  canOpen: boolean;
  canClose: boolean;

  ngOnInit(): void {
    this.canOpen = this.canClose = true;
  }

  openFirstModal(): void {
    if (this.modals && this.modals.toArray().length > 0) {
      this.previousModal = this.modals.toArray()[0];
      this.modals.toArray()[0].open();
    }
  }

  openSecondModal(): void {
    if (this.modals && this.modals.toArray().length > 1) {
      this.previousModal = this.modals.toArray()[1];
      this.modals.toArray()[1].open();
    }
  }

  openThirdModal(): void {
    if (this.modals && this.modals.toArray().length > 2) {
      // Do not store reference to the modal, this is the 'are you sure your sure' modal
      this.modals.toArray()[2].open();
    }
  }

  saveFirstModal(): void {
    if (this.modals && this.modals.toArray().length > 0) {
      this.previousModal = null;
      this.modals.toArray()[0].close();
    }
  }

  saveSecondModal(): void {
    if (this.modals && this.modals.toArray().length > 1) {
      this.previousModal = null;
      this.modals.toArray()[1].close();
    }
  }

  closeThirdModal(): void {
    if (this.modals && this.modals.toArray().length > 2) {
      // Clear the previous modal since they were really sure they wanted to cancel
      this.previousModal = null;
      this.modals.toArray()[2].close();
    }
  }

  cancelFirstModal(): void {
    if (this.modals && this.modals.toArray().length > 2) {
      this.modals.toArray()[0].close();
      this.modals.toArray()[2].open();
    }
  }

  cancelSecondModal(): void {
    if (this.modals && this.modals.toArray().length > 1) {
      this.modals.toArray()[1].close();
      this.modals.toArray()[2].open();
    }
  }

  cancelThirdModal(): void {
    if (this.modals && this.modals.toArray().length > 2) {
      this.modals.toArray()[2].close();

      if (this.previousModal) {
        // Open the previous modal
        this.previousModal.open();
      }
    }
  }

  ngAfterViewInit(): void {
    console.log('Vanilla Modal Ready!');
  }

  onBeforeOpen(whichModal: string): void {
    console.log(\`\${whichModal} modal onBeforeOpen\`);
  }

  onBeforeClose(whichModal: string): void {
    console.log(\`\${whichModal} modal onBeforeClose\`);
  }

  onOpen(whichModal: string): void {
    console.log(\`\${whichModal} modal onOpen\`);
  }

  onClose(whichModal: string): void {
    console.log(\`\${whichModal} modal onClose\`);
  }
}
  `;
}
