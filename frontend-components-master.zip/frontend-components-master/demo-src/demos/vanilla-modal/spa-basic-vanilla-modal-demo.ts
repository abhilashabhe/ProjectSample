import { Component, AfterViewInit, ViewChild } from '@angular/core';
import { VanillaModalComponent } from '../../../src/sprint-angular-modules/components/vanilla-modal/vanilla-modal.component';

@Component({
  template: `
    <button type="button" class="button button--link" (click)="openBasicModal()">Open Basic Modal</button>
    <sprint-vanilla-modal (onBeforeOpen)="onBeforeOpen()"
                          (onOpen)="onOpen()"
                          (onClose)="onClose()"
                          (onBeforeClose)="onBeforeClose()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="closeBasicModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>Basic Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below.
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="closeBasicModal()">Close</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
  `
})
export class SPABasicVanillaModalDemoComponent implements AfterViewInit {
  static demoName = 'SPA: Basic Vanilla Modal';
  static demoTopic = 'Modals';
  static demoDescription = 'Demo of a basic vanilla modal for SPAs.';

  @ViewChild(VanillaModalComponent)
  private modal: VanillaModalComponent;

  ngAfterViewInit(): void {
    console.log('Vanilla Modal Ready!');
  }

  openBasicModal(): void {
    if (this.modal) {
      this.modal.open();
    }
  }

  closeBasicModal(): void {
    if (this.modal && this.modal.isOpen) {
      this.modal.close();
    }
  }

  onBeforeOpen(): void {
    console.log('onBeforeOpen');
  }

  onBeforeClose(): void {
    console.log('onBeforeClose');
  }

  onOpen(): void {
    console.log('onOpen');
  }

  onClose(): void {
    console.log('onClose');
  }

  exampleScript = `
@Component({
  template: \`
    <button type="button" class="button button--link" (click)="openBasicModal()">Open Basic Modal</button>
    <sprint-vanilla-modal (onBeforeOpen)="onBeforeOpen()"
                          (onOpen)="onOpen()"
                          (onClose)="onClose()"
                          (onBeforeClose)="onBeforeClose()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="closeBasicModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>Basic Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below.
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="closeBasicModal()">Close</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
  \`
})
export class SPABasicVanillaModalDemoComponent implements AfterViewInit, Demo {
  @ViewChild(VanillaModalComponent)
  private modal: VanillaModalComponent;

  ngAfterViewInit(): void {
    console.log('Vanilla Modal Ready!');
  }

  openBasicModal(): void {
    if (this.modal) {
      this.modal.open();
    }
  }

  closeBasicModal(): void {
    if (this.modal && this.modal.isOpen) {
      this.modal.close();
    }
  }

  onBeforeOpen(): void {
    console.log('onBeforeOpen');
  }

  onBeforeClose(): void {
    console.log('onBeforeClose');
  }

  onOpen(): void {
    console.log('onOpen');
  }

  onClose(): void {
    console.log('onClose');
  }
}
  `;
}
