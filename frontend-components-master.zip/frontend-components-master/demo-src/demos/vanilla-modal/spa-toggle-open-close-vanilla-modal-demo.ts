import { Component, OnInit, AfterViewInit, ViewChild } from '@angular/core';
import { VanillaModalComponent } from '../../../src/sprint-angular-modules/components/vanilla-modal/vanilla-modal.component';

@Component({
  template: `
    <button type="button" class="button button--link" (click)="openModal()">Open CanOpen/CanClose Toggle Modal</button>
    <button type="button" class="button button--link" (click)="toggleCanOpen()">Toggle Modal Can Open: {{canOpen}}</button>
    <sprint-vanilla-modal [canOpen]="canOpen"
                          [canClose]="canClose"
                          (onBeforeOpen)="onBeforeOpen()"
                          (onOpen)="onOpen()"
                          (onClose)="onClose()"
                          (onBeforeClose)="onBeforeClose()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="closeModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>Toggle Open/Close Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below....
          </div>
          <div class="col-xs-24 pt-10">
            But only if you have enabled closing of the modal:
          </div>
          <div class="col-xs-24 pt-10">
            <button type="button" class="button button--link" (click)="toggleCanClose()">Toggle Modal Can Close: {{canClose}}</button>
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="closeModal()">Close</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
  `
})
export class SPAToggleOpenCloseVanillaModalDemoComponent implements OnInit, AfterViewInit {
  static demoName = 'SPA: Open/Close Toggle Vanilla Modal';
  static demoTopic = 'Modals';
  static demoDescription = 'Demo of a SPA vanilla modal that can have it\'s ability to open and close toggled on and off.';

  @ViewChild(VanillaModalComponent)
  private modal: VanillaModalComponent;

  public canOpen: boolean;
  public canClose: boolean;

  ngOnInit(): void {
    this.canOpen = this.canClose = true;
  }

  ngAfterViewInit(): void {
    console.log('Vanilla Modal Ready!');
  }

  openModal(): void {
    if (this.modal) {
      this.modal.open();
    }
  }

  closeModal(): void {
    if (this.modal && this.modal.isOpen) {
      this.modal.close();
    }
  }

  toggleCanOpen(): void {
    this.canOpen = !this.canOpen;
  }

  toggleCanClose(): void {
    this.canClose = !this.canClose;
  }

  onBeforeOpen(): void {
    console.log('onBeforeOpen');
  }

  onBeforeClose(): void {
    console.log('onBeforeClose');
  }

  onOpen(): void {
    console.log('onOpen');
  }

  onClose(): void {
    console.log('onClose');
  }

  exampleScript = `
@Component({
  template: \`
    <button type="button" class="button button--link" (click)="openModal($event)">Open CanOpen/CanClose Toggle Modal</button>
    <button type="button" class="button button--link" (click)="toggleCanOpen($event)">Toggle Modal Can Open: {{canOpen}}</button>
    <sprint-vanilla-modal [canOpen]="canOpen"
                          [canClose]="canClose"
                          (onBeforeOpen)="onBeforeOpen()"
                          (onOpen)="onOpen()"
                          (onClose)="onClose()"
                          (onBeforeClose)="onBeforeClose()">
      <button type="button" class="sprint-modal__close" aria-label="Close modal" (click)="closeModal()"></button>
      <div class="container">
        <div class="row">
          <div class="col-xs-24">
            <h1>Toggle Open/Close Modal</h1>
          </div>
          <div class="col-xs-24">
            This modal has been opened by using the \`open\` method of the VanillaModalComponent. You can close this modal
            by clicking outside the modal area, by hitting the \`ESC\` key, by clicking the close button in the top right
            corner of the modal, or by clicking the close button below....
          </div>
          <div class="col-xs-24 pt-10">
            But only if you have enabled closing of the modal:
          </div>
          <div class="col-xs-24 pt-10">
            <button type="button" class="button button--link" (click)="toggleCanClose($event)">Toggle Modal Can Close: {{canClose}}</button>
          </div>
        </div>
        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button" (click)="closeModal()">Close</button>
          </div>
        </div>
      </div>
    </sprint-vanilla-modal>
  \`
})
export class SPABasicVanillaModalDemoComponent implements OnInit, AfterViewInit, Demo {
  @ViewChild(VanillaModalComponent)
  private modal: VanillaModalComponent;
  canOpen: boolean;
  canClose: boolean;

  ngOnInit(): void {
    this.canOpen = this.canClose = true;
  }

  ngAfterViewInit(): void {
    console.log('Vanilla Modal Ready!');
  }

  openModal(): void {
    if (this.modal) {
      this.modal.open();
    }
  }

  closeModal(): void {
    if (this.modal && this.modal.isOpen) {
      this.modal.close();
    }
  }

  toggleCanOpen(): void {
    this.canOpen = !this.canOpen;
  }

  toggleCanClose(): void {
    this.canClose = !this.canClose;
  }

  onBeforeOpen(): void {
    console.log('onBeforeOpen');
  }

  onBeforeClose(): void {
    console.log('onBeforeClose');
  }

  onOpen(): void {
    console.log('onOpen');
  }

  onClose(): void {
    console.log('onClose');
  }
}
  `;
}
