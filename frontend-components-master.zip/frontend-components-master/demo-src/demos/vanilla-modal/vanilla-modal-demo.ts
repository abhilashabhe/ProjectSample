import { Component, OnInit } from '@angular/core';
import * as I from '../../../src/sprint-angular-modules/directives/vanilla-modal/vanilla-modal.interface';

@Component({
    styles: [],
    template: `
      <a href="#modal-1" data-sprint-modal-open>Open Modal 1</a>
      <a href="#modal-2" data-sprint-modal-open>Open Modal 2</a>

      <!-- modal 1 content -->
      <div
          [sprintVanillaModal]="vanillaModalOptions"
          (onTransitionEnd)="onTransitionEnd($event)"
          (onBeforeOpen)="onBeforeOpen($event)"
          (onBeforeClose)="onBeforeClose($event)"
          (onOpen)="onOpen($event)"
          (onClose)="onClose($event)">
        <div id="modal-1" class="sprint-modal__target">
          <div class="sprint-modal__container">
            <h2 class="mt-0">Heading!</h2>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean rhoncus arcu blandit blandit tincidunt. Ut massa odio, cursus ac consectetur et, sodales ac velit. Praesent posuere ligula et eros bibendum maximus sed quis nunc. Duis pulvinar purus hendrerit tempus condimentum. Sed eleifend consequat ligula quis pellentesque. Vestibulum diam nulla, pellentesque in nisi ut, vulputate aliquet augue. Aenean sollicitudin, dolor sit amet accumsan ullamcorper, augue lorem mollis quam, quis rutrum nunc risus quis nisl. Ut diam tellus, egestas id congue vestibulum, molestie quis ligula. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.
            </p>
            <p>
              Curabitur sodales purus id magna venenatis ullamcorper. Nullam tristique eget odio a rutrum. Morbi pellentesque erat at accumsan vehicula. Aliquam sodales erat vitae orci vestibulum eleifend.
            </p>
          </div>
        </div>
      </div>

      <!-- modal 2 content -->
      <div id="modal-2" class="sprint-modal__target">
        <div class="sprint-modal__container">
          Modal 2 Content
        </div>
      </div>

      <
    `
})
export class VanillaModalDemoComponent implements OnInit {
  static demoName = 'Vanilla Modal';
  static demoTopic = 'Modals';
  static demoDescription = 'Demo of the vanilla modal directive';


  public vanillaModalOptions: I.IVanillaModalOptions = {
    modal : '[data-sprint-modal]',
    modalInner : '[data-sprint-modal-inner]',
    modalContent : '[data-sprint-modal-content]',
    open: '[data-sprint-modal-open]',
    close: '[data-sprint-modal-close]',
    clickOutside : false,
    closeKeys: [27],
    transitions: true
  };

  ngOnInit () {
    console.log('Vanilla Modal Ready!');
  }

  onTransitionEnd (event: Event) {
    console.log('onTransitionEnd', event);
  }
  onBeforeOpen (event: Event) {
    console.log('onBeforeOpen', event);
  }
  onBeforeClose (event: Event) {
    console.log('onBeforeClose', event);
  }
  onOpen (event: Event) {
    console.log('onOpen', event);
  }
  onClose (event: Event) {
    console.log('onClose', event);
  }
}
