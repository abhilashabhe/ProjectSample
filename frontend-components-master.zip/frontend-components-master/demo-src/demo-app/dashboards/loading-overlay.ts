/* tslint:disable:component-selector */
import { Component, Input, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'loading-overlay',
  styleUrls: [ './loading-overlay.scss' ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="loading-overlay py-40" [class.is-active]="show">
      <div class="loading-overlay__content">
        <h2 class="text-center">{{message}}</h2>
        <sprint-global-loader></sprint-global-loader>
      </div>
    </div>`
})
export class LoadingOverlayComponent {
  @Input() message: string = '';
  @Input() show: boolean = false;
}
