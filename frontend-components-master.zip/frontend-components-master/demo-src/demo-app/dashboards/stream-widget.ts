/* tslint:disable:component-selector */
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Component, Input, OnInit } from '@angular/core';
import { IServiceLayer, IServiceLayerFactory, IServiceKeys } from '../../../src/aem-components/interfaces/service-layer';
import { ISprintApp } from '../../../src/aem-components/interfaces/aem-bridge/sprint-app.interface';
import { IServiceInput } from '../../../src/aem-components/service-layer/lib';

declare const sprintApp: ISprintApp;

@Component({
  selector: 'stream-widget',
  styleUrls: ['./stream-widget.scss'],
  template: `
  <h4 class="py-10 px-40 bgc--ash-light ma-0"><code>{{serviceKey}}</code> Stream</h4>
  <div style="position: relative"  class="container">
    <loading-overlay
      [message]="'Running ' + serviceKey + ' Stream'"
      [show]="loading$ | async">
    </loading-overlay>

    <div class="row">

      <div class="col-xs-12 pb-40">
        <h6>Stream Input</h6>
        <ng-content></ng-content>
        <pre>{{serviceInput | json}}</pre>

        <div class="row middle-md end-md">
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button type="button" class="button button--sm" (click)="dispatchEvent()">Dispatch Event</button>
          </div>
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button class="button button--sm" (click)="runStream()">Run Stream</button>
          </div>
          <div class="col-xs-24 col-md-reset mb-20 mb-md-0">
            <button class="button button--sm" (click)="runStreamWithCache()">Run Stream with Cache</button>
          </div>
        </div>
      </div>

      <div class="col-xs-12">
        <h6 class="mb-0">Stream Output</h6>
        <button
          type="button"
          class="button button--link button--sm mb-20"
          *ngIf="(output$ | async)?.length > 0"
          (click)="clearOutput.next([])">
          Clear output
        </button>
        <p *ngIf="(output$ | async)?.length < 1">No output yet</p>
        <pre
          *ngFor="let output of (output$ | async)"
          [ngClass]="{'data': output.type === 'data', 'error': output.type ==='error'}">{{output.contents | json}}
        </pre>
      </div>
    </div>
  </div>
  `
})
export class StreamWidgetComponent implements OnInit {
  @Input() serviceKey: IServiceKeys;
  @Input() serviceInput: IServiceInput;

  private serviceLayer$: Observable<IServiceLayer>;
  private clearOutput = new Subject();
  output$: Observable<{type: string, contents: any}[]>;
  loading$: Observable<boolean>;

  ngOnInit() {
    const serviceLayerPromise: Promise<IServiceLayer>
      = new Promise(resolve =>
          sprintApp.getComponentFactory('SprintStreams')
            .then((serviceLayerFactory: IServiceLayerFactory) => resolve(serviceLayerFactory()))
        );

    this.serviceLayer$ = Observable.fromPromise(serviceLayerPromise);

    this.loading$
      = this.serviceLayer$
          .map(serviceLayer => serviceLayer.getLoadingStream(this.serviceKey))
          .mergeAll();

    const errors$
      = this.serviceLayer$
          .map(serviceLayer => serviceLayer.getErrorStream(this.serviceKey))
          .mergeAll()
          .pluck('response', 'data');

    const data$
      = this.serviceLayer$
          .map(serviceLayer => serviceLayer.getStream(this.serviceKey))
          .mergeAll()
          .pluck('data');


    const outputTransformers$
      = Observable.merge(
          data$.map(contents => ({ type: 'data', contents })),
          errors$.map(contents => ({ type: 'error', contents }))
        )
        .map(entry => (
          (existing: any[]): any[] => [entry, ...existing]
        ));

    this.output$
      = Observable.merge(
          outputTransformers$,
          this.clearOutput.mapTo((_: any[]): any[] => [])
        )
        .scan((output: {type: string, contents: any}[], transform) => transform(output), []);
  }

  runStream() {
    this.serviceLayer$
      .map(serviceLayer =>
        serviceLayer.getStreamRunner(this.serviceKey)(this.serviceInput)
      )
      .mergeAll()
      .subscribe();
  }

  runStreamWithCache() {
    this.serviceLayer$
      .map(serviceLayer =>
        serviceLayer.getStreamRunnerWithCache(this.serviceKey)(this.serviceInput)
      )
      .mergeAll()
      .subscribe();
  }

  dispatchEvent() {
    const event: Event = new Event(this.serviceKey);
    event['payload'] = this.serviceInput;
    window.dispatchEvent(event);
  }



}
