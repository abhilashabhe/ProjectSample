import { Component, Type, Input, ViewContainerRef, ComponentFactoryResolver, ViewChild, ReflectiveInjector, ComponentRef } from '@angular/core';

@Component({
  selector: 'sprint-dynamic-demo-component',
  template: `
    <div #dynamicDemoWrapper></div>
  `
})
export class DynamicDemoComponent {

  private currentComponent: ComponentRef<any>;

  @ViewChild('dynamicDemoWrapper', { read: ViewContainerRef })
  dynamicDemoWrapper: ViewContainerRef;

  @Input()
  set component(comp: Type<any>) {
    if (!comp || this.currentComponent) {
      return;
    }

    const factory = this.resolver.resolveComponentFactory(comp);
    const injector = ReflectiveInjector.fromResolvedProviders([], this.dynamicDemoWrapper.parentInjector);
    const component = factory.create(injector);
    this.currentComponent = component;
    this.dynamicDemoWrapper.insert(component.hostView);
  }

  constructor(
    private resolver: ComponentFactoryResolver
  ) {}

}
