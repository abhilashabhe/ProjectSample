import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Demo } from '../../demos';
import { DemoAppService } from '../demo-app.service';

declare const hljs: any;

@Component({
  selector: 'sprint-demo-detail',
  styleUrls: ['./demo-detail.component.scss'],
  template: `
    <ng-template [ngIf]="demoName$ | async">
      <section class="demo-entry mb-20">
        <div class="demo-title py-40 px-40 bgc--purple color--white">
          <h3 class="ma-0">{{demoName$ | async}}</h3>
          <br/>
          <span [textContent]="demoDescription$ | async"></span>
          <div class="mt-10">
            <code>{{demoTopic$ | async}}</code>
          </div>
        </div>

        <div class="demo-container mb-10 pb-10">
          <sprint-dynamic-demo-component [component]="demo$ | async"></sprint-dynamic-demo-component>
        </div>

        <div class="demo-code border-bottom mb-1" *ngIf="(demo$ | async).exampleScript">
          <span class="demo-code--title">Example Script</span>
          <pre [innerHTML]="highlight('javascript', (demo$ | async).exampleScript.trim())"></pre>
        </div>
      </section>
    </ng-template>
  `
})
export class DemoDetailComponent {
  demo$: Observable<Demo>;
  demoTopic$: Observable<string>;
  demoName$: Observable<string>;
  demoDescription$: Observable<string>;

  constructor (
    private route: ActivatedRoute,
    private demoService: DemoAppService
  ) {
    this.demo$ = this.route.params
      .filter(params => params['name'])
      .map(params => decodeURIComponent(params['name']))
      .distinctUntilChanged()
      .mergeMap(name => this.demoService.getDemoByName(name))
      .publishReplay(1)
      .refCount();

    this.demoTopic$ = this.demo$.map(demo => demo.demoTopic || '');
    this.demoName$ = this.demo$.map(demo => demo.demoName || '');
    this.demoDescription$ = this.demo$.map(demo => demo.demoDescription || '');
  }

  highlight (lang: string, code: string) {
    return typeof hljs === 'undefined'
      ? code.replace(/</g, '&lt;')
      : hljs.highlight(lang, code).value;
  }
}
