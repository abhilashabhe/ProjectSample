import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { DEMO_DECLARATIONS, Demo } from '../demos';

import { I18nService } from '../../src/sprint-angular-modules';

@Injectable()
export class DemoAppService {

  demos$: Observable<Demo[]>;
  demosByTopic$: Observable<{ [demoTopic: string]: Demo[] }>;
  demoTopics$: Observable<string[]>;

  constructor(
    public i18nService: I18nService
  ) {
    this.demos$ = Observable.of(DEMO_DECLARATIONS).share();

    const unique: (<T>(list: T[]) => T[]) = <T>(list: T[]) => Array.from(new Set(list));

    this.demosByTopic$
      = this.demos$
          .map((demos: Demo[]) =>
            unique(demos.map(d => d.demoTopic))
              .reduce(
                (groups, demoTopic) =>
                  Object.assign({}, groups, { [demoTopic]: demos.filter(d => d.demoTopic === demoTopic) }),
                {}
              )
          );

    this.demoTopics$ = this.demosByTopic$.map(subs => Object.keys(subs));
  }

  getDemoByName(name: string): Observable<Demo> {
    return this.demos$
      .mergeMap(demos => Observable.from(demos))
      .find(demo => name === demo.demoName);
  }
}
