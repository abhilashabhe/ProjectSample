export * from './demo-detail/demo-detail.component';
export * from './demo-detail/dynamic-demo.component';
export * from './demo-index/demo-index.component';
export * from './demo-app.service';
export * from './demo-app.component';
