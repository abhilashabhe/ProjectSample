import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule } from '@angular/router';

/* Shared modules */
import {
  SprintAngularPipesModule,
  SprintAngularI18nModule,
  SprintAngularDirectivesModule,
  SprintAngularComponentsModule,
  SprintAngularFormsModule,
  GlobalLoaderComponent } from '../../src/sprint-angular-modules';

/* Demo app components & providers */
import { DemoAppComponent } from './demo-app.component';
import { DemoAppService } from './demo-app.service';
import { DemoDetailComponent, DynamicDemoComponent } from './demo-detail';
import { DemoIndexComponent } from './demo-index/demo-index.component';
import { StreamWidgetComponent } from './dashboards/stream-widget';
import { FormAnalyzerComponent } from './forms/form-analyzer.component';
import { LoadingOverlayComponent } from './dashboards/loading-overlay';

/* Demo declarations (components, directives & pipes) */
import { DEMO_DECLARATIONS } from '../demos';

const routes: Routes =
  [ { path: '', component: DemoIndexComponent }
  , { path: 'demo/:name', component: DemoDetailComponent }
  ];

@NgModule({
  imports:
    [ RouterModule.forRoot(routes)
    , BrowserModule
    , FormsModule
    , ReactiveFormsModule
    , HttpModule
    , SprintAngularPipesModule
    , SprintAngularI18nModule
    , SprintAngularDirectivesModule
    , SprintAngularComponentsModule
    , SprintAngularFormsModule
    ],
  entryComponents:
    [ ...DEMO_DECLARATIONS
    , GlobalLoaderComponent
    ],
  declarations:
    [ DemoAppComponent
    , DemoIndexComponent
    , DemoDetailComponent
    , DynamicDemoComponent
    , StreamWidgetComponent
    , LoadingOverlayComponent
    , FormAnalyzerComponent
    , ...DEMO_DECLARATIONS
    ],
  providers: [ DemoAppService ],
  bootstrap: [ DemoAppComponent ]
})
export class DemoAppModule {}
