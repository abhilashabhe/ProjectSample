/* tslint:disable:component-selector */
import { Component, Input, AfterViewInit } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';


@Component({
  selector: 'form-analyzer',
  styleUrls: ['form-analyzer.component.scss'],
  template: `
    <div class="row">
      <div class="col-xs-8">
        <h5>Form Flags</h5>
        <div *ngIf="form.invalid" class="formstate formstate--danger">
          <i class="ico ico--thumbs-down"></i>Invalid
        </div>
        <div *ngIf="form.valid" class="formstate formstate--info">
          <i class="ico ico--thumbs-up"></i>Valid
        </div>
        <div *ngIf="form.dirty" class="formstate formstate--danger">
          <i class="ico ico--incorrect"></i>Dirty
        </div>
        <div *ngIf="form.pristine" class="formstate formstate--info">
          <i class="ico ico--valid"></i>Pristine
        </div>
        <div *ngIf="form.touched" class="formstate formstate--danger">
          <i class="ico ico--incorrect"></i>Touched
        </div>
        <div *ngIf="form.untouched" class="formstate formstate--info">
          <i class="ico ico--valid"></i>Untouched
        </div>
      </div>
      <div class="col-xs-10">
        <h5>Form Value</h5>
        <pre>{{form.value | json}}</pre>
        <h5>Form Value Changes</h5>
        <pre>{{form.valueChanges | async | json}}</pre>
      </div>
      <div class="col-xs-6">
        <h5>Form Actions</h5>
        <button
          (click)="form.reset()"
          type="button" class="button button--sm">
          Reset
        </button>
      </div>
    </div>
    <form-analyzer *ngFor="let control of childControls" [form]="control"></form-analyzer>
  `
})
export class FormAnalyzerComponent implements AfterViewInit {
  @Input() form: AbstractControl;
  childControls: AbstractControl[] = [];

  ngAfterViewInit() {
    if (!this.form || !(this.form instanceof AbstractControl)) {
      throw new Error(`The FormAnalyzerComponent requires a [form] input attribute of type AbstractControl!`);
    }
    if (this.form instanceof FormGroup) {
      this.childControls = Object.values(this.form.controls);
    }
  }
}
