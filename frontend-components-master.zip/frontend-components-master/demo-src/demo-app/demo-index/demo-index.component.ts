import { Component } from '@angular/core';
import { DemoAppService } from '../demo-app.service';
import { Demo } from '../../demos/demos.declarations';
import { Observable } from 'rxjs/Observable';

@Component({
  selector: 'sprint-demo-index',
  template: `
    <div class="container-md">
      <h2>Components</h2>
      <div *ngFor="let subjectPath of (demoTopics$ | async)" class="di-entry pb-10 border-bottom">
        <h3 class="mb-0">
          {{ (demosByTopic$ | async)[subjectPath][0].demoGroupName }}
        </h3>
        <div class="my-10">
          <code>{{ subjectPath }}</code>
        </div>
        <div style="opacity: 0.5;">
          [
            <a
              *ngFor="let demo of (demosByTopic$ | async)[subjectPath]"
              class="px-5"
              [routerLink]="['demo/', encode(demo.demoName)]">
              {{ demo.demoName }}
            </a>
          ]
        </div>
      </div>
    </div>
  `
})
export class DemoIndexComponent {
  public demoTopics$: Observable<string[]>;
  public demosByTopic$: Observable<{ [path: string]: Demo[] }>;

  constructor(private demoService: DemoAppService) {
    this.demoTopics$ = this.demoService.demoTopics$;
    this.demosByTopic$ = this.demoService.demosByTopic$;
  }

  encode(str: string) {
    return encodeURIComponent(str).replace(/\./g, '%2E');
  }
}
