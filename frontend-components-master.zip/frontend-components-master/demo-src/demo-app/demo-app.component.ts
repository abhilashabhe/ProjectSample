import { Component } from '@angular/core';

@Component({
  selector: 'sprint-demo-app',
  template: `
    <div class="bgc--gray-dark">
      <a [routerLink]="['']">
        <h4 class="color--white px-40 py-10 my-0">Home</h4>
      </a>
    </div>
    <router-outlet></router-outlet>`
})
export class DemoAppComponent {}
