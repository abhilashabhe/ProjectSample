import 'intl';
import 'intl/locale-data/jsonp/en.js';
import 'intl/locale-data/jsonp/es.js';
import 'core-js/es6';
import 'core-js/es7';
import 'zone.js/dist/zone';
import 'ts-helpers';
