'use strict';

var path = require('path');
var webpack = require('webpack');
var webpackMerge = require('webpack-merge'); // used to merge webpack configs

module.exports = function (config) {
  /**
   * Load the base karma config onto the config object.
   */
  require('@sprint/frontend-config/config/common/karma/karma.conf')(config);

  /**
   * We need to add a preprocessor entry for each webpack source directory. If all source code is contained within a single
   * source directory, there should only be one entry. However, some projects may build multiple applications from different
   * source directories. Be sure to list each one of those here. These source directories should contain the following
   * preprocessor:
   *   webpack: to process the source directory with webpack (webpack entry should exist in webpack config)
   *   sourcemap: to properly load source maps for code coverage
   *   coverage: to perform code coverage calculations/reporting
   */
  config.preprocessors = {
    './src/test.ts': [
      'webpack',
      'sourcemap'
    ]
  };
  config.files = [
    // Global scripts
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/rxjs/5.3.0/Rx.min.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/lodash.js/4.17.4/lodash.min.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.2/jquery.min.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/js-cookie/2.1.3/js.cookie.min.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.2/moment.min.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.2/locale/en-ca.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.15.2/locale/es.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/moment-timezone/0.5.7/moment-timezone-with-data.min.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.12.4/js/standalone/selectize.min.js', watched: false },
    { pattern: 'https://cdnjs.cloudflare.com/ajax/libs/vanilla-modal/1.6.1/index.min.js', watched: false },
    // Other project imports
    { pattern: './assets/styles/global.css', watched: false },
    { pattern: './assets/fonts/**/*', included: false, watched: false },
    { pattern: './assets/images/**/*', included: false, watched: false },
    { pattern: './assets/svgs/**/*', included: false, watched: false },
    // Project scripts
    { pattern: './node_modules/@sprint/frontend-config/config/common/karma/karma-shim.js', watched: false },
    { pattern: './.frontend-config/generated-scripts/global-shared-links.js', watched: false },
    { pattern: './src/test.ts', watched: false }
  ];

  /**
   * We must assign a webpack config object to the webpack property of the karma configuration object. However, not all
   * the plugins and options for webpack are compatible with karma. For that reason, we build a separate webpack
   * configuration for karma, separate of the webpack.config file in the root of the project.
   */
  var buildEnvironment = require('@sprint/frontend-config').getBuildEnvironment({
    projectRoot: path.resolve(__dirname)
  });
  var baseWebpackConfig = require('@sprint/frontend-config/config/common/webpack/webpack.common.js')(buildEnvironment);

  var projectWebpackConfig = {
    /**
     * Change dev tool to inline source maps to support code coverage mapping to TS source.
     */
    devtool: 'inline-source-map',

    module: {
      rules: [
        {
          enforce: 'pre',
          test: /\.js$/,
          exclude: [
            /node_modules/
          ],
          use: [
            {
              loader: 'source-map-loader'
            }
          ]
        },

        {
          test: /\.ts$/,
          exclude: [
            /\.e2e\.ts$/
          ],
          use: [
            {
              loader: 'awesome-typescript-loader',
              options: {
                // use inline sourcemaps for "karma-remap-coverage" reporter
                sourceMap: false,
                inlineSourceMap: true,
                module: 'commonjs'
              }
            },
            {
              loader: 'angular2-template-loader'
            }
          ]
        },

        {
          test: /\.html$/,
          use: [
            {
              loader: 'html-loader'
            }
          ]
        }
      ]
    },
    plugins: [
      new webpack.ProgressPlugin(),
      new webpack.SourceMapDevToolPlugin({
        filename: null, // if no value is provided the sourcemap is inlined
        test: /\.(ts|js)($|\?)/i // process .js and .ts files only
      })
    ],
    performance: {
      hints: false
    }
  };

  config.webpack = webpackMerge.smart(baseWebpackConfig, projectWebpackConfig);

  // Change settings to enable chrome based debugging of the tests
  config.reporters = ['mocha'];
  config.autoWatch = true;
  config.browsers = ['Chrome_without_security'];
  config.singleRun = false;

  if (buildEnvironment.apiEndpoint) {
    config.proxyValidateSSL = false;
    config.proxies = {
      '/api/': {
        'target': buildEnvironment.apiEndpoint + '/api/',
        'secure': false,
        'changeOrigin': true,
        'configure': function (proxy) {
          proxy.on('proxyRes', function (proxyRes) {
            if (proxyRes.statusCode === 302) {
              proxyRes.statusCode = 200;
            }
          });
        }
      },
      '/etc/': {
        'target': buildEnvironment.apiEndpoint + '/etc/',
        'secure': false,
        'changeOrigin': true
      },
      '/content/': {
        'target': buildEnvironment.apiEndpoint + '/content/',
        'secure': false,
        'changeOrigin': true
      },
      '/mysprint/': {
        'target': buildEnvironment.apiEndpoint + '/mysprint/',
        'secure': false,
        'changeOrigin': true
      }
    };
  }

  return config.set(config);
};
