import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import { DEVICE_SERVICE } from '../interfaces/device-service';
import factory from './device-service';

declare var sprintApp: ISprintApp;

(function init() {
  sprintApp.attachComponentFactory(DEVICE_SERVICE, factory);
})();
