import { Observable } from 'rxjs/Observable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import {DeviceService} from './device-service';
import factory from '../service-layer/service-layer';
import * as location from '../location-service/location-service';
import { IServiceLayer } from '../interfaces/service-layer/index';
import {IDeviceService, DeviceInfo, DeviceContractInfo, DeviceCreditInfo} from '../interfaces/device-service/index';
import {ISprintApp, AuthModule} from '../interfaces/aem-bridge/sprint-app.interface';
import Mocks from './device-service-mocks';
import * as Schemas from '../../../src/aem-components/interfaces/service-layer/schemas';
import {ILocationService} from '../interfaces/location-service/index';

let getStreamRunnerWithCacheData: any;
const fakeMethods = {
  streamRunnerWithCacheParamFunc: (params: any) => {
    console.log('streamRunnerWithCacheParamFunc called with: ', params);
    return Observable.of({
      data: getStreamRunnerWithCacheData
    });
  }
};

declare const sprintApp: ISprintApp;

sprintApp.authModule = (sprintApp.authModule || {}) as AuthModule;
sprintApp.authModule.getUsersAPIResponse = (): any => [];
sprintApp.authModule.getSessionAPIResponse = () => null;
sprintApp.authModule.isAuthenticated = () => false;

describe('Device Service Loaded with Test Data', () => {
  let deviceService: IDeviceService;
  let serviceLayer: IServiceLayer;
  let locationService: ILocationService;
  const mocks: Mocks = new Mocks();
  let streamRunnerWithCacheSpy: any;
  const csaSubject: BehaviorSubject<Schemas.CustomerServiceArea> = new BehaviorSubject<Schemas.CustomerServiceArea>(mocks.testCSA);

  beforeEach(function() {
    serviceLayer = factory();
    locationService = location.default();

    locationService.CSAObservable = csaSubject.publishReplay(1);
    locationService.CSAObservable.connect();

    // fake streams
    spyOn(fakeMethods, 'streamRunnerWithCacheParamFunc').and.callThrough();
    spyOn(serviceLayer, 'getStream').and.callFake((stream: string) => {

      let data: any;
      switch (stream) {
        case 'getDevice':
          data = mocks.testDevice;
          break;
        case 'getDevicePrices':
          data = mocks.testDevicePrices;
          break;
        case 'getPlans':
          data = mocks.testDevicePlans;
          break;
        case 'getServices':
          data = mocks.testDeviceServices;
          break;
        default:
          data = {};
          break;
      }
      return Observable.of({
        data: data
      });
    });

    streamRunnerWithCacheSpy = spyOn(serviceLayer, 'getStreamRunnerWithCache').and.callFake((stream: string) => {

      console.log('getStreamRunnerWithCache called for stream: ', stream);
      switch (stream) {
        case 'getDevice':
          getStreamRunnerWithCacheData = mocks.testDevice;
          break;
        case 'getDevicePrices':
          getStreamRunnerWithCacheData = mocks.testDevicePrices;
          break;
        case 'getPlans':
          getStreamRunnerWithCacheData = mocks.testDevicePlans;
          break;
        case 'getServices':
          getStreamRunnerWithCacheData = mocks.testDeviceServices;
          break;
        default:
          getStreamRunnerWithCacheData = {};
          break;
      }

      return fakeMethods.streamRunnerWithCacheParamFunc;
    });

    spyOn(locationService, 'getCSA').and.callFake(() => {
      console.log('faking getCSA');
    });

    deviceService = new DeviceService();

    Object.defineProperty(deviceService, 'serviceLayerPromise', new Promise( () => {
      return serviceLayer;
    }));
    Object.defineProperty(deviceService, 'locationServicePromise', new Promise( () => {
      return locationService;
    }));
  });

  it('should load', () => {
    expect(deviceService).toBeDefined();
  });

  it('should set device info', (done) => {

    deviceService.setDeviceInfo(mocks.testDeviceInfo);
    deviceService.deviceInfo$.take(1).subscribe( (deviceInfo: DeviceInfo) => {
      expect(deviceInfo).toEqual(mocks.testDeviceInfo);
      done();
    });
  });

  it('should set device contract', (done) => {

    deviceService.setDeviceContract(mocks.testDeviceContractInfo);
    deviceService.deviceContract$.take(1).subscribe( (deviceContract: DeviceContractInfo) => {
      expect(deviceContract).toEqual(mocks.testDeviceContractInfo);
      done();
    });
  });

  it('should set device credit', (done) => {

    deviceService.setDeviceCreditInfo(mocks.testDeviceCreditInfo);
    deviceService.deviceCredit$.take(1).subscribe( (deviceCredit: DeviceCreditInfo) => {
      expect(deviceCredit).toEqual(mocks.testDeviceCreditInfo);
      done();
    });
  });

  it('should set device plan', (done) => {

    deviceService.setDevicePlan(mocks.testDevicePlan);
    deviceService.devicePlan$.take(1).subscribe( (plan: Schemas.BaseRequestPlan) => {
      expect(plan).toEqual(mocks.testDevicePlan);
      done();
    });
  });

  it('should set device services', (done) => {

    deviceService.setDeviceServices(mocks.testDeviceServicesArray);
    deviceService.services$.take(1).subscribe( (services: Schemas.BaseRequestService[]) => {
      expect(services).toEqual(mocks.testDeviceServicesArray);
      done();
    });
  });

  it('should set device info and call device details api', (done) => {
    deviceService.setDeviceInfo(mocks.testDeviceInfo);

    deviceService.getDeviceDetails().take(1).subscribe( (device: Schemas.Device) => {
      expect(device).toEqual(mocks.testDevice);

      expect(serviceLayer.getStreamRunnerWithCache).toHaveBeenCalledWith('getDevice');
      expect(fakeMethods.streamRunnerWithCacheParamFunc).toHaveBeenCalledWith({
        pathParams: {
          deviceId: '12345678'
        }
      });

      done();
    });
  });

  it('should set device info and device credit and call device pricing api', (done) => {
    deviceService.setDeviceInfo(mocks.testDeviceInfo);
    deviceService.setDeviceCreditInfo(mocks.testDeviceCreditInfo);

    deviceService.getDevicePricing().take(1).subscribe( (devicePricing: Schemas.DevicePrices) => {
      expect(devicePricing).toEqual(mocks.testDevicePrices);
      expect(serviceLayer.getStreamRunnerWithCache).toHaveBeenCalledWith('getDevicePrices');
      expect(fakeMethods.streamRunnerWithCacheParamFunc).toHaveBeenCalledWith({
        pathParams: {
          deviceId: '12345678'
        },
        queryParams: {
          accountType: 'I',
          accountSubType: 'I',
          creditClass: 'A'
        }
      });

      done();
    });
  });

  it('should set device info and device contract and call device pricing api', (done) => {

    deviceService.setDeviceInfo(mocks.testDeviceInfo);
    deviceService.setDeviceContract(mocks.testDeviceContractInfo);

    deviceService.getDevicePlans().take(1).subscribe( (plans: Schemas.Plan[]) => {
      expect(plans).toEqual(mocks.testDevicePlans);
      expect(serviceLayer.getStreamRunnerWithCache).toHaveBeenCalledWith('getPlans');
      expect(fakeMethods.streamRunnerWithCacheParamFunc).toHaveBeenCalledWith({
        queryParams: {
          deviceId: '12345678',
          accountType: 'I',
          accountSubType: 'I',
          csa: mocks.testCSA.csaCode,
          deviceSaleType: mocks.testDeviceContractInfo.deviceSaleType
        }
      });
      done();
    });
  });

  it('should set device info, device credit, and device plan and call device services api', (done) => {

    deviceService.setDeviceInfo(mocks.testDeviceInfo);
    deviceService.setDeviceCreditInfo(mocks.testDeviceCreditInfo);
    deviceService.setDevicePlan(mocks.testDevicePlan);

    deviceService.getDeviceServices('GROSS_ADD').take(1).subscribe( (services: Schemas.Service[]) => {
      expect(services).toEqual(mocks.testDeviceServices);
      expect(serviceLayer.getStreamRunnerWithCache).toHaveBeenCalledWith('getServices');
      expect(fakeMethods.streamRunnerWithCacheParamFunc).toHaveBeenCalledWith({
        queryParams: {
          deviceId: '12345678',
          csa: mocks.testCSA.csaCode,
          accountType: 'I',
          accountSubType: 'I',
          planSoc: mocks.testDevicePlan.planSOCSKU,
          creditClass: mocks.testDeviceCreditInfo.value,
          flow: 'GROSS_ADD'
        }
      });
      done();
    });
  });
});
