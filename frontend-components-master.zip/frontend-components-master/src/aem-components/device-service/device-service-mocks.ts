import * as Schemas from '../interfaces/service-layer/schemas';
import {DeviceInfo, DeviceContractInfo, DeviceCreditInfo} from '../interfaces/device-service/index';

export default class Mocks {

  testCSA: Schemas.CustomerServiceArea = {
    csaCode: 'KC66',
    zipCode: '66203'
  };

  testDeviceInfo: DeviceInfo = {
    color: 'Silver',
    storage: '32',
    ensembleId: '12345678'
  };

  testDevice: Schemas.Device = {
    id: '12345678'
  };

  testDeviceContractInfo: DeviceContractInfo = {
    contractInfo: {
      contractId: '0-yr-IB'
    },
    offerGroupInfo: {
      offerGroupCode: 'testCODE'
    },
    deviceSaleType: 'LEASE'
  };

  testDeviceCreditInfo: DeviceCreditInfo = {
    value: 'A',
    display: 'This is good credit'
  };

  testDevicePlan: Schemas.BaseRequestPlan = {

  };

  testDeviceService: Schemas.BaseRequestService = {

  };

  testDeviceServiceAdditional: Schemas.BaseRequestService = {

  };

  testDeviceServicesArray: Schemas.BaseRequestService[] = [
    this.testDeviceService,
    this.testDeviceServiceAdditional
  ];

  testDevicePrices: Schemas.DevicePrices = {
    id: '12345',
    purchaseTypes: []
  };

  testDevicePlans: Schemas.Plan[] = [

  ];

  testDeviceServices: Schemas.Service[] = [

  ];
}
