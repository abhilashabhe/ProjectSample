import { Observable } from 'rxjs/Observable';
import { ConnectableObservable } from 'rxjs/observable/ConnectableObservable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import {
  IDeviceService, IDeviceServiceFactory, DeviceContractInfo,
  DeviceInfo, DeviceCreditInfo
} from '../interfaces/device-service/index';
import {IServiceLayer, IServiceLayerFactory, SERVICE_LAYER} from '../interfaces/service-layer/index';
import * as Schemas from '../interfaces/service-layer/schemas/index';
import {ILocationService, ILocationServiceFactory, LOCATION_SERVICE} from '../interfaces/location-service/index';
import {CustomerServiceArea} from '../interfaces/service-layer/schemas/customer-service-areas/customer-service-areas.interface';
import {IGetAccountPlansRequest} from '../interfaces/service-layer/schemas/plans/plans.api-requests.interfaces';

declare const sprintApp: ISprintApp;

export class DeviceService implements IDeviceService {

  deviceInfo$: Observable<DeviceInfo | null>;
  deviceContract$: Observable<DeviceContractInfo | null >;
  deviceCredit$: Observable<DeviceCreditInfo | null>;
  devicePlan$: Observable<Schemas.BaseRequestPlan | null>;
  services$: Observable<Schemas.BaseRequestService[] | null>;
  deviceStream$: ConnectableObservable<Schemas.Device>;
  plansStream$: ConnectableObservable<Schemas.Plan[]>;
  pricingStream$: ConnectableObservable<Schemas.DevicePrices>;
  servicesStream$: ConnectableObservable<Schemas.Service[]>;
  customerServiceArea$: Observable<CustomerServiceArea>;
  deviceQuantity$: Observable<number>;

  private deviceInfo: DeviceInfo;
  private deviceContract: DeviceContractInfo;
  private deviceCredit: DeviceCreditInfo;
  private devicePlan: Schemas.BaseRequestPlan;
  private deviceServices: Schemas.BaseRequestService[];
  private deviceUpdatedSubject = new BehaviorSubject<DeviceInfo | null>(null);
  private deviceContractUpdatedSubject = new BehaviorSubject<DeviceContractInfo | null>(null);
  private deviceCreditInfoUpdatedSubject = new BehaviorSubject<DeviceCreditInfo | null>(null);
  private planUpdatedSubject = new BehaviorSubject<Schemas.BaseRequestPlan | null>(null);
  private servicesUpdatedSubject = new BehaviorSubject<Schemas.BaseRequestService[] | null>(null);
  private locationService$: Observable<ILocationService>;
  private serviceLayer$: Observable<IServiceLayer>;
  private user: Schemas.Session;
  private ban: string;
  private isAuthenticated: boolean;
  private deviceQuantitySubject = new BehaviorSubject<number | null>(null);

  static serviceLayerPromise(): Promise<IServiceLayer> {
    return sprintApp.getComponentFactory<IServiceLayerFactory>(SERVICE_LAYER)
      .then((serviceLayerFactory: IServiceLayerFactory) => serviceLayerFactory());
  }

  static locationServicePromise(): Promise<ILocationService> {
    return sprintApp.getComponentFactory<ILocationServiceFactory>(LOCATION_SERVICE)
      .then((locationServiceFactory: ILocationServiceFactory) => locationServiceFactory());
  }

  constructor() {
    // set user data
    this.user = sprintApp.authModule!.getUser();
    this.isAuthenticated = sprintApp.authModule!.isAuthenticated();

    if (this.isAuthenticated) {
      const users = sprintApp.authModule!.getUsersAPIResponse();
      const authUser = (users && users.length ? users[0] : {});
      const accountSecurityContexts = authUser.accountSecurityContexts;
      this.ban = (accountSecurityContexts && accountSecurityContexts.length ? accountSecurityContexts[0].accountId! : '');
    }

    if (!this.user) {
      this.user = {};
    }

    // if user attributes is empty, set default
    if (!this.user.userAttributes) {
      this.user.userAttributes = {
        accountType: 'I',
        accountSubType: 'I'
      };
    }

    this.serviceLayer$ = Observable.fromPromise(DeviceService.serviceLayerPromise());
    this.locationService$ = Observable.fromPromise(DeviceService.locationServicePromise());

    this.customerServiceArea$ = this.locationService$
      .mergeMap( (locationService) => {
        locationService.getCSA();
        return locationService.CSAObservable;
      });

    this.deviceStream$ = this.serviceLayer$
      .mergeMap( (serviceLayer) => {
        return serviceLayer.getStream('getDevice');
      })
      .map((response: { data: Schemas.Device }) => response.data)
      .publishReplay(1);

    this.deviceStream$.connect();

    this.plansStream$ = this.serviceLayer$
      .mergeMap( (serviceLayer) => {
        return serviceLayer.getStream('getPlans');
      })
      .map((response: { data: Schemas.Plan[] }) => response.data)
      .publishReplay(1);

    this.plansStream$.connect();

    this.pricingStream$ = this.serviceLayer$
      .mergeMap( (serviceLayer) => {
        return serviceLayer.getStream('getDevicePrices');
      })
      .map((response: { data: Schemas.DevicePrices }) => response.data)
      .publishReplay(1);

    this.pricingStream$.connect();

    this.servicesStream$ = this.serviceLayer$
      .mergeMap( (serviceLayer) => {
        return serviceLayer.getStream('getServices');
      })
      .map((response: { data: Schemas.Service[] }) => response.data)
      .publishReplay(1);

    this.servicesStream$.connect();

    // connect observables
    this.deviceInfo$ = this.deviceUpdatedSubject.asObservable().filter( (deviceInfo: DeviceInfo) => !!(deviceInfo));
    this.deviceContract$ = this.deviceContractUpdatedSubject.asObservable().filter( (deviceContract: DeviceContractInfo) => !!(deviceContract));
    this.deviceCredit$ = this.deviceCreditInfoUpdatedSubject.asObservable().filter( (deviceCredit: DeviceCreditInfo) => !!(deviceCredit));
    this.devicePlan$ = this.planUpdatedSubject.asObservable().filter( (plan: Schemas.BaseRequestPlan) => !!(plan));
    this.services$ = this.servicesUpdatedSubject.asObservable().filter( (services: Schemas.BaseRequestService[]) => !!(services));
    this.deviceQuantity$ = this.deviceQuantitySubject.asObservable().filter( (deviceQuantity: number) => !!(deviceQuantity));
  }

  /**
   * method to set device
   * @param device
   */
  setDeviceInfo(device: DeviceInfo) {
    this.deviceInfo = Object.assign({}, device);
    this.deviceUpdatedSubject.next(device);
  }

  /**
   * method to set device contract
   * @param contract
   */
  setDeviceContract(contract: DeviceContractInfo) {
    this.deviceContract = Object.assign({}, contract);
    this.deviceContractUpdatedSubject.next(contract);
  }

  /**
   *
   * @param credit
   */
  setDeviceCreditInfo(credit: DeviceCreditInfo) {
    this.deviceCredit = credit;
    this.deviceCreditInfoUpdatedSubject.next(credit);
  }

  /**
   * method to set device plan
   * @param plan
   */
  setDevicePlan(plan: Schemas.BaseRequestPlan) {
    this.devicePlan = Object.assign({},  plan);
    this.planUpdatedSubject.next(plan);
  }

  /**
   * method to set device services
   * @param services
   */
  setDeviceServices(services: Schemas.BaseRequestService[]) {
    this.deviceServices = [...services];
    this.servicesUpdatedSubject.next(services);
  }

  /**
   * method to set device quatity
   * @param quantity
   */
  setDeviceQuantity(deviceQuantity: number) {
    this.deviceQuantitySubject.next(deviceQuantity);
  }

  /**
   * method to get device details from api
   * @returns {any}
   */
  getDeviceDetails(): Observable<Schemas.Device> {
    return Observable.combineLatest(
      this.serviceLayer$,
      this.deviceInfo$
    )
      .take(1)
      .mergeMap( ([serviceLayer, deviceInfo]) => {
        const params: Schemas.IGetDeviceRequest = {
          pathParams: {
            deviceId: deviceInfo!.ensembleId!
          }
        };
        return serviceLayer.getStreamRunnerWithCache('getDevice')(params)
          .pluck('data');
      });
  }

  /**
   * method to retrieve device prices
   * @param params
   * @returns {any}
   */
  getDevicePricing(flow: string, subscriptionId: string): Observable<Schemas.DevicePrices> {
    return Observable.combineLatest(
      this.serviceLayer$,
      this.deviceInfo$,
      this.deviceCredit$
    )
      .take(1)
      .mergeMap( ([serviceLayer, deviceInfo, deviceCredit]) => {
        const params: Schemas.IGetDevicePricesRequest = {
          pathParams: {
            deviceId: deviceInfo!.ensembleId!
          },
          queryParams: {
            accountType: this.user.userAttributes!.accountType,
            accountSubType: this.user.userAttributes!.accountSubType,
            creditClass: deviceCredit!.value
          }
        };

        if (flow) {
          params.queryParams.flow = flow;
        }

        if (subscriptionId) {
          params.queryParams.subscriptionId = subscriptionId;
        }
        return serviceLayer.getStreamRunnerWithCache('getDevicePrices')(params)
          .map( (res): Schemas.DevicePrices => res.data);
      });
  }

  /**
   * method to get plans for a device
   * @param params
   * @returns {any}
   */
  getDevicePlans(): Observable<Schemas.Plan[]> {
    return Observable.combineLatest(
      this.serviceLayer$,
      this.deviceInfo$,
      this.customerServiceArea$,
      this.deviceContract$
    )
      .take(1)
      .mergeMap( ([serviceLayer, deviceInfo, CSA, deviceContract]) => {
        return serviceLayer.getStreamRunnerWithCache('getPlans')({
          queryParams: {
            deviceId: deviceInfo!.ensembleId,
            accountType: this.user.userAttributes!.accountType,
            accountSubType: this.user.userAttributes!.accountSubType,
            csa: CSA.csaCode,
            deviceSaleType: deviceContract!.deviceSaleType
          }
        })
        .map( (res): Schemas.Plan[] => res.data);
      });
  }

  getAccountPlans(): Observable<Schemas.AccountPlansLookup> {

    return Observable.combineLatest(
      this.serviceLayer$,
      this.deviceInfo$,
      this.deviceContract$,
      this.deviceQuantity$,
      (serviceLayer, deviceInfo, deviceContract, deviceQuantity) => ({serviceLayer, deviceInfo, deviceContract, deviceQuantity})
    )
      .take(1)
      .mergeMap( ({serviceLayer, deviceInfo, deviceContract, deviceQuantity}) => {
        const request: IGetAccountPlansRequest = {
          data: {},
          queryParams: {
            lineDetail: {
              lineType: 'GROSS_ADD',
              itemID: deviceInfo!.ensembleId,
              contractId: deviceContract!.contractInfo!.contractId,
              quantity: deviceQuantity.toString()
            }
          }
        };

        if (this.isAuthenticated && this.ban) {
          request.queryParams.ban = this.ban;
        }

        return serviceLayer.getStreamRunnerWithCache('getAccountPlans')(request)
          .map( (res): Schemas.AccountPlansLookup => res.data);
      });
  }

  /**
   * method to get services for a device
   * @param params
   * @returns {any}
   */
  getDeviceServices(flow: string, category?: string, deviceSaleType?: string): Observable<Schemas.Service[]> {
    return Observable.combineLatest(
      this.serviceLayer$,
      this.deviceInfo$,
      this.customerServiceArea$,
      this.deviceCredit$,
      this.devicePlan$
    )
      .take(1)
      .mergeMap( ([serviceLayer, deviceInfo, CSA, credit, plan]) => {
        const params: Schemas.IGetServicesRequest = {
          queryParams: {
            deviceId: deviceInfo!.ensembleId!,
            csa: CSA.csaCode!,
            accountType: this.user.userAttributes!.accountType!,
            accountSubType: this.user.userAttributes!.accountSubType!,
            planSoc: plan!.planSOCSKU,
            creditClass: credit!.value,
            flow: flow
          }
        };

        if (category) {
          params.queryParams.category = category;
        }
        if (deviceSaleType) {
          params.queryParams.deviceSaleType = deviceSaleType;
        }

        return serviceLayer.getStreamRunnerWithCache('getServices')(params)
          .map( (res): Schemas.Service[] => res.data);
      });
  }
}

// Cart Service should be treated as a singleton
let deviceService: IDeviceService;
// Export factory as default function to simplify the encapsulation.
const factory: IDeviceServiceFactory = function ServiceLayerFactory(): IDeviceService {
  deviceService = deviceService || new DeviceService();
  return deviceService;
};

export default factory;
