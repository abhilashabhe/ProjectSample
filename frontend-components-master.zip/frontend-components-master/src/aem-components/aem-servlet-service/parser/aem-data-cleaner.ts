import * as _ from 'lodash';

export const aemDataCleaner = (data: {[key: string]: any}): {[key: string]: any} =>
  _.omitBy(
    data,
    (value: string) => !value || value.toString().toLowerCase().trim() === 'string.class'
  );
