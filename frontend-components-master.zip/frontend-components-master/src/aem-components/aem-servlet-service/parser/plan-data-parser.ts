import { aemDataCleaner } from './aem-data-cleaner';
import * as _ from 'lodash';

export const planDataParser = (data: any[]): {[key: string]: any} => {
  if (!data || data.length === 0) {
    return {};
  }

  if (Array.isArray(data) && Array.isArray(data[0])) {
    return planDataParser(data[0]);
  }

  const requestedNode = data.slice(0, 1).reduce(
    (coll, node) => {
      if (node) {
        coll[node.datatype] = aemDataCleaner(node.values);
      }
      return coll;
    },
    {}
  );
  const parentNode = data.slice(1, 2).reduce(
    (coll, node) => {
      if (node) {
        coll[node.datatype] = aemDataCleaner(node.values);
      }
      return coll;
    },
    {}
  );

  return _.merge({}, parentNode, requestedNode);
};
