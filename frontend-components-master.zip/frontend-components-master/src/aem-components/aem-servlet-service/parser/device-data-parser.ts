import { aemDataCleaner } from './aem-data-cleaner';
import * as _ from 'lodash';

export const deviceDataParser = (data: any[]): {[key: string]: any} => {
  if (!data || data.length === 0) {
    return {};
  }

  const requestedNode = data.slice(0, 2).reduce(
    (coll, node) => {
      if (node) {
        coll[node.datatype] = aemDataCleaner(node.values);
      }
      return coll;
    },
    {}
  );
  const parentNode = data.slice(2, 4).reduce(
    (coll, node) => {
      if (node) {
        coll[node.datatype] = aemDataCleaner(node.values);
      }
      return coll;
    },
    {}
  );

  return _.merge({}, parentNode, requestedNode);
};
