import { IServiceKeys } from '../../interfaces/service-layer';
import { planDataParser } from './plan-data-parser';
import { deviceDataParser } from './device-data-parser';
import { serviceDataParser } from './service-data-parser';

export type AEMDataParser = (data: any[]) => {[key: string]: any};

export const getDataParser = (serviceKey: IServiceKeys): AEMDataParser => {
  switch (serviceKey) {
    case 'getAEMServiceData':
      return serviceDataParser;
    case 'getAEMPlanData':
      return planDataParser;
    case 'getAEMDeviceData':
      return deviceDataParser;
    default:
      console.warn(`Unknown AEM data parser for ${serviceKey}.`);
      return (data: any) => data;
  }
};
