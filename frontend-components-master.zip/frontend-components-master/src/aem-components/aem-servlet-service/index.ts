import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import { aemServletServiceKey } from '../interfaces/aem-servlet-service';
import factory from './aem-servlet-service';

declare const sprintApp: ISprintApp;

(function init() {
  sprintApp.attachComponentFactory(aemServletServiceKey, factory);
})();
