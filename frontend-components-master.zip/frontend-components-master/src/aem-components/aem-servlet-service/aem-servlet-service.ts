import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import {
  AEMServletServiceSettings,
  AEMServletService,
  AEMServletServiceFactory,
  AEMServletEvent,
  aemServletMaxRetries,
  aemServletBufferDelay
} from '../interfaces/aem-servlet-service';
import {
  IServiceLayer,
  IServiceLayerFactory,
  IServiceKeys,
  SERVICE_LAYER
} from '../interfaces/service-layer';
import { ISprintApp } from '../interfaces/aem-bridge';
import * as _ from 'lodash';
import { getDataParser } from './parser/aem-data-parser';

declare const sprintApp: ISprintApp;

export class AEMServletServiceImpl implements AEMServletService {
  private queueProcessing = new BehaviorSubject<boolean>(false);
  private eventQueue = new Subject<AEMServletEvent>();
  private eventStore = new BehaviorSubject<AEMServletEvent[]>([]);
  // Settings
  private maxRetries: number = aemServletMaxRetries;
  private bufferDelay: number = aemServletBufferDelay;

  constructor(settings: AEMServletServiceSettings) {
    // Be very explicit about extracting settings
    if (settings && Object.getOwnPropertyNames(settings).indexOf('maxRetries') > -1 && settings.maxRetries > -1) {
      this.maxRetries = settings.maxRetries;
    }
    if (settings && Object.getOwnPropertyNames(settings).indexOf('bufferDelay') > -1 && settings.bufferDelay > -1) {
      this.bufferDelay = settings.bufferDelay;
    }

    this.eventQueue.asObservable()
      // Buffer the events for a set number of milliseconds
      .bufferWhen(() =>
        this.eventQueue.asObservable()
          .delay(this.bufferDelay)
          .switchMap(() => this.queueProcessing.asObservable())
          .filter(processing => !processing)
      )
      // Do not execute any further if there are no events to process
      .filter(queue => queue.length > 0)
      .do(() => this.queueProcessing.next(true))
      .mergeMap(queue => this.reduceQueue(queue))
      .mergeMap(queue => this.processQueue(queue))
      .catch((error) => {
        console.log('Error encountered in event queue:', error);
        this.queueProcessing.next(false);
        return Observable.of([]);
      })
      // Do not execute any further if there are no events to process
      .filter((queue) => {
        if (!queue || queue.length <= 0) {
          this.queueProcessing.next(false);
          return false;
        }

        return true;
      })
      .withLatestFrom(this.eventStore)
      .subscribe(([queue, eventStore]) => {
        this.eventStore.next([
          ...eventStore,
          ...queue
        ]);
        this.queueProcessing.next(false);
      });
  }

  public getServiceCategoriesFromAEM(serviceCategoryIds: string[]): Observable<any[]> {
    return this.enqueueEvents('getAEMServiceData', 'identifier', serviceCategoryIds);
  }

  public getServicesFromAEM(serviceIds: string[]): Observable<any[]> {
    return this.enqueueEvents('getAEMServiceData', 'ensembleId', serviceIds);
  }

  public getPlansFromAEM(planIds: string[]): Observable<any[]> {
    return this.enqueueEvents('getAEMPlanData', 'ensembleId', planIds);
  }

  public getDevicesFromAEM(itemIds: string[]): Observable<any[]> {
    return this.enqueueEvents('getAEMDeviceData', 'ensembleId', itemIds);
  }

  /**
   * Retrieve the service layer stream runner.
   */
  private getStreamRunner(serviceKey: IServiceKeys): Observable<(input: any) => Observable<any>> {
    return Observable.fromPromise(
      sprintApp.getComponentFactory<IServiceLayerFactory>(SERVICE_LAYER)
    )
      .map((factory: IServiceLayerFactory) => factory())
      .map((serviceLayer: IServiceLayer) => serviceLayer.getStreamRunner(serviceKey));
  }

  /**
   * Validate the AEM response contains data.
   */
  private aemResponseHasData(data?: any): boolean {
    if (!data || _.isEmpty(data)) {
      return false;
    } else if (typeof data === 'object') {
      if (Object.keys(data).length === 0) {
        return false;
      }

      return Object.keys(data).some((key) =>
        this.aemResponseHasData(data[key])
      );
    } else if (Array.isArray(data)) {
      if (data.length === 0) {
        return false;
      }

      // Because it could be an array of objects or arrays.
      return data.some((value) =>
        this.aemResponseHasData(value)
      );
    } else {
      return !_.isEmpty(data);
    }
  }

  /**
   * Helper method to find the result array from am AEM Servlet response that contains
   * the specified key/value pair. When calling the AEM Servlet, the response will contain
   * a data property as an array of responses (one for each requested object).
   */
  private findAemData(data: any[] | { [key: string]: any } = [], key: string, value: any): any[] | any | null {
    if (Array.isArray(data)) {
      return data.find(elem => !!this.findAemData(elem, key, value));
    } else {
      if (data && data.values) {
        const prop = this.caseInsensitiveFindDataKey(data.values, key);

        if (data.values[prop] === value) {
          return data.values;
        }
      }

      if (data) {
        const prop = this.caseInsensitiveFindDataKey(data, key);

        if (data[prop] === value) {
          return data;
        }
      }

      return null;
    }
  }

  /**
   * Helper method to find a key in an AEM data object using a case-insensitive approach.
   */
  private caseInsensitiveFindDataKey(data: { [key: string]: any }, key: string): string | undefined {
    let found: string;
    for (const prop in data) {
      if (String(prop).toLowerCase() === key.toLowerCase()) {
        found = prop;
        break;
      }
    }

    return found;
  }

  /**
   * Enqueues an AEM service request into the processing queue.
   */
  private enqueueEvents(serviceKey: IServiceKeys, searchKey: string, searchValues: string[]): Observable<any[]> {
    if (!serviceKey || !searchKey || !searchValues || searchValues.length === 0) {
      return Observable.of([]);
    }

    searchValues
      .reduce(
        (acc, itemId) => {
          acc.push(...itemId.split(','));
          return acc;
        },
        []
      )
      .map(searchValue => this.createServletEvent(serviceKey, searchKey, searchValue))
      .forEach(event => this.eventQueue.next(event));

    return this.eventStore.asObservable()
      // Collect all the stored events that are for devices and match the given planIds
      .map(events =>
        events.filter(event =>
          event.serviceKey === serviceKey &&
          event.searchKey === searchKey &&
          searchValues.includes(event.searchValue)
        )
      )
      .map(events =>
        searchValues.map(searchValue =>
          events.find(event => event.searchValue === searchValue)
        )
      )
      // Do not continue the event chain unless all the requested devices have been retrieved
      .filter(events =>
        events.reduce(
          (acc, event) => {
            acc = acc && !!event;
            return acc;
          },
          true
        )
      )
      .map(events => events.map(event => event.value));
  }

  /**
   * Converts a service request into a servlet event that can be processed via this service.
   */
  private createServletEvent(serviceKey: IServiceKeys, searchKey: string, searchValue: string): AEMServletEvent {
    return {
      serviceKey,
      searchKey,
      searchValue
    };
  }

  /**
   * Reduce a queue of AEM Servlet calls to remove any duplicates and any calls
   * that have already been processed.
   */
  private reduceQueue(queue: AEMServletEvent[]): Observable<AEMServletEvent[]> {
    const reducedQueue: AEMServletEvent[] = _.uniqWith(queue, _.isEqual);

    return this.eventStore.asObservable()
      .take(1)
      .map(eventStoreEvents => {
        return _.differenceWith(
          reducedQueue,
          eventStoreEvents,
          (a: AEMServletEvent, b: AEMServletEvent) =>
            a.serviceKey === b.serviceKey &&
            a.searchKey === b.searchKey &&
            a.searchValue === b.searchValue
        );
      });
  }

  /**
   * Process a queue of AEM Servlet calls. Only the successful calls will be returned
   * within an Observable. All failed calls will be re-queued with their retry count
   * increased. If a call has surpassed the set retry count, it will be returned with
   * an null value.
   *
   * This method will make use of the AEM Servlet API ability to batch requests for
   * multiple items into a single call. It will then split the results back out into
   * their individual Servlet call events.
   */
  private processQueue(queue: AEMServletEvent[]): Observable<AEMServletEvent[]> {
    if (!queue || queue.length === 0) {
      return Observable.of([]);
    }

    const groupedByServiceKey: {[key: string]: AEMServletEvent[][]} =
      _.chain(queue).groupBy(event => event.serviceKey)
      .reduce((acc: {[key: string]: any[]}, events: AEMServletEvent[], key: string) => { acc[key] = _.chunk(events, 20); return acc; }, {})
      .value();

    return Observable.combineLatest(
      [].concat(...Object.keys(groupedByServiceKey).map((serviceKey: IServiceKeys) => {
          return groupedByServiceKey[serviceKey].map(events => {
            return this.processQueueServiceKey(serviceKey, events);
          });
        })
      ))
      .map(results => {
        const flattenedResults = _.flatten(_.flatten(results));
        return flattenedResults.reduce(
          (acc, result) => {
            if (result.value) {
              // If the result has a value, return it
              acc.push(result);
            } else {
              // If the result has no data, requeue if it has not exceeded the max retry count
              if (result.retryCount && result.retryCount <= this.maxRetries) {
                this.eventQueue.next(result);
              } else {
                // If max retries is exceeded, set the value to null and return it
                result.value = null;
                acc.push(result);
              }
            }

            return acc;
          },
          []
        );
      });
  }

  /**
   * Process a queue of AEM Servlet calls for a specific service key.
   */
  private processQueueServiceKey(serviceKey: IServiceKeys, queue: AEMServletEvent[]): Observable<AEMServletEvent[][]> {
    const parser = getDataParser(serviceKey);
    const groupedBySearchKey: {[key: string]: AEMServletEvent[]} =
      _.groupBy(queue, (event) => event.searchKey);

    return Observable.combineLatest(
      ...Object.keys(groupedBySearchKey).map(searchKey => {
        const accumulatedSearchValue: string = groupedBySearchKey[searchKey]
          .map(event => event.searchValue)
          .join(',');

        return this.getStreamRunner(serviceKey)
          .switchMap(runner => runner({
            pathParams: {
              searchKey: searchKey,
              searchValue: accumulatedSearchValue
            }
          }))
          .catch(error => {
            console.log('Error encountered executing AEM Servlet call:', error);
            return Observable.of(null);
          })
          .map(response => {
            if (!response || !response.data || !this.aemResponseHasData(response.data)) {
              // If there was no response, increase the retry count of all events and return them with no value
              return groupedBySearchKey[searchKey].map(event => {
                if (!event.retryCount) {
                  event.retryCount = 1;
                } else {
                  event.retryCount += 1;
                }

                return event;
              });
            } else {
              // Map the correct response object to the event and return the events
              // Loop the grouped events for the current searchKey
              return groupedBySearchKey[searchKey].map(event => {
                const foundResponse = this.findAemData(response.data.data, searchKey, event.searchValue);
                const parsedResponse = parser(foundResponse);

                // If the data was found, add it to the event. Otherwise, increase the event retry count
                if (parsedResponse && this.aemResponseHasData(parsedResponse)) {
                  event.value = parsedResponse;
                } else if (!event.retryCount) {
                  event.retryCount = 1;
                } else {
                  event.retryCount += 1;
                }

                return event;
              });
            }
          });
      })
    );
  }
}

// AEMServletService should be treated as a singleton
let aemServletService: AEMServletService;

// Export factory as default function to simplify the encapsulation.
const factory: AEMServletServiceFactory = function AEMServletServiceFactory(): AEMServletService {
  const aemServletServiceSettings = sprintApp.getConfigData()['aemServletService'];
  aemServletService = aemServletService || new AEMServletServiceImpl(aemServletServiceSettings);
  return aemServletService;
};
export default factory;
