import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import { BING_MAPS_SERVICE } from '../interfaces/bing-maps/index';
import { BingMapsService } from './bing-maps.service';
export * from '../interfaces/bing-maps/index';
export * from './bing-maps.constants';
export * from './sprint-pushpin-icon';
export * from './bing-maps.service';
export * from './bing-maps.interfaces';

declare var sprintApp: ISprintApp;

export type BingMapsServiceFactory = () => BingMapsService;

(function init() {
  BingMapsService.get()
    .then(bingMapsService => {
      sprintApp.attachComponentFactory(BING_MAPS_SERVICE, () => bingMapsService);
    });
})();
