import { Observable } from 'rxjs/Observable';
import { IServiceLayerFactory, IServiceLayer } from '../interfaces/service-layer/index';
import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import { SERVICE_LAYER } from '../interfaces/service-layer';
import {
  bingMapsKey,
  suggestionBoxId,
  suggestionContainerId,
  defaultAutosuggestOptions,
  defaultMapLoadOptions,
  defaultPushpinOptions,
  defaultLocation
} from './bing-maps.constants';
import { SprintPushpinIcon } from './sprint-pushpin-icon';
import * as BingTypes from './bing-maps.interfaces';
import * as SprintTypes from '../../aem-components/interfaces/service-layer/schemas';


declare const sprintApp: ISprintApp;
let pendingBingMapsService: Promise<BingMapsService>;

export class BingMapsService {

  /* TODO: implmement these */
  static countryRegionWhitelist = [
    'United States',
    'Guam',
    'Puerto Rico',
    'Virgin Islands'
  ];

  static get(): Promise<BingMapsService> {
    if (!pendingBingMapsService) {
      pendingBingMapsService = new Promise((resolve, reject) => {
        // We need to call Microsoft's loadModule method to load in
        // the AutoSuggest module so that it can be used. The autosuggest module
        // requires that you provide it with a credential key.
        // Then we can resolve the Promise with the service as its value.
        const moduleOptions: BingTypes.ModuleOptions = {
          credentials: bingMapsKey,
          errorCallback: () => reject(new Error('Failed to load the Microsoft.Maps.AutoSuggest module')),
          callback: () => resolve(new BingMapsService())
        };

        window['_bingMapsLoadedCallback'] = () => {
          Microsoft.Maps.loadModule('Microsoft.Maps.AutoSuggest', moduleOptions);
        };

        const script = window.document.createElement('script');
        script.type = 'text/javascript';
        script.async = true;
        script.src = 'https://www.bing.com/api/maps/mapcontrol?callback=_bingMapsLoadedCallback';

        window.document.querySelector('head')!.appendChild(script);
      });
    }
    return pendingBingMapsService;
  }

  static bingAddressToSprintAddress(bingAddress: BingTypes.Address): SprintTypes.Address {
    const states = sprintApp.sharedMethods.addressMethods.getStateNames();
    const isPuertoRico = bingAddress.countryRegion === 'Puerto Rico';
    const state =
      isPuertoRico
        ? 'PR'
        : states.find(stateObj => stateObj.stateFullName === (bingAddress.adminDistrict || '').toUpperCase())!.stateAbbr;

    const urbanization = isPuertoRico ? bingAddress.district : null;

    return {
      address1: bingAddress.addressLine || null,
      city: bingAddress.locality || null,
      urbanization: urbanization || null,
      state: state || null,
      country: bingAddress.countryRegionISO2 || null,
      zip: bingAddress.postalCode || null
    };
  }

  createPoint(x: number, y: number): BingTypes.Point {
    return new Microsoft.Maps.Point(x, y);
  }

  createLocation(latitude: number, longitude: number): BingTypes.Location {
    return new Microsoft.Maps.Location(latitude, longitude);
  }

  createMapLoadOptions(options: Partial<BingTypes.MapLoadOptions> = {}): BingTypes.MapLoadOptions {
    return {
      ...defaultMapLoadOptions,
      center: new Microsoft.Maps.Location(defaultLocation.latitude, defaultLocation.longitude),
      ...options
    };
  }

  createMap(element: HTMLElement, options: Partial<BingTypes.MapLoadOptions> = {}): BingTypes.Map {
    return new Microsoft.Maps.Map(element, this.createMapLoadOptions(options));
  }

  /* Provide a way to create a PushPin from extended IPushPinOptions objects */
  createPushpin(metadata: BingTypes.PushpinMetadata): BingTypes.Pushpin {
    const {location, options = {}} = metadata;
    const id = metadata.id || JSON.stringify(location).replace(/\W/g, '');
    const pushpinOptions = {
      ...defaultPushpinOptions,
      anchor: new Microsoft.Maps.Point(SprintPushpinIcon.width / 2, SprintPushpinIcon.height),
      ...options
    };
    const pushpin = new Microsoft.Maps.Pushpin(
      this.createLocation(location.latitude, location.longitude),
      pushpinOptions
    );
    /* Add the metadata information to the pin's metadata */
    pushpin.metadata = {...pushpin.metadata, ...metadata, id};
    return pushpin;
  }

  createPushpinLayer(id?: string): BingTypes.Layer {
    return this.createPushpinLayerOf([], id);
  }

  createPushpinLayerOf(ofShapes: BingTypes.Shape|BingTypes.Shape[], id?: string): BingTypes.Layer {
    const shapes = Array.isArray(ofShapes) ? ofShapes : [ofShapes];
    const layer = new Microsoft.Maps.Layer(id);
    layer.setPrimitives(shapes);
    return layer;
  }

  attachAutosuggest(
    element: HTMLElement,
    options: BingTypes.AutosuggestOptions = {}
  ): Observable<BingTypes.Suggestion> {
    const randomString = Math.random().toString(36).replace(/[^a-z]+/g, '');
    const uniqueSuggestionBoxId = suggestionBoxId + randomString;
    const uniqueSuggestionContainerid = suggestionContainerId + randomString;

    return new Observable<BingTypes.Suggestion>(subscriber => {
      element.classList.add(uniqueSuggestionBoxId);
      element.parentElement!.classList.add(uniqueSuggestionContainerid);
      const manager = new Microsoft.Maps.AutosuggestManager({...defaultAutosuggestOptions, ...options});
      manager.attachAutosuggest(`.${uniqueSuggestionBoxId}`, `.${uniqueSuggestionContainerid}`, suggestionResult => {
        subscriber.next(suggestionResult);
      });

      /* Return the teardown logic */
      return () => {
        if (element) {
          element.classList.remove(suggestionBoxId);
          element.parentElement!.classList.remove(suggestionContainerId);
        }
        manager.detachAutosuggest();
        manager.dispose();
      };
    });
  }

  getCityAndStateByZip(zipQuery: string): Observable<{city?: string, state?: string}> {
    return !zipQuery || zipQuery.trim().length !== 5
      ? Observable.of({})
      : this.searchLocationsByQuery(zipQuery)
          .map(result => this.extractAddressesFromLocationResources(result))
          .map(([address]) =>
            !!address && !!address.adminDistrict && !!address.locality
              ? {
                  city: address.locality,
                  state: address.adminDistrict /* Unless country is not US, then use countryRegion as state */
                }
              : {}
          );
  }

  extractResourcesFromBingResult(result: SprintTypes.BingResult<SprintTypes.BingLocationResource>): SprintTypes.BingLocationResource[] {
    return (result && result.resourceSets || [])
      .reduce(
        (resources: SprintTypes.BingLocationResource[], set) => [ ...(set.resources || []), ...resources],
        []
      );
  }

  extractAddressesFromLocationResources(resources: SprintTypes.BingLocationResource[]): SprintTypes.BingAddress[] {
    return resources
      .map(resource => resource.address!)
      .filter(address =>
        !!address
        && ['Puerto Rico', 'United States'].some(country => address.countryRegion === country)
      );
  }

  searchLocationsByCoordinates(coords: BingTypes.Coordinates): Observable<SprintTypes.BingLocationResource[]> {
    const pathParams = { lat: coords.latitude, long: coords.longitude };

    return this.serviceLayer$
      .map(serviceLayer => serviceLayer.getStreamRunnerWithCache('getBingLocationByPoint'))
      .mergeMap(runner => runner({ pathParams }))
      .map(result => this.extractResourcesFromBingResult(result));
  }

  searchLocationsByQuery(query: string): Observable<SprintTypes.BingLocationResource[]> {
    return this.serviceLayer$
      .map(serviceLayer => serviceLayer.getStreamRunnerWithCache('getBingLocations'))
      .mergeMap(runner => runner({ queryParams: { query } }))
      .map(result => this.extractResourcesFromBingResult(result));
  }

  private get serviceLayer$(): Observable<IServiceLayer> {
    return Observable.from(
      sprintApp.getComponentFactory(SERVICE_LAYER)
        .then((factory: IServiceLayerFactory) => factory())
    );
  }
}
