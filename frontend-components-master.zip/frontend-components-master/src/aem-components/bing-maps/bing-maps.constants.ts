import { SprintPushpinIcon } from './sprint-pushpin-icon';
import * as BingTypes from './bing-maps.interfaces';

export const bingMapsKey = 'Apxk71SM4K4iaHH9xv1w-Lr1nRSf0-TaardRvcZS7oLtNKCs3TNEOI2bRIbQjeF4';

export const suggestionBoxId = 'bing-suggestion-box';

export const suggestionContainerId = 'bing-suggestion-container-id';

export const defaultLocation = {
  latitude: 38.915779665112495,
  longitude: -94.657189249992371
};

export const defaultAutosuggestOptions: BingTypes.AutosuggestOptions = {
  addressSuggestions: true,
  autoDetectLocation: true,
  maxResults: 5,
  placeSuggestions: false
};

export const defaultMapLoadOptions: BingTypes.MapLoadOptions = {
  credentials: bingMapsKey,
  // showDashboard: false,
  showZoomButtons: true,
  showLocateMeButton: true,
  zoom: 10
};

export const defaultPushpinOptions: BingTypes.PushpinOptions = {
  color: '#FFCE09',
  cursor: 'pointer',
  draggable: true,
  enableClickedStyle: true,
  enableHoverStyle: true,
  icon: SprintPushpinIcon.of().toString(),
  roundClickableArea: false,
  subTitle: '',
  title: '',
  text: '',
  visible: true
};
