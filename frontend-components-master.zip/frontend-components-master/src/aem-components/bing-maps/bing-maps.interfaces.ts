import { Address } from '../../aem-components/interfaces/service-layer/schemas';

export interface PushpinMetadata {
  id?: string;
  location?: Coordinates;
  options?: PushpinOptions;
  [metaKey: string]: any;
}

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export type Address = Microsoft.Maps.IAddress;
export type AutosuggestOptions = Microsoft.Maps.IAutosuggestOptions;
export type Color = Microsoft.Maps.Color;
export type Layer = Microsoft.Maps.Layer;
export type Location = Microsoft.Maps.Location;
export type LocationRect = Microsoft.Maps.LocationRect;
export type Map = Microsoft.Maps.Map;
export type MapEvent = Microsoft.Maps.IMouseEventArgs;
export type MapLoadOptions = Microsoft.Maps.IMapLoadOptions;
export type MapOptions = Microsoft.Maps.IMapOptions;
export type ModuleOptions = Microsoft.Maps.IModuleOptions;
export type Point = Microsoft.Maps.Point;
export type Shape = Microsoft.Maps.IPrimitive;
export type Pushpin = Microsoft.Maps.Pushpin;
export type PushpinEvent = Microsoft.Maps.IMouseEventArgs | Microsoft.Maps.IPrimitiveChangedEventArgs;
export type PushpinOptions = Microsoft.Maps.IPushpinOptions;
export type StreetsideOptions = Microsoft.Maps.IStreetsideOptions;
export type Suggestion = Microsoft.Maps.ISuggestionResult;
export type ViewOptions = Microsoft.Maps.IViewOptions;

/*
  Create a type that aggregates and base Bing Maps suggestion,
  along with a transformed version of the Bing address that matches
  the Sprint API spec.
*/
export interface AddressAutocompleteSuggestion {
  /* The original Bing maps suggestion */
  suggestion: Suggestion;
  location: Location;
  /* The Sprint API formatted address */
  address: Address;
  /* Address one-liner */
  formatted: string;
}
