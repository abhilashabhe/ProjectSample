import * as BingTypes from './bing-maps.interfaces';

export interface SprintPushpinIconOptions {
  text: string;
  color: string;
}

export class SprintPushpinIcon {
  static width = 25;
  static height = 34.9;
  static textElementId = 'pushpin-text';
  static pathElementId = 'pushpin-path';

  static of(options?: Partial<SprintPushpinIconOptions>): SprintPushpinIcon {
    return new SprintPushpinIcon({
      color: '#FFCE09',
      text: '',
      ...(options || {})
    });
  }

  static fromPin(pin: BingTypes.Pushpin): SprintPushpinIcon {
    return SprintPushpinIcon.fromString(pin.getIcon());
  }

  static fromString(svgSrc: string): SprintPushpinIcon {
    const parser = new DOMParser();
    let svgDocument: Document;
    let svg: SVGElement;
    let pathElement = null;
    let textElement = null;

    try {
      svgDocument = parser.parseFromString(svgSrc, 'image/svg+xml');
      svg = svgDocument.firstElementChild as SVGElement;
      pathElement = svg.querySelector('#' + SprintPushpinIcon.pathElementId) as SVGPathElement;
      textElement = svg.querySelector('#' + SprintPushpinIcon.textElementId) as SVGTextElement;
    } catch (error) {
      console.warn(error);
    }

    return new SprintPushpinIcon({
      color: pathElement !== null
        ? pathElement.getAttribute('fill')
        : '#FFCE09',
      text: textElement !== null
        ? textElement.innerHTML
        : ''
    });
  }

  private constructor(
    private options: SprintPushpinIconOptions
  ) {}

  color(color: string): SprintPushpinIcon {
    return new SprintPushpinIcon({ ...this.options, color });
  }

  text(text: string): SprintPushpinIcon {
    return new SprintPushpinIcon({ ...this.options, text });
  }

  green(): SprintPushpinIcon {
    return new SprintPushpinIcon({ ...this.options, color: '#90CE00' });
  }

  gray(): SprintPushpinIcon {
    return new SprintPushpinIcon({ ...this.options, color: '#CECFCF' });
  }

  blue(): SprintPushpinIcon {
    return new SprintPushpinIcon({ ...this.options, color: '#7D4EFF' });
  }

  yellow(): SprintPushpinIcon {
    return new SprintPushpinIcon({ ...this.options, color: '#FFCE09' });
  }

  toString(): string {
    return `
    <svg
      version="1.1"
      id="Layer_1"
      xmlns="http://www.w3.org/2000/svg"
      x="0px"
      y="0px"
      width="${SprintPushpinIcon.width}px"
      height="${SprintPushpinIcon.height}px"
      viewBox="-284.9 368 25 34.9"
      enable-background="new -284.9 368 25 34.9"
      xml:space="preserve">
      <g id="Page-1">
        <g id="Desktop-HD" transform="translate(-699.000000, -483.000000)">
          <g id="Map-pin" transform="translate(699.000000, 483.000000)">
            <g id="Group-2">
              <path
                id="${SprintPushpinIcon.pathElementId}"
                fill="${this.options.color}"
                d="M-272.4,368c-6.9,0-12.5,5.6-12.5,12.4c0,8.1,10.4,22.5,12.5,22.5s12.5-14.4,12.5-22.5C-259.9,373.6-265.5,368-272.4,368z"/>
            </g>
          </g>
        </g>
      </g>
      <text
        id="${SprintPushpinIcon.textElementId}"
        transform="matrix(1 0 0 1 -276.9105 385.4611)"
        font-family="'ArialMT'"
        font-size="16.8481px">
        ${this.options.text}
      </text>
    </svg>`;
  }
}
