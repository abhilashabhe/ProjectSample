import { BingMapsService } from './bing-maps.service';

describe('BingMapsService static constructor', () => {

  it('should load bing maps', (cb) => {
    BingMapsService.get().then(
      (bm) => {
        expect(bm).toBeDefined();
        expect(window[ 'Microsoft' ]).toBeDefined();
        expect(window[ 'Microsoft' ].Maps).toBeDefined();
        cb();
      },
      (err) => {
        cb.fail(new Error(err.message));
      }
    );
  }, 10000);

});
