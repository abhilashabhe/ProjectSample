import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import * as I from '../interfaces/date-picker';

const Pikaday = require('./pikaday');

const factory: I.IDatePickerFactory = function (opts: {[opt: string]: any}, pikadayOpts?) {
  const pikadayOptions = <any> {
    theme: 'sprint-calendar',
    format: 'MMM D, YYYY'
  };

  // extend opts
  Object.keys(opts).forEach(key => {
    pikadayOptions[key] = opts[key];
  });

  // extend pikaday fine tuning opts
  if (pikadayOpts) {
    Object.keys(pikadayOpts).forEach(key => {
      pikadayOptions[key] = pikadayOpts[key];
    });
  }

  return new Pikaday(pikadayOptions);
};

declare var sprintApp: ISprintApp;

(function init() {
  sprintApp.attachComponentFactory(I.DATE_PICKER, factory);
})();
