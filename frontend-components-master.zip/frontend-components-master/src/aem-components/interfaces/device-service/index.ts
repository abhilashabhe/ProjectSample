import { Observable } from 'rxjs/Observable';
import { ConnectableObservable } from 'rxjs/observable/ConnectableObservable';
import * as Schemas from '../../interfaces/service-layer/schemas/';
import {CustomerServiceArea} from '../service-layer/schemas/customer-service-areas/customer-service-areas.interface';

// The identifier for this component when it is registered
export const DEVICE_SERVICE = 'DeviceService';

export interface IDeviceService {
  deviceInfo$: Observable<DeviceInfo | null>;
  deviceContract$: Observable<DeviceContractInfo | null>;
  deviceCredit$: Observable<DeviceCreditInfo | null>;
  devicePlan$: Observable<Schemas.BaseRequestPlan | null>;
  services$: Observable<Schemas.BaseRequestService[] | null>;
  deviceStream$: ConnectableObservable<Schemas.Device>;
  plansStream$: ConnectableObservable<Schemas.Plan[]>;
  pricingStream$: ConnectableObservable<Schemas.DevicePrices>;
  servicesStream$: ConnectableObservable<Schemas.Service[]>;
  customerServiceArea$: Observable<CustomerServiceArea>;
  deviceQuantity$: Observable<number>;

  setDeviceInfo: (device: DeviceInfo) => void;
  setDeviceContract: (contract: DeviceContractInfo) => void;
  setDeviceCreditInfo: (credit: DeviceCreditInfo) => void;
  setDevicePlan: (plan: Schemas.BaseRequestPlan) => void;
  setDeviceServices: (services: Schemas.BaseRequestService[]) => void;
  setDeviceQuantity: (deviceQuantity: number) => void;
  getDeviceDetails: () => Observable<Schemas.Device>;
  getDevicePricing: (flow?: string, subscriptionId?: string ) => Observable<Schemas.DevicePrices>;
  getDevicePlans: () => Observable<Schemas.Plan[]>;
  getAccountPlans: () => Observable<Schemas.AccountPlansLookup>;
  getDeviceServices: (flow: string, category?: string, deviceSaleType?: string) => Observable<Schemas.Service[]>;
}

export interface DeviceInfo {
  color?: string;
  storage?: string;
  ensembleId?: string;
}

export interface DeviceContractInfo {
  contractInfo?: {
    contractId?: string;
  };
  offerGroupInfo?: {
    offerGroupCode: string;
    promoCode?: string | null;
  };
  deviceSaleType?: string;
  tradeInRequired?: boolean;
}

export interface DeviceCreditInfo {
  value: string;
  display: string;
}

export type IDeviceServiceFactory = () => IDeviceService;
