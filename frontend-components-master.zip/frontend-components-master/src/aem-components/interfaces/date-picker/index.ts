// The identifier for this component when it is registered
export const DATE_PICKER = 'DatePicker';

/* tslint:disable:no-empty-interface */
export interface IDatePicker {
}
/* tslint:enable:no-empty-interface */

export type IDatePickerFactory = (opts: IDatePickerOptions, pikadayOpts?: any) => IDatePicker;

export interface IDatePickerOptions {
  // Input for the calendar to attach to
  field: HTMLInputElement;

  labels?: [string, Date][];

  // TODO document which start day is which
  // this is an integer of [0, 7]
  firstDay?: number;

  yearRange?: [number, number];

  // Container for the calendar to be appended to
  container: HTMLElement;

  // How many months to show side by side, defaults to 1
  numberOfMonths?: number;

  // Optionally set maximum dates
  minDate?: Date;
  maxDate?: Date;
  disableWeekends?: boolean;

  defaultValue?: Date;
}
