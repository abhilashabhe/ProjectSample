import { ISprintApiConfig } from '../service-layer/sprint-api-config.interface';

export interface ISprintAppConfig {
  apiConfig?: ISprintApiConfig;
  [propName: string]: any;
}
