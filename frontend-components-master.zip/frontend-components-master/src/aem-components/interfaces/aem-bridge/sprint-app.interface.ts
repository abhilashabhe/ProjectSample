import { ISprintAppConfig } from './sprint-app-config.interface';
import { ISprintAppLoginModalConfig } from './sprint-app-login-modal-config.interface';
import { ISprintAppHeaderLogin } from './sprint-app-header-login.interface';
import { IAEMGlobalMessage } from './aem-global-messages.interface';
import { IAEMGlobalError } from './aem-global-errors.interface';
import * as Schemas from '../service-layer/schemas/index';
import { IServiceLayer } from '../service-layer/index';
import { AnalyticsMethods, IAnalyticsItem } from '../../interfaces/shared/analytics.interface';
import { Observable } from 'rxjs/Observable';
import { UserAccountDetails, User, AddressStateOption } from '../service-layer/schemas';

export interface AuthModule {
  getUser: () => any;
  getUsersAPIResponse: () => User[];
  getSessionAPIResponse: () => Schemas.Session | null;
  isAuthenticated: () => boolean;
}

export interface ISprintApp {
  // Methods/Properties added at runtime
  disableGeolocation?: boolean;
  openLoginModal?: (param: ISprintAppLoginModalConfig) => void;
  headerLogIn?: ISprintAppHeaderLogin;
  globalMessages: IAEMGlobalMessage[];
  globalErrors: IAEMGlobalError[];
  authModule?: AuthModule;
  globalErrorHandler?: {
    triggerGlobalError: (message: string, errCode: string) => void;
    resetGlobalError: () => void;
    retrieveErrorMessage: (errorCode: string) => Promise<string>,
    triggerGlobalErrorWithLookup: (code: string) => void;
  };
  utils?: {
    appendPromoModal: (value: Schemas.CartModalPromo) => void;
    checkQueryString: (value: string) => string;
    getUserAccountDetail: () => Schemas.Session;
    checkButton: (condition: boolean, button: Element) => void;
    getUserAccountDetails: () => UserAccountDetails;
    retrieveAEMDeviceData: (serviceLayer: IServiceLayer, ensembleId: string) => any;
    getDeviceQuantityFromURL: () => number;
  };
  globalSharedLinks?: {[key: string]: string};
  getCurrentPageLoadTime?: () => number;
  createAtgRunTargeterBatch?: () => void;
  nbaProfileOffer?: (parameters: Object) => void;

  // Shared Methods
  sharedMethods: {
    addressMethods: {
      addressToString: (value: {[key: string]: string}) => string;
      calculateHaversineDistance: (center: { latitude: number, longitude: number },
                                   point: { latitude: number, longitude: number }) => number;
      degreesToRadians: (deg: number) => number;
      getStateAbbreviations: () => string[];
      getStateNames: () => AddressStateOption[];
      kilometersToMiles: (km: number, precision?: number) => number;
      milesToKilometers: (mi: number, precision?: number) => number;
    };
    storageMethods: {
      getItem: (key: string) => any;
      setItem: (key: string, value: any) => any;
      removeItem: (key: string) => void;
      localStorageAvailable: () => boolean;
      sessionStorageAvailable: () => boolean;
      checkCookie: (key: string) => string;
    };
    locationMethods: {
      isRedirectDisabled: () => boolean;
      redirect: (location: string) => void;
      getGlobalSharedLink: (linkKey: string, linkParams?: Object) => string;
      getGlobalSharedLinkAsync: (linkKey: string, linkParams?: Object) => Observable<string>;
      updateQueryString: (param: string, value: string, url?: string) => string;
      checkQueryString: (param: string, url?: string) => string;
      encodeQueryParams: (data: any) => string;
    };
    scrollToMethods: {
      currentScrollPosition: () => {x: number, y: number};
      elementPosition: (element: HTMLElement) => {x: number, y: number};
      smoothScrollTo: (x: number, y: number, duration: number) => void;
      scrollTo: (x: number, y: number) => void;
      scrollToElement: (element: HTMLElement) => void;
      smoothScrollToElement: (element: HTMLElement, duration: number) => void;
    };
    pricingMethods: {
      generateDisplayPrice: (price: number) => string;
    };
    phoneMethods: {
      phoneToString: (value: string) => string;
    };
    streamMethods: {
      runParallelStreams: (streams: Observable<any>[]) => Observable<any>;
      retrieveAEMDeviceData: (serviceLayer: IServiceLayer, ensembleId: string) => Observable<any>;
      retrieveAEMAccessoryData: (serviceLayer: IServiceLayer, ensembleId: string) => Observable<any>;
    };
    dateMethods: {
      monthDiff: (date1: Date, date2: Date) => number;
    };
    imageMethods: {
      lazyLoadImage: (img: Element, errFunction: Function) => void;
    };
    stringMethods: {
      convertUtcString: (utc: string) => string;
      annotateNumber: (n: string) => string;
      deannotateString: (s: string) => string;
    };
    analyticsMethods: {
      getPageBaseAnalytics: () => IAnalyticsItem;
      createAnalyticsItem: (pageData: IAnalyticsItem) => IAnalyticsItem;
      setPageBaseAnalytics: (pageData: IAnalyticsItem) => void;
      saqPush: (method: AnalyticsMethods, pageData?: IAnalyticsItem | null | undefined) => void;
      saqRawPush: (saqArray: any[]) => void;
      trackPage: (pageData: IAnalyticsItem) => void;
      trackWidget: (message: string) => void;
      trackClick: (pageData: IAnalyticsItem) => void;
      trackEvent: (pageData: IAnalyticsItem) => void;
      trackMessage: (message: string) => void;
      trackModal: (pageData: IAnalyticsItem) => void;
      trackUpdate: (status: 'start' | 'complete', message: string) => void;
      closeModal: () => void;
      trackTransaction: (message: string, status: 'transactionStart' | 'transactionComplete') => void;
    };
  };

  // Module build data
  buildData?: {
    checkout?: Object;
    cart?: Object;
    care?: Object;
  };

  dispatchEvent(eventName: string, element: Element|Document|Window, obj: {[param: string]: any}): void;
  attachComponentFactory(name: string, fn: Function): void;
  getComponentFactory<T>(name: string): Promise<T>;
  setConfigData(configData: ISprintAppConfig): void;
  getConfigData(): ISprintAppConfig;
}
