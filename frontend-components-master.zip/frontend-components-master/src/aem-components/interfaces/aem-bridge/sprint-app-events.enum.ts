export abstract class SprintAppEventsEnum {
  static get INIT_STARTED(): string {
    return 'sprint-app:init:started';
  }

  static get INIT_COMPLETED(): string {
    return 'sprint-app:init:completed';
  }
}
