export interface ISprintAppHeaderLogin {
    open?: (redirectOverride: string) => void;
}
