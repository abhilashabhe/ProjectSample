import * as Interfaces from './';

describe('Schema Models', () => {

  it(`is an object`, () => {
    expect(typeof Interfaces).toBe('object');
  });
});
