export interface ISprintAppLoginModalConfig {
    action?: string;
    description?: string;
    disableClose?: boolean;
    disableSidebar?: boolean;
    header?: string;
    redirect?: string;
    redirectOnClose?: string;
}
