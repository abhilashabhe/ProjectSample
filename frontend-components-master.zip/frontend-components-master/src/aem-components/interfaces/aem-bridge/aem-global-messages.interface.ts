export interface IAEMGlobalMessage {
  message: string;
  color?: string;
  cta?: {
    type?: string;
    label?: string;
    buttonStyle?: string;
    url?: string;
    fn?: Function;
  }[];
}
