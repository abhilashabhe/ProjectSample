import { SprintAppEventsEnum } from './sprint-app-events.enum';

describe('Sprint App Events Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof SprintAppEventsEnum.INIT_COMPLETED).toBe('string');
    expect(typeof SprintAppEventsEnum.INIT_STARTED).toBe('string');
  });

});
