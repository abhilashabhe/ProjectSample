import { ConnectableObservable } from 'rxjs/observable/ConnectableObservable';
import {CustomerServiceArea} from '../service-layer/schemas/customer-service-areas/customer-service-areas.interface';
// The identifier for this component when it is registered
export const LOCATION_SERVICE = 'LocationService';

export interface ILocationService {
  CSAObservable: ConnectableObservable<CustomerServiceArea>;
  getCSA(): ConnectableObservable<CustomerServiceArea>;
}

export type ILocationServiceFactory =
  () => ILocationService;
