import { Observable } from 'rxjs/Observable';
import { IServiceKeys } from '../service-layer';

// The identifier for this component when it is registered
export const aemServletServiceKey = 'AEMServletService';
export const aemServletMaxRetries = 2;
export const aemServletRetryDelay = 200;
export const aemServletBufferDelay = 1000;

export interface AEMServletServiceSettings {
  maxRetries?: number;
  retryDelay?: number;
  bufferDelay?: number;
}

export interface AEMServletService {
  getServiceCategoriesFromAEM(serviceCategoryIds: string[]): Observable<any[]>;
  getServicesFromAEM(serviceIds: string[]): Observable<any[]>;
  getPlansFromAEM(planIds: string[]): Observable<any[]>;
  getDevicesFromAEM(itemIds: string[]): Observable<any[]>;
}

export interface AEMServletEvent {
  serviceKey: IServiceKeys;
  searchKey: string;
  searchValue: string;
  value?: any | null;
  retryCount?: number;
}

export type AEMServletServiceFactory =
  (settings?: AEMServletServiceSettings) => AEMServletService;
