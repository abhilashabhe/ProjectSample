import { Observable } from 'rxjs/Observable';
import { ConnectableObservable } from 'rxjs/observable/ConnectableObservable';
import * as Schemas from '../../interfaces/service-layer/schemas/';

// The identifier for this component when it is registered
export const CART_SERVICE = 'CartService';

export interface ICartService {
  cartStream$: ConnectableObservable<Schemas.Cart | null>;
  isCartEmpty$: Observable<boolean>;
  cartId$: Observable<string>;
  packages$: Observable<Schemas.Package[]>;
  subpackages$: Observable<Schemas.Subpackage[]>;
  lastPackage$: Observable<Schemas.Package | null>;
  lastSubPackage$: Observable<Schemas.Subpackage | null>;
  plans$: Observable<Schemas.Plan[]>;
  planIds$: ConnectableObservable<string[]>;
  AOPackage$: Observable<Schemas.Package | null>;
  hasAOPackage$: Observable<boolean>;
  AOObject$: ConnectableObservable<{ hasAOPackage: boolean; AOPackage: Schemas.Package | null; }>;

  cartReady$: Observable<boolean>;
  lastAddedService$: Observable<Schemas.ServiceItem | null>;
  lastAddedDevice$: Observable<Schemas.Device | null>;
  hasAOPackage: boolean;
  isCartEmpty: boolean;
  cartLoader: HTMLElement;
  remainingLineLimit$: Observable<number>;


  initializeBaseRequest(baseRequest: Schemas.BaseRequestCartOverride): Schemas.BaseRequestCart;
  addAccessories(accessories: Schemas.BaseRequestAccessory[], packageId?: string, subpackageId?: string, byodFlag?: boolean): Observable<{}>;
  addCartSubpackage(packageId: string, subpackage: Schemas.BaseRequestSubpackage): Observable<{}>;
  addPackageToCart(packageToAdd: Schemas.BaseRequestPackage): Observable<{}>;
  addByodDevice(byoddevice: Schemas.BaseRequestByodDevice, plan?: Schemas.BaseRequestPlanForAddToCart): Observable<{}>;
  addDevice(device: Schemas.BaseRequestDevice, plan?: Schemas.BaseRequestPlanForAddToCart, service?: Schemas.BaseRequestService | Schemas.BaseRequestService[], accessories?: Schemas.BaseRequestAccessory[], quantity?: number): Observable<{}>;
  addUpgradeDevice(device: Schemas.BaseRequestDevice, subscriber: Schemas.SubscriptionLineInfo): Observable<{}>;
  addService(service: Schemas.BaseRequestService): Observable<{}>;
  addTablet(device: Schemas.BaseRequestDevice, plan?: Schemas.BaseRequestPlan, service?: Schemas.BaseRequestService | Schemas.BaseRequestService[], accessories?: Schemas.BaseRequestAccessory[]): Observable<{}>;
  deleteCart(): Observable<{}>;
  getNewCart(): Observable<Schemas.Cart | null>;
  updateCartCreditRange(creditRange: Schemas.CreditRangeEnum): Observable<{}>;
  updateCartCreditClass(creditClass: string): Observable<{}>;
  updateCartZipCode(zipCode: string): Observable<{}>;
}

export type ICartServiceFactory =
  () => ICartService;
