// The identifier for this component when it is registered
export const BING_MAPS_SERVICE = 'BingMapsService';
