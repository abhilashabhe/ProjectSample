export interface UserAccountDetails {
  accountId?: string;
  accountType: string;
  accountSubtype?: string;
  authenticated?: boolean;
  billingAccountStatusCode: string;
  startDate: string;
  creditClass: string;
  creditClassDesc: string;
  firstName?: string;
  lastName?: string;
  brandCode: string;
  aslInd: boolean;
  delinquent: boolean;
  hotlineType: string;
  doNotSellInd: boolean;
  accountLevelChurnScore: number;
  marketTreatmentValue: number;
  languageCode: string;
  hasAdjustedSpeedPlanOnBan: boolean;
  hasAutoBuyUpPlanOnBan: boolean;
  billing: {
    billCycleCode: string;
    totalDue: number;
    currentBalance: number;
    cycleStartDate: string;
    cycleCloseDate: string;
    billLanguageCode: string;
  };
  subscriberCounts: {
    totalCount: number;
    activeCount: number;
    reservedCount: number;
    suspendedCount: number;
    cancelledCount: number;
  };
  areMoreSubscribers: boolean;
  areSubscribersGrouped: boolean;
  role?: string;
}
