import {UserAttributes} from './user-attributes.interface';
export interface Session {
  userAttributes?: UserAttributes;
}
