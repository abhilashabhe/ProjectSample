export interface UserAccountSecurityContexts {
  accountId?: string;
  role?: string;
  permissions?: string[];
  primary?: boolean;
}
