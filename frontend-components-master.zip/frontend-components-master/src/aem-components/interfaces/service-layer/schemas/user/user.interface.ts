import {AccountSecurityContext} from './account-security-context.interface';
export interface User {
  id?: string;
  username?: string;
  email?: string;
  earlyLifeUser?: string;
  accountSecurityContexts?: AccountSecurityContext[];
  isBusinessUser?: boolean;
  selectedAccount?: string;
}

/* tslint:disable:no-empty-interface */
export interface UserSession {

}
/* tslint:enable:no-empty-interface */
