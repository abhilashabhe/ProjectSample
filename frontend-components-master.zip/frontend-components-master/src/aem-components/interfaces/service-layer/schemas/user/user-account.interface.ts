export interface UserAccount {
  roleId: string;
  roleName: string;
  ban: string;
  accountLevel: boolean;
}
