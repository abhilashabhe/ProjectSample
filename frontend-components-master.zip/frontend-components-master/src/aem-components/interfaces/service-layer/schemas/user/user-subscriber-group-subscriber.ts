export interface UserSubscriberGroupSubscriber {
  subscriberInfo: {
    subscriberId: string
    activationDate: string
    csa: string
  };
  plan: {
    pricePlanCode: string
    pricePlanName: string
    pricePlanEffectiveDate: string
    currentRank: number
    ffPlanType: string
    sharedDataSoc: string
    hasAdjustedSpeedSOCOnSub: boolean
    primaryLineInd: boolean
    hasAutoBuyUpSOCOnSub: boolean
    hasDEHotspotOnLegacyPlan: boolean
  };
  device: {
    itemId: string
    itemIdType: string
    modelId: string
    manufacturer: string
    operatingSystem: string
    technologyCode: string
    mdn: string
    esn: string
    esnHex: string
    imsi: string
    nai: string
  };
  name: {
    firstName: string
    lastName: string
  };
}
