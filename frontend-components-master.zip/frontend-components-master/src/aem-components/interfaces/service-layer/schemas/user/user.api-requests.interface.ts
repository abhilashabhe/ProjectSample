import {IServiceInput} from '../../service-input.interface';
import { User } from '../user/user.interface';

export interface IUpdateSessionRequest extends IServiceInput {
  data: {
    userAttributes: {
      profileId: string;
      shopingZipCode?: string;
      geoCity?: string;
      geoState?: string;
      geoZip?: string;
      geoCSA?: string;
      currentShopingPath?: string;
      currentPurchaseStep?: string;
      currentSessionProductsViewed?: string;
    }
  };
}


export interface IGetUserRequest extends IServiceInput {
  pathParams: {
    userId: string;
  };
}

export interface IPutUserRequest extends IGetUserRequest {
  data: User;
}
