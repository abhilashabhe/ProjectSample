import {UserSubscriberGroupSubscriber} from './user-subscriber-group-subscriber';
export interface UserSubscriberGroup {
  planType: string;
  sharingGroupId: string;
  singleSubOnSharedPlan: boolean;
  subscriberList: UserSubscriberGroupSubscriber[];
}
