export interface AccountSecurityContext {
  accountId?: string;
  deviceInHandMDN?: string;
  role?: 'ACCOUNT_OWNER' | 'DEVICE_USER' | 'ACCOUNT_AUTHORIZED';
  permissions?: string[];
  primary?: boolean;
}
