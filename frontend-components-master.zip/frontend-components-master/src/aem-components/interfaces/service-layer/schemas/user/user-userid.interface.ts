import {UserAccountSecurityContexts} from './user-account-security-contexts.interface';
export interface UserId {
  id?: string;
  username?: string;
  email?: string;
  earlyLifeUSer?: boolean;
  accountSecurityContexts?: UserAccountSecurityContexts[];
}
