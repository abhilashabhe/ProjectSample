import { UnitOfMeasureEnum } from './plans/unit-of-measure.enum';
export interface UnitOfMeasure {
  unitOfMeasure?: UnitOfMeasureEnum;
}
