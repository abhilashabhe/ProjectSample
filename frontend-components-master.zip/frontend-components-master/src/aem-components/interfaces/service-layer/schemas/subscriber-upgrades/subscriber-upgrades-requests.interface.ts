import {IServiceInput} from '../../service-input.interface';
export interface IGetSubscriberUpgradesRequestInterface extends IServiceInput {
  pathParams: {
    accountId: string;
  };
  queryParams: {
    ptn?: string;
  };
};
