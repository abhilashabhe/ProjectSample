import { CancelOrderResponse } from './cancel-order-response.interface';
export interface CancelOrderRequest {
  cancelOrderResponse?: CancelOrderResponse;
}
