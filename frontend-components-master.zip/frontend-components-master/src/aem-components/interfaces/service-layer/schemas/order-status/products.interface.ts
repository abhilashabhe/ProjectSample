import { OrderStatusOrderLineInfo } from './order-status-order-line-info.interface';
export interface Products {
  bucketTitle?: string;
  orderLineInfo?: OrderStatusOrderLineInfo[];
  orderLineTypeCode?: string;
  itemId?: string;
}
