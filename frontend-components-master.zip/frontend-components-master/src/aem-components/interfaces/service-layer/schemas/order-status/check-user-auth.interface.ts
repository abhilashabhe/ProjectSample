export interface CheckUserAuth {
  question: string;
}
