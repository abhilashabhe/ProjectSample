export interface ValidationErrorInfo {
  lineItem?: string;
  errorCode?: string;
  errorDescription?: string;
}
