import {IServiceInput} from '../../';
export interface IGetOrderStatusRequest extends IServiceInput {
  pathParams: {
    orderKey: string;
  };
  queryParams: {
    blackBox: string;
  };
};
export interface GetOrderCancelListRequest extends IServiceInput {
  pathParams: {
    accountId: string;
  };
};
export interface PutCancelOrdersRequest extends IServiceInput {
  pathParams: {
    accountId: string;
    orderKey: string;
  };
  data: {
    notificationType: string;
    userText: string;
  };
};
export interface CheckUserAuthRequest extends IServiceInput {
  pathParams: {
    accountId: string;
  };
};
