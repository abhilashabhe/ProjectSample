export interface OrderSummaryList {
  orderKey: string;
  orderDate?: string;
  items?: string[];
  orderStatus?: string;
}
