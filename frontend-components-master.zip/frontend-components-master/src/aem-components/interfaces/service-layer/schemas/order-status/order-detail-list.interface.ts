import { Products } from './products.interface';
export interface OrderDetailList {
  orderKey: string;
  orderDate?: string;
  orderDateTime?: string;
  orderSource?: string;
  orderStatus?: string;
  orderStatusShortDesc?: string;
  orderStatusId?: string;
  wareHouseFulfillmentInd?: string;
  typeOfOrder?: string;
  shippingVendor?: string;
  products?: Products[];
  message?: string;
  ban?: string;
  enableCancel?: string;
  bucketTitle?: string;
  securityQuestion?: string;
}
