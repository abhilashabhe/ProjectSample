export interface OrderStatusOrderLineInfo {
  itemId?: string;
  orderLineTypeCode?: string;
  lineSequenceNumber?: string;
  itemDesc?: string;
  lineStatusId?: string;
  lineStatusDesc?: string;
  externalShippingVendor?: string;
  bucketTitle?: string;
  trackingNumber?: string;
  shipmentDate?: string;
  shippingVendorUrl?: string;
}
