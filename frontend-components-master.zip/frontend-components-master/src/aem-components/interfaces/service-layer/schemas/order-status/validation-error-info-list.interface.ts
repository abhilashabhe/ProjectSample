import { ValidationErrorInfo } from './validation-error-info.interface';
export interface ValidationErrorInfoList {
  validationErrorInfo?: ValidationErrorInfo[];
}
