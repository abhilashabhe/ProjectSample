import { ValidationErrorInfoList } from './validation-error-info-list.interface';
export interface CancelOrderResponse {
  successInd: Boolean;
  memoId: string;
  billingAccountNumber: string;
  validationErrorInfoList?: ValidationErrorInfoList;
}
