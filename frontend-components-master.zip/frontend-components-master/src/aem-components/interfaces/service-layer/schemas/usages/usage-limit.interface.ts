import { UnitOfMeasure } from '../unit-of-measure.interface';
export interface UsageLimit {
  usageLimitType?: string;
  usageType?: string;
  limit?: number;
  unitOfMeasure?: UnitOfMeasure;
}
