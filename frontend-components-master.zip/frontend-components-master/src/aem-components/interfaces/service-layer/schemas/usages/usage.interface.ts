import { UnitOfMeasure } from '../unit-of-measure.interface';
import { BillPeriod } from '../bills/bill-period.interface';

// TODO: UsageLimit is not defined well. Could be wrong here.
export interface Usage {
  usedUnits?: number;
  uom?: UnitOfMeasure;
  period?: Array<BillPeriod>;
  category?: UnitOfMeasure;
}
