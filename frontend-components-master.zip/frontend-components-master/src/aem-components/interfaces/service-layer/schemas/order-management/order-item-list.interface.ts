import { OrderItemInfo } from './order-item-info.interface';
export interface OrderItemList {
  orderItemInfo: OrderItemInfo[];
}
