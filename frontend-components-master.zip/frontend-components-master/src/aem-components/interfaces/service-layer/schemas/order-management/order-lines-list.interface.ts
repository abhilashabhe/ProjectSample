import { OrderLineInfo } from './order-line-info.interface';
export interface OrderLinesList {
  orderLineInfo: OrderLineInfo[];
}
