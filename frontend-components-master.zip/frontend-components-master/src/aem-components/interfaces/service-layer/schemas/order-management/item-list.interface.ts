import {ItemInfo} from './item-info.interface';
export interface ItemList {
  itemInfo: ItemInfo[];
}
