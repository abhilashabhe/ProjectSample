export interface GiveBackDeviceInfo {
  itemDesc: string;
  giveBackSerialNumber: string;
}
