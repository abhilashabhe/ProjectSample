import { IServiceInput } from '../..';
import { FastOrderKey } from './fast-order-key.interface';
export interface ManageOrders extends IServiceInput {
  manageDeviceOrderResponse?: FastOrderKey;
}
