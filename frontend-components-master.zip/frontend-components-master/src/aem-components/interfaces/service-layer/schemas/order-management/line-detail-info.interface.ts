import {GiveBackDeviceInfo} from './give-back-device-info.interface';
import {TradeInInfo} from './trade-in-info.interface';
export interface LineDetailInfo {
  lineSequenceNumber: string;
  mdn: string;
  giveBackDeviceInfo: GiveBackDeviceInfo;
  tradeInInfo: TradeInInfo;
}
