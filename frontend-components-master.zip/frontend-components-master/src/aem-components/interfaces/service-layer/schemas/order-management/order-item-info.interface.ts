export interface OrderItemInfo {
  status: string;
}
