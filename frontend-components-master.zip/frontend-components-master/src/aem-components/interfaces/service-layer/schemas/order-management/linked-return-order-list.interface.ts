import { LinkedReturnOrderInfo } from './linked-return-order-info.interface';

export interface LinkedReturnOrderList {
  linkedReturnOrderInfo: LinkedReturnOrderInfo[];
}
