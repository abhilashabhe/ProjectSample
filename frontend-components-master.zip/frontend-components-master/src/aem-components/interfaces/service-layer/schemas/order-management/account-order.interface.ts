export interface AccountOrder {
  orderDate: string;
  orderKey: string;
  rmaAuthorizationNumber: string;
  shipmentDate: number;
  streetNumber: string;
  addressLine1: string;
  apartment: string;
  city: string;
  state: string;
  zipCode: string;
}
