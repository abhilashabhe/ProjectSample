import { InventoryOrderInfo } from './inventory-order-info.interface';
export interface OrderLineInfo {
lineSequenceNumber: string;
itemId: string;
inventoryOrderInfo: InventoryOrderInfo;
}
