export interface FastOrderKey {
  fastOrderkey: string;
}
