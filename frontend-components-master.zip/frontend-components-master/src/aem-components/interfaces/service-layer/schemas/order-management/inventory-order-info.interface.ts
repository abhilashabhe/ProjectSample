import { OrderItemList } from './order-item-list.interface';
export interface InventoryOrderInfo {
orderItemList: OrderItemList;
}
