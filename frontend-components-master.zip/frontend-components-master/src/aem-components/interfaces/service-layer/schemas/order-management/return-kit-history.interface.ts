export interface ReturnKitHistory {
  orderKey: string;
  shippingStatus: string;
  streetNumber: string;
  addressLine1: string;
  apartment: string;
  city: string;
  state: string;
  zipCode: string;
  shipmentDate: string;
  orderDate: string;
  isShipped: Boolean;
  isDelivered: Boolean;
}
