import { ItemList } from './item-list.interface';

export interface LinkedReturnOrderInfo {
  itemList: ItemList;
}
