export interface ItemInfo {
  lineSequenceNumber: string;
  itemDesc: string;
}
