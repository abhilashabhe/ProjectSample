import { LineDetailList } from './line-detail-list.interface';
import { OrderLinesList } from './order-lines-list.interface';
import { ReturnKitHistory } from './return-kit-history.interface';
import { LinkedReturnOrderList } from './linked-return-order-list.interface';

export interface OrderInfo {
  lineDetailList: LineDetailList;
  shippingFirstName: string;
  shippingLastName: string;
  rmaLabelUrl: string;
  orderSource: string;
  status: string;
  linkedReturnOrderList: LinkedReturnOrderList;
  orderLinesList: OrderLinesList;
  returnKitHistory: ReturnKitHistory[];
}
