import { LineDetailInfo } from './line-detail-info.interface';
export interface LineDetailList {
  lineDetailInfo: LineDetailInfo[];
}
