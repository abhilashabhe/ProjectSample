export interface TradeInInfo {
  itemDesc: string;
  serialNumber: string;
}
