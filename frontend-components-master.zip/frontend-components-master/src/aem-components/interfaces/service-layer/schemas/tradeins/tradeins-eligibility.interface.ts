export interface TradeInsEligibilityRequest {
  params: {
    tradeInESN: string;
    tradeInProductId: string;
    purchaseDeviceId: string;
    subscriptionId?: string;
    offerGroupCode?: string;
    promoCode?: string;
    accountId?: string;
    accountType?: string;
    accountSubType?: string;
    offerSaleType?: string;
  };
}

export interface TradeInsEligibility {
  eligibility: boolean;
  appleLocked?: boolean;
}
