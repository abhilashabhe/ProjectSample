export interface TradeInsCarriersRequest {
  params: {
    carrierId: string
  };
}
