export interface TradeInsManufacturersProductsRequest {
  params: {
    carrierId: string
    manufacturerId: string
  };
}

export  interface TradeInsProductsRequest {
  params: {
    search: string
  };
}

export interface TradeInProduct {
  id: string;
  name: string;
  price: number;
  largeImage: string;
  smallImage: string;
}
