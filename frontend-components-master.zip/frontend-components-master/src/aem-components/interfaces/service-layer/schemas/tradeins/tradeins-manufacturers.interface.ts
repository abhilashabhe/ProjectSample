export interface TradeInsManufacturersRequest {
  params: {
    carrierId: string
  };
}
