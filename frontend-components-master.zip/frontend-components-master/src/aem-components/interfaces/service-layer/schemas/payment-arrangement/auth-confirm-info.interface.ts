export interface IAuthConfirmInfo {
  responseStatus?: string;
}
