import {ICheckAccountPaymentEligibilityResponse} from './check-account-payment-eligibility-response.interface';

export interface IPaymentEligibilityResponse {
  checkAccountPaymentEligibilityResponse?: ICheckAccountPaymentEligibilityResponse;
}
