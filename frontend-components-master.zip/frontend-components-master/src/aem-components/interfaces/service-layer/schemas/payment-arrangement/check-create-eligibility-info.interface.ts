export interface ICheckCreateEligibilityInfo {
  paymentSourceId?: string;
}
