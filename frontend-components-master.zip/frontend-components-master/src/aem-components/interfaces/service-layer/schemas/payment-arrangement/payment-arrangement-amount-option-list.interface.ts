import { IPaymentArrangementAmountOption } from './payment-arrangement-amount-option.interface';

export interface IPaymentArrangementAmountOptionList {
  paAmountOptionInfo?: IPaymentArrangementAmountOption[];
}
