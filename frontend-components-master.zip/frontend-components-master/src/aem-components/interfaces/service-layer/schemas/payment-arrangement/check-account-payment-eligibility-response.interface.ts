import {IEligibilityInfo} from './eligibility-info.interface';
import {IPaymentArrangementAmountOptionList} from './payment-arrangement-amount-option-list.interface';
import {IPaymentArrangementEligibilityDetailInfo} from './payment-arrangement-eligibility-detail-info.interface';

export interface ICheckAccountPaymentEligibilityResponse {
  fdpEligibilityInfo?: IEligibilityInfo;
  paEligibilityInfo?: IEligibilityInfo;
  fdpMaxDate?: string;
  paAmountOptionList?: IPaymentArrangementAmountOptionList;
  paEligibilityDetailInfo?: IPaymentArrangementEligibilityDetailInfo;
  netDisputeAmount?: number;
  aslBufferValue?: number;
  aslPaymentAmount?: number;
}
