import { IGetAccountRequestInterface } from '../accounts/account.api-requests.interface';
import { BankInfo } from '../future-dated-payments/bank-info.interface';
import { CardInfo } from '../future-dated-payments/card-info.interface';
import { IPaymentArrangementInstallment } from './payment-arrangement-installment.interface';

export interface IAccountUpdatePaymentArrangement extends IGetAccountRequestInterface {
  sourceId: string;
  sourceType: string;
  paymentMethodToken?: string;
  paymentMethodId?: string;
  futureDatedPaymentInd?: boolean;
  paymentMethod: string;
  paymentSubMethod?: string;
  bankInfo?: BankInfo;
  cardInfo?: CardInfo;
  installments?: IPaymentArrangementInstallment[];
}

