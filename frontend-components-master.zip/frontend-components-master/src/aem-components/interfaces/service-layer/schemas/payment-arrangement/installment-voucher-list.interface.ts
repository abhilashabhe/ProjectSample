import { IInstallmentVoucherInfo } from './installment-voucher-info.interface';

export interface IInstallmentVoucherList {
  installmentVoucherInfo: IInstallmentVoucherInfo[];
}
