import {ICheckCreateEligibilityInfo} from './check-create-eligibility-info.interface';
import {ICheckModifyEligibilityInfo} from './check-modify-eligibility-info.interface';
import {ICheckCancelEligibilityInfo} from './check-cancel-eligibility-info.interface';

export interface ICheckEligibilityInfo {
  checkCreateEligibilityInfo?: ICheckCreateEligibilityInfo;
  checkModifyEligibilityInfo?: ICheckModifyEligibilityInfo;
  checkCancelEligibilityInfo?: ICheckCancelEligibilityInfo;
}
