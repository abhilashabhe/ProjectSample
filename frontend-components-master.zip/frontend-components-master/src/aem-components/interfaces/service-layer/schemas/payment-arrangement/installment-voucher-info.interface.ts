export interface IInstallmentVoucherInfo {
  installmentDueDate?: string;
  voucherNumber?: string;
}
