export interface IPaymentArrangementInstallment {
  installmentNumber: number;
  installmentAmount: number;
  installmentDueDate: string;
}
