export interface ICheckModifyEligibilityInfo {
  paymentSourceId?: string;
  voucherNumber?: string;
}
