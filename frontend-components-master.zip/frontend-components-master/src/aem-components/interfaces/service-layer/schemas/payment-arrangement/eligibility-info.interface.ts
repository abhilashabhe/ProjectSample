export interface IEligibilityInfo {
  eligibilityInd?: boolean;
  ineligibilityReasonCode?: string;
  ineligibilityDesc?: string;
}
