import { IInstallmentVoucherList } from './installment-voucher-list.interface';
import { IAuthConfirmInfo } from './auth-confirm-info.interface';

export interface IPaymentArrangementResponsePrimary {
  message?: string;
  authConfirmInfo: IAuthConfirmInfo;
  installmentVoucherList: IInstallmentVoucherList;
  fdpVoucherNumber?: string;
  fdpDate?: string;
  fdpAmount?: number;
}
