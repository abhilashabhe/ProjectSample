import {ICheckEligibilityInfo} from './check-eligibility-info.interface';

export interface ICheckAccountPaymentEligibility {
  checkEligibilityInfo?: ICheckEligibilityInfo;
}
