export interface ICheckCancelEligibilityInfo {
  voucherNumber?: string;
}
