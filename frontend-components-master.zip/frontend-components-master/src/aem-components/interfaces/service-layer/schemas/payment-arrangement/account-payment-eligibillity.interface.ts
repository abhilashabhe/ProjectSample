import {ICheckAccountPaymentEligibility} from './check-account-payment-eligibility.interface';

export interface IAccountPaymentEligibility {
  checkAccountPaymentEligibility?: ICheckAccountPaymentEligibility;
}
