export interface IPaymentArrangementEligibilityDetailInfo {
  installmentInitialDate?: string;
  installmentMaxNumber?: number;
  installmentFrequency?: number;
  paMaxDaysLength?: number;
  paMaxEndDate?: string;
  paMaxNumber?: number;
}
