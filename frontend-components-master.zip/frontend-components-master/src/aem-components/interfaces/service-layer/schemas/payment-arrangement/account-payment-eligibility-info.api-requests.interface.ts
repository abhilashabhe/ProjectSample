import { IGetAccountRequestInterface } from '../accounts/account.api-requests.interface';
import { IAccountPaymentEligibility } from './account-payment-eligibillity.interface';
import { CreatePaymentArrangementPrimary } from './payment-arrangement-create.interface';
import { IPaymentArrangementResponsePrimary } from './payment-arrangement-response.interface';

export interface IPostAccountPaymentEligibility extends IGetAccountRequestInterface {
  data: IAccountPaymentEligibility;
}

export interface IPostCreatePaymentArrangement {
  createPA: CreatePaymentArrangementPrimary;
}

export interface IPostPaymentArrangementRequestInterface extends IGetAccountRequestInterface {
  data: IPostCreatePaymentArrangement;
}

export interface IPaymentArrangementResponse {
  createPaymentArrangementResponse: IPaymentArrangementResponsePrimary;
}

export interface IPutPaymentArrangement {
  modifyPA: CreatePaymentArrangementPrimary;
}

export interface IPutPaymentArrangementRequestInterface extends IGetAccountRequestInterface {
  data: IPutPaymentArrangement;
}

export interface IPutPaymentArrangementResponse {
  managePaymentArrangementResponse: IPaymentArrangementResponsePrimary;
}
