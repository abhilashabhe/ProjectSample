import { BankInfo } from '../future-dated-payments/bank-info.interface';
import { CardInfo } from '../future-dated-payments/card-info.interface';
import { IPaymentArrangementInstallment } from './payment-arrangement-installment.interface';

export interface CreatePaymentArrangementPrimary {
  sourceId: string;
  sourceType: string;
  paymentMethodToken?: string;
  paymentMethodId?: string;
  paymentMethod: string;
  paymentSubMethod?: string;
  bankInfo?: BankInfo;
  cardInfo?: CardInfo;
  installments?: IPaymentArrangementInstallment[];
  futureDatedPaymentInd?: boolean;
}

