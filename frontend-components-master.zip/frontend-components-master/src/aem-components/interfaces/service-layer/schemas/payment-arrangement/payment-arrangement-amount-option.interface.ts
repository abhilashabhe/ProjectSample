export interface IPaymentArrangementAmountOption {
  optionType?: string;
  amount?: number;
  optionLabelCode?: string;
  upfrontPayReqInd?: boolean;
  upfrontAmt?: number;
}
