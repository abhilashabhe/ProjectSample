import { IServiceInput } from '../..';

export interface IConfirmPlanRequest extends IServiceInput {
  pathParams: {
    orderid: string;
  };
  data: {
    suppressEmail: boolean;
  };
}
