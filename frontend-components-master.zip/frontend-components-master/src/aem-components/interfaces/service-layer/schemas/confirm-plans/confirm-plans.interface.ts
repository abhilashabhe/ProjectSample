export interface IConfirmPlan {
  data: {
    orderKey: string;
  };
}
