import {IServiceInput} from '../../service-input.interface';

export interface CustomerServiceAreasRequest extends IServiceInput {
  params: {
    latitude?: string;
    longitude?: string;
  };
}

export interface CustomerServiceArea {
  csaCode?: string;
  zipCode?: string;
}
