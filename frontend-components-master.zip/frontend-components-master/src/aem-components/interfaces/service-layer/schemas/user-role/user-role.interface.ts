export interface UserRole {
  userId?: string;
  userName?: string;
  ptn?: string;
  roleId?: string;
  roleName?: string;
  accountId?: string;
  userRole?: number;
  requestStatus?: string;
  previousUserRole?: string;
  updatingUserRole?: string;
  status?: string;
}
