import { IServiceInput } from '../..';

export interface IGetUserRole extends IServiceInput {
  pathParams: {
    userId: string;
  };
  queryParams: {
    role: string;
  };
}

export interface IPutUserRoles extends IServiceInput {
  pathParams: {
    accountId: string;
    userId: string;
  };
  data: {
    updateRoleRequest: {
      userID: string;
      updatingUserRole: string;
      status: string;
    }[];
  };
}
