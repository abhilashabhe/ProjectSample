import { IServiceInput } from '../..';

export interface IGetAppointmentsRequest extends IServiceInput {
  queryParams: {
    zipCode: string;
    locale: string;
    numberOfLines: string;
    spanishInd: string;
  };
}
