export interface DeliveryAppointment {
  datetime?: string;
  duration?: string;
}

export interface Appointments {
  appointmentServiceId?: string;
  timeZone?: string;
  deliveryAppointments?: Array<DeliveryAppointment>;
}
