export interface OfferInfoInterface {
  offerId: number;
  pyOutcome: string;
}
