import { OfferInfoInterface } from './offer-info.interface';

export interface OfferDispositionInterface extends OfferInfoInterface {
  offerDispositionRequest: {
    subscriberId: string;
    intentId: string;
    offerList: {
      offerInfo: Array<OfferInfoInterface>
    }
  }
}
