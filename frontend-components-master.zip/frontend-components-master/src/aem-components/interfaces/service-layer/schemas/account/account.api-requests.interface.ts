import { IServiceInput } from '../../';

export interface IPutProfileOffersRequest extends IServiceInput {
  profileOffersRequest: {
    intentId: string;
  }
}

export interface IProfileOffersResponse extends IServiceInput {
  profileOffersResponse: {
    message: string;
  }
}

export interface IPutOfferDispositionRequest extends IServiceInput {
  offerDispositionRequest: {
    intentId: string;
    offerList: {
      offerInfo: [
        {
          offerId: number;
          pyOutcome: string;
        }
        ]
    }
  }
}

export interface IOfferDispositionResponse extends IServiceInput {
  offerDispositionResponse: {
    message: string;
  }
}
