export interface ProfileOffersInterface {
  profileOffersRequest: {
    subscriberId: string;
    intentId: string;
  }
}
