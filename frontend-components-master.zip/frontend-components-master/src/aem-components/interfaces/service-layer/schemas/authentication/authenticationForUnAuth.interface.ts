import { IServiceInput } from '../..';
export interface AuthenticationForUnAuth extends IServiceInput {
  access_token?: string;
  refresh_token?: string;
  expires_in?: string;
}
