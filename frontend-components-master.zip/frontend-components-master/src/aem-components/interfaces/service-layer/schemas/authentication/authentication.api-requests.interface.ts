import { IServiceInput } from '../..';

export interface ICheckAuthenticationRequest extends IServiceInput {
  data: {};
}

export interface IAuthenticationRequest extends IServiceInput {
  headers: {
    authorization: string;
  };
  data: {
    username?: string;
    password?: string;
    clientKey?: string;
  };
}
