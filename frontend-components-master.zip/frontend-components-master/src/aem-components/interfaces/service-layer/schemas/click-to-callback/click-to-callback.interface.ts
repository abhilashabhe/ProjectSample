export interface ClickToCallBack {
  callbackAvailability?: string;
  earliestScheduleTime?: string;
  latestScheduleTime?: string;
  earliestScheduleTimeTomorrow?: string;
  latestScheduleTimeTomorrow?: string;
  expectedWaitTime?: string;
  callsInQueue?: string;
  offerExpiry?: string;
  status?: string;
  statusDescription?: string;
}
