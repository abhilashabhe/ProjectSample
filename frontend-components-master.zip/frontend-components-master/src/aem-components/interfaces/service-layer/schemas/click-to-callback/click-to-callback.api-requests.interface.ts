import { IServiceInput } from '../..';

export interface IGetClickToCallBackRequest extends IServiceInput {

  pathParams: {
    customerId: string;
  };
  queryParams: {
    brand: string;
    intent: string;
  };
}

export interface IPostClickToCallBackRequest extends IServiceInput {
  pathParams: {
    customerId: string;
  };
  data: {
      clickToCallBack: {
        callbackNumber: string;
        intent: string;
        sessionId: string;
        callbackType: string;
        banPtn: string;
        customerName: string;
        isAuthenticated: boolean;
        brand: string;
        location: string;
      };
  };
}
