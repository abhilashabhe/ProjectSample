import { IServiceInput } from '../..';
import { flow } from '../lookup-devices/lookup-devices.api-request.interface';

export interface IEligibilityRequest extends IServiceInput {
  queryParams: {
    type: flow;
    subscriberId?: string;
  };
}
