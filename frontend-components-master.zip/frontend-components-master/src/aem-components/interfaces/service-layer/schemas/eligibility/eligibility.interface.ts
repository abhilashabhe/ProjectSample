import { flow } from '../lookup-devices/lookup-devices.api-request.interface';
import { IServiceError } from '../../service-error.interface';

export interface IEligibility {
  type: flow;
  browseEligible: boolean;
  addToCartEligible: boolean;
  checkoutEligible: boolean;
  errors?: IServiceError[];
}
