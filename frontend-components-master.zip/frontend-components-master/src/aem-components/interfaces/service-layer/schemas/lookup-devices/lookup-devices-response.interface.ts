export type DevicePurchaseMethod = 'Lease' | 'InstallmentBilling' | 'FULL_SRP' | 'SUBSIDY';

export interface LookupDevicesGroup {
  defaultProductId?: string;
  groupId?: string;
  products: LookupDevicesProduct[];
}

export interface LookupDevicesProduct {
  defaultItemId?: string;
  productId?: string;
  items?: LookupDevicesItem[];
}

export interface LookupDevicesItem {
  contractPricings: ContractPricing[];
  inventoryStatus?: string;
  itemId?: string;
  purchaseMechanism?: string;
}

export interface ContractPricing {
  baseMonthlyPayment?: number;
  contractInfo?: ContractInfo;
  finalMonthlyPayment?: number;
  macDiscounts?: DeviceMacDiscount[];
  nonMACDiscounts?: DeviceNonMacDiscount[];
  todaysTotal?: number;
}

export interface ContractInfo {
  contractId?: string;
  creditCheckNeeded?: boolean;
  offerGroupCode?: string;
  promoCode?: string | null;
  paymentDuration?: number;
  purchaseMethod?: DevicePurchaseMethod;
  tradeInRequired?: boolean;
}

export interface DeviceMacDiscount {
  macId: string;
  macName: string;
  macDescription?: string;
  macStatus: string;
  effectiveDate?: string;
  amount: number;
  duration?: number;
}

export interface DeviceNonMacDiscount {
  discountType: string;
  discountAmount: number;
  discountId: string;
  duration: number;
  couponCodes?: string[];
}
