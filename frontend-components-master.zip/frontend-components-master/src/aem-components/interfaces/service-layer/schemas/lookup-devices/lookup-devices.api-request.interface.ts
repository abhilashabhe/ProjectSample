import { IServiceInput } from '../..';
import { IApplicationID } from '../index';

export type defaultSKUPrice = 'NO_PRICING' | 'SINGLE_PRICING' | 'ALL_PRICING';
export type deviceType = 'PHONES' | 'TABLETS_AND_LAPTOPS' | 'HOTSPOTS_AND_MBB' | 'ALL_DEVICES';
export type flow = 'GROSS_ADD' | 'UPGRADE' | 'GROSSADD';

export interface ILookupDevicesRequest extends IServiceInput {
  queryParams: {
    accountType?: string;
    accountSubType?: string;
    applicationId?: IApplicationID,
    ban?: string;
    corpId?: string;
    creditClass?: string;
    defaultSKUPrice: defaultSKUPrice;
    deviceType?: deviceType;
    flow: flow;
    nonDefaultItems?: boolean;
    salesChannelCode?: string;
    subscriberId?: string;
    zipCode?: string;
  };
}

export interface ILookupDeviceByGroupId extends ILookupDevicesRequest {
  pathParams: {
    groupId: string;
  };
}

export interface ILookupDeviceByProductId extends ILookupDevicesRequest {
  pathParams: {
    productId: string;
  };
}

export interface ILookupDeviceByItemId extends ILookupDevicesRequest {
  pathParams: {
    itemId: string;
  };
}
