import { CreditClass } from '../orders/creditCheck.interface';

export interface FinanceInfoCreditInfo extends CreditClass {
  authorizedLineLimit: number;
  creditCheckApplicationNumber: string;
}
