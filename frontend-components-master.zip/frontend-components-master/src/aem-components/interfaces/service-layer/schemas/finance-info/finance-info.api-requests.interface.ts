import { IServiceInput } from '../..';
import { FinanceInfoContactInfo } from './finance-info-contact-info.interface';
import { CreditCheck } from '../orders/creditCheck.interface';

export interface PostFinanceInfo extends IServiceInput {
  data: {
    contactInfo: FinanceInfoContactInfo;
    creditCheckInfo: CreditCheck;
  };
}



