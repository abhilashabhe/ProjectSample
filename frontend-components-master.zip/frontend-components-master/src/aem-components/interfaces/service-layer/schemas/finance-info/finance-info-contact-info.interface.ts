import { Address } from '../address.interface';
import { Contact } from '../contact.interface';
import { Name } from '../name.interface';

export interface FinanceInfoContactInfo {
  address: Address;
  contact: Contact;
  name: Name;
}
