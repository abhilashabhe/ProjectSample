import { Address } from '../address.interface';
import { FinanceInfoCreditInfo } from './finance-info-credit-info.interface';
import { IServiceError } from '../../service-error.interface';

export interface FinanceInfoCreditCheckResponse {
  creditInformation: FinanceInfoCreditInfo;
  correctedAddress?: Address;
  errors?: Array<IServiceError>;
}




