export class DiscountTypeEnum {
  static get ARM(): string {
    return 'ARM';
  }

  static get BOGO(): string {
    return 'BOGO';
  }

  static get SIEBEL(): string {
    return 'SIEBEL';
  }

  static get UFP(): string {
    return 'UFP';
  }

  static get WEB_PROMO(): string {
    return 'WEB_PROMO';
  }

  static get UNKNOWN(): string {
    return 'UNKNOWN';
  }

  static get UPGNOW(): string {
    return 'UPGNOW';
  }

  static get MIR(): string {
    return 'MIR';
  }

  static get INVCR(): string {
    return 'INVCR';
  }

  static get INST(): string {
    return 'INST';
  }
}
