import { ChargeTypeEnum } from './charge-type.enum';

describe('Charge Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof ChargeTypeEnum.MRC_CHARGE).toBe('string');
    expect(typeof ChargeTypeEnum.ONE_TIME_CHARGE).toBe('string');
  });

});
