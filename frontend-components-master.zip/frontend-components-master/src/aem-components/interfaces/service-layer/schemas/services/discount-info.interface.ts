import { DiscountTypeEnum } from './discount-type.enum';
export interface DiscountInfo {
  discountSequenceNumber?: string;
  discountType?: DiscountTypeEnum;
  code?: string;
  description?: string;
  amount?: number;
}
