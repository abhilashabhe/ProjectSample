import { ServicePricing } from './pricing.interface';
export interface Service {
  sku?: string;
  description?: string;
  name?: string;
  category?: string;
  price?: ServicePricing;
  soc?: string;
}
