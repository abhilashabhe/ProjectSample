import { ChargeTypeEnum } from './charge-type.enum';
import { DiscountInfo } from './discount-info.interface';
// Changed at Patrick's request
export interface ServicePricing {
  retailPrice?: number;
  price?: number;
  chargeType?: ChargeTypeEnum;
  discounts?: Array<DiscountInfo>;
}
