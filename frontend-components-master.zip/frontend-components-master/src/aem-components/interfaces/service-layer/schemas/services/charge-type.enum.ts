export class ChargeTypeEnum {
  static get MRC_CHARGE(): string {
    return 'MRC_CHARGE';
  }

  static get ONE_TIME_CHARGE(): string {
    return 'ONE_TIME_CHARGE';
  }
}
