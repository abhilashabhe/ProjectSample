import { SelectionTypeEnum } from './selection-type.enum';

describe('Selection Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof SelectionTypeEnum.MULTI_SELECT).toBe('string');
    expect(typeof SelectionTypeEnum.SINGLE_SELECT).toBe('string');
  });

});
