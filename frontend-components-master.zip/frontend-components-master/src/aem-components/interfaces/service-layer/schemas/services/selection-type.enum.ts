export class SelectionTypeEnum {
  static get SINGLE_SELECT(): string {
    return 'SINGLE_SELECT';
  }

  static get MULTI_SELECT(): string {
    return 'MULTI_SELECT';
  }
}
