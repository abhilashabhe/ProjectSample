import { DiscountTypeEnum } from './discount-type.enum';

describe('Discount Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof DiscountTypeEnum.ARM).toBe('string');
    expect(typeof DiscountTypeEnum.BOGO).toBe('string');
    expect(typeof DiscountTypeEnum.INST).toBe('string');
    expect(typeof DiscountTypeEnum.INVCR).toBe('string');
    expect(typeof DiscountTypeEnum.MIR).toBe('string');
    expect(typeof DiscountTypeEnum.SIEBEL).toBe('string');
    expect(typeof DiscountTypeEnum.UFP).toBe('string');
    expect(typeof DiscountTypeEnum.UNKNOWN).toBe('string');
    expect(typeof DiscountTypeEnum.UPGNOW).toBe('string');
    expect(typeof DiscountTypeEnum.WEB_PROMO).toBe('string');
  });

});
