import { ServicePricing } from './pricing.interface';
export interface ServiceProduct {
  serviceId?: string;
  productId?: string;
  description?: string;
  name?: string;
  carryForward?: boolean;
  systemRemove?: boolean;
  price?: ServicePricing;
}
