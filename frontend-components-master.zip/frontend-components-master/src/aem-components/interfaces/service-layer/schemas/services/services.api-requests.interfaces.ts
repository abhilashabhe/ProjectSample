import { IServiceInput } from '../..';

export interface IGetServicesRequest extends IServiceInput {
  queryParams: {
    deviceId: string;
    csa: string;
    accountType: string;
    accountSubType: string;
    planSoc?: string;
    creditClass: string;
    flow: string;
    category?: string;
    deviceSaleType?: string;
  };
}

export interface IGetServiceRequest extends IGetServicesRequest {
  pathParams: {
    serviceId: string;
  };
}
