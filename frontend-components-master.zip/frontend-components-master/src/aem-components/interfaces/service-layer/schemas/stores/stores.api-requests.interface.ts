import { IServiceInput } from '../..';

export interface IGetStoreAppointmentsRequestInterface extends IServiceInput {
  pathParams: {
    storeId: string;
  };
  queryParams: {
    startDateTime: string;
    endDateTime: string;
    duration: string;
  };
}

export interface IGetStoreInventoryRequestInterface extends IServiceInput {
  pathParams: {
    storeId: string;
  };
  queryParams: {
    deviceIds: string;
  };
}
