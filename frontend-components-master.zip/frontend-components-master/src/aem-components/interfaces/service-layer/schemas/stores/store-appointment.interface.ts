export interface StoreAppointment {
  appointmentAvailable?: string;
}
