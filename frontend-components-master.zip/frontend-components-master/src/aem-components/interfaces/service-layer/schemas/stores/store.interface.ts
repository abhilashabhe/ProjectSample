import { Address } from '../';

export interface Store {
  name?: string;
  phone?: string;
  storeId?: string;
  address?: Address;
}
