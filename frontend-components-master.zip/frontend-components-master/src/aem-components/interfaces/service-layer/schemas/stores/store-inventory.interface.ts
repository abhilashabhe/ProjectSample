export interface StoreInventory {
  storeId?: string;
  deviceId?: string;
  availableQuantity?: number;
  isReserveEligible?: boolean;
}
