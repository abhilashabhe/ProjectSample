import { IServiceInput } from '../..';

export interface ICheckEligibilityRequest extends IServiceInput {

  pathParams: {
    accountId: string;
    subscriberId: string;
  };
  queryParams: {
    flow: string;
  };
}
