# Schemas

Schemas contained in this directory are entirely based on API schemas contained in the [Digital APIs Repository](https://github.com/SprintDigital/digital-apis). This directory should not contain any other interfaces or schemas.

This directory contains a barrel that exports all interfaces. Do not include this barrel in any other barrel. Doing so could lead to name conflicts as well as confusion regarding what interface a person is importing.
