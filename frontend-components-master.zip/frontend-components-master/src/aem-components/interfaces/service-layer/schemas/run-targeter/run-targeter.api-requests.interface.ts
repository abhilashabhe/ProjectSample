import {Targeters} from './targeters.interface';

export interface IPostRunTargeterRequest {
  header: {
    applicationId: string;
  };
  target: {
    targeters: Targeters[];
    targeterParameters: {
      requestParameters: any;
      profileParameters: any;
    }
  };
}
