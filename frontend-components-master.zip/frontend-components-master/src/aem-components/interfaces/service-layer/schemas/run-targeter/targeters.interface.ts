export interface Targeters {
  targeterName: string;
  numberOfKeys: number;
  random: boolean;
}
