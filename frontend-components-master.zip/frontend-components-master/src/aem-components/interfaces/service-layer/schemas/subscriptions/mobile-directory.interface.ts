export interface MobileDirectory {
  number?: string;
}
