export interface AccountSubscription {
  id?: string;
  ptn?: string;
  nickName?: string;
  callerId?: string;
  esn?: string;
  itemId?: string;
  unlockSimCapable?: boolean;
  status?: string;
  modelName?: string;
  primary?: boolean;
}
