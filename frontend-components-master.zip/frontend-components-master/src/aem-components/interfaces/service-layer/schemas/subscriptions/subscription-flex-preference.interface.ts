import { IGetAccountSubscriptionRequestInterface } from '../accounts/account.api-requests.interface';
import { FlexPreference } from '../subscriptions/flex-preference-data.interface';

export interface IPutFlexPreferenceInterface extends IGetAccountSubscriptionRequestInterface {
  data: FlexPreference;
}

