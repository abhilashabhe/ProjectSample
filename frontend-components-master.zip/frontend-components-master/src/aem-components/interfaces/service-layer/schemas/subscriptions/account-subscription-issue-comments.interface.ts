export interface AccountSubscriptionIssueComment {
  maximum: number;
}
