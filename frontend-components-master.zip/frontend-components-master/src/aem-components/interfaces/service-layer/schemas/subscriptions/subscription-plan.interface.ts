import {SubscriptionPlanFeature} from './subscription-plan-features.interface';

export interface SubscriptionPlan {
  planId?: string;
  planName?: string;
  recurringCharge?: number;
  features?: SubscriptionPlanFeature[];
}
