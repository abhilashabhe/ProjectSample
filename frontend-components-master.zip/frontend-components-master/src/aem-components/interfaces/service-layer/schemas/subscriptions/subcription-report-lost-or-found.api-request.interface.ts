export type IOption = 'RESTRICT_SERVICE'|'ACTIVATE_NEW'|'REMOVE_CONFLICT'|'REPORT_FOUND';

export interface IPostReportLostOrFound {
  option: IOption;
  socConflictList: string[];
}
