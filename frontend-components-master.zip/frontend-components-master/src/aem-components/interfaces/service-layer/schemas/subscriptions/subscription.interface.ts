import { MobileDirectory } from './mobile-directory.interface';
export interface Subscription {
  id?: string;
  accountId?: string;
  mdn?: MobileDirectory;
  nickname?: string;
}
