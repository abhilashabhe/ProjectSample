export type IPreferenceType = 'INTERESTED'|'NOT_INTERESTED';

export interface FlexPreference {
  option: IPreferenceType;
  paramValue: number;
}
