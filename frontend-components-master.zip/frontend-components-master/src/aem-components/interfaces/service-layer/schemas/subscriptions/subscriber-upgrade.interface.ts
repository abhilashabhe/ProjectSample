import { LoanDetails } from '../carts/loan-details.interface';
export interface SubscriberUpgrade {
  subscriberId?: string;
  ptn?: string;
  deviceModelName?: string;
  deviceEnsembleId?: string;
  subscriberDisplayName?: string;
  deviceTabId?: string;
  display?: {
    displayClass?: string;
  };
  armnfo?: {
    eligibleInd?: boolean;
    tier?: string;
    eligibleDate?: string;
    channelExclusiveInd?: boolean;
  };
}

export interface SubscriberUpgradeTransformed extends SubscriberUpgrade {
  isEligibleForUpgrade?: boolean;
  contractLength?: string;
  monthsUntilUpgrade?: string;
  isEarlyUpgrade?: boolean;
  displayDate?: string;
  leaseInfo?: {
    turnInCost?: number;
    turnInCredit?: number;
    purchaseCost?: number;
    giveBackEnsembleId?: string;
    leaseTermStatus?: string;
    isEligibleForTradeIn?: boolean;
    isEligibleForBuyBack?: boolean;
    hasLeaseTradeInValue?: boolean;
  };
  needsLeaseResolve?: boolean;
  needsIBResolve?: LoanDetails;
  iBInfo?: number;
  subscriberStatusList: string[];
}
