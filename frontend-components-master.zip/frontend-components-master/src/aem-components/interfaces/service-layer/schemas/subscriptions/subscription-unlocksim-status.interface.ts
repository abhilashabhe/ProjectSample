import {UnlockSimResponse} from './subscription-unlocksim-request-response.interface';

export interface IUnlockSimStatus {
  status: string;
  response: UnlockSimResponse[];
}
