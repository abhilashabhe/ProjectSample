export type IdeviceLockStatus = 'LOCKED' | 'UNLOCKED_INTERNATIONAL_ONLY' | 'UNLOCKED_INTERNATIONAL_AND_DOMESTIC';

export interface IGetUnlockSim {
   deviceLockStatus: IdeviceLockStatus;
   devicelockUnlockDate?: string;
   isCapable: boolean;
}

