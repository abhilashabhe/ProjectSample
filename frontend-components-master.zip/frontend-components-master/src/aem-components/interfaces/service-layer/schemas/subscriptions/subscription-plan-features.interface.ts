export interface SubscriptionPlanFeature {
  name?: string;
  charge?: number;
  socCode?: string;
}
