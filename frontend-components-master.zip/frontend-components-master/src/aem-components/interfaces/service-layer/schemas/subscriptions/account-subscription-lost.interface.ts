export interface AccountSubscriptionLost {
  lostOrStolen?: boolean;
}
