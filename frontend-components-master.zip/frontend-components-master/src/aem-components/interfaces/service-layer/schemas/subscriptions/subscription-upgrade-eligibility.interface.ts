export interface SubscriptionUpgradeEligibility {
  eligible: boolean;
  subsidy: boolean;
  lease: boolean;
  installmentBilling: boolean;
  subsidyEligibleDate: string;
  leaseEligibleDate: string;
  installmentBillingEligibleDate: string;
}
