
export interface AccountSubscriptionIssueType {
  type: string;
}
