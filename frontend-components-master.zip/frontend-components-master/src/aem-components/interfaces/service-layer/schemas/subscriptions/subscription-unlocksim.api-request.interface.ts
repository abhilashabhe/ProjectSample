export interface IPostUnlockSim {
  ptn: string;
  endUserIp: string;
  blackbox: string;
  userfunction: string;
}
