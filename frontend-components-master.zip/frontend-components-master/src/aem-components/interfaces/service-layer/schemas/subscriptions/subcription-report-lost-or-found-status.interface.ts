export interface IReportLostOrFoundStatus {
  status: string;
  socConflicts: string[];
}
