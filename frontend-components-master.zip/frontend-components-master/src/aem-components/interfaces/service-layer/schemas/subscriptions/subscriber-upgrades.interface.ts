import { SubscriberUpgradeTransformed } from './subscriber-upgrade.interface';
export interface SubscriberUpgrades {
  ban?: string;
  subscriberList?: SubscriberUpgradeTransformed[];
  hasMoreSubscribers?: boolean;
  error?: {
    code?: string;
    message?: string;
  };
}
