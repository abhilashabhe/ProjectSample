import { IServiceInput } from '../../';
import { AccountSubscription } from '../subscriptions/account-subscription.interface';
import { IGetAccountSubscriptionRequestInterface } from '../accounts/account.api-requests.interface';

export interface IGetSubscriberUpgradeInfoRequestInterface extends IServiceInput {
  pathParams: {
    accountId: string;
  };
}

export interface IPutAccountSubscriptionRequestInterface extends IGetAccountSubscriptionRequestInterface {
  data: AccountSubscription ;
}
