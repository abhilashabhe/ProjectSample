import { Usage } from '../usages/usage.interface';
export interface SubscriptionGroup {
  id?: string;
  usages?: Array<Usage>;
}
