export interface SubscriptionService {
  socCode: string;
  name: string;
  charge: string;
  startDate: string;
}
