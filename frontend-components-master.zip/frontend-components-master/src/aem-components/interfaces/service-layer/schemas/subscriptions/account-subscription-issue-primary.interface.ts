import {AccountSubscriptionIssueType} from './account-subscription-issue-type.interface';

export interface AccountSubscriptionIssuePrimary {
  type: Array<AccountSubscriptionIssueType>;
  comments: string;
}
