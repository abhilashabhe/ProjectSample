import {SubscriptionUsagePrimary} from './subscription-usage-primary.interface';
export interface SubscriptionUsageBuckets {
  talk?: SubscriptionUsagePrimary[];
  'push to talk'?: SubscriptionUsagePrimary[];
  text?: SubscriptionUsagePrimary[];
  data?: SubscriptionUsagePrimary[];
}
