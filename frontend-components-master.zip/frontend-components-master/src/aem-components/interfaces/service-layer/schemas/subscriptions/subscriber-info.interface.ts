import {Subscriber} from './subscriber.interface';
import {SubscriberAnalytics} from './subscriber-analytics.interface';
export interface SubscriberInfo {
  header: {
    requestId: string
    appId: string
  };
  getSubscriberUpgradeInfo: {
    hasMoreSubscribers: boolean,
    ban: string,
    subscriberList: Subscriber[]
  };
  analytics: SubscriberAnalytics;
}
