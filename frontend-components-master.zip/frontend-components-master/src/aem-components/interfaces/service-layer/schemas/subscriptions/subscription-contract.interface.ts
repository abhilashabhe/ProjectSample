export interface SubscriptionContractInterface {
    contractType?: string;
    contractId?: string;
    monthlyPayment?: number;
    durationInMonths?: number;
    timeRemainingInMonths?: number;
    purchaseOptionPrice?: number;
    extendedMonthly?: number;
    startDate?: string;
    upfrontPayment?: number;
    payOffAmount?: number;
    leaseSequenceNumber?: number;
    flexLeaseInd?: boolean;
    flexPurchasePreferenceInd?: string;
}
