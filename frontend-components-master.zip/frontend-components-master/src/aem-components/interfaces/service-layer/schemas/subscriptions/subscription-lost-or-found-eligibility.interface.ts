export interface IAccountSubscriptionLostFound {
  eligibilityIndicator: boolean;
  ineligibleReasonCode: string;
  ineligibleReasonDescription: string;
}
