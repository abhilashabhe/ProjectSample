export interface SubscriptionPlanInfo {
  planType?: string;
  pricePlanChangeDate?: string;
  pricePlanChangeType?: string;
  pricePlanCode?: string;
  pricePlanName?: string;
  shareUsageExclusionId: string;
}
