export interface SubscriptionUsagePrimary {
  additionalCharge?: string;
  additionalUsedUnits?: string;
  bucketType?: string;
  category?: string;
  displayOrder?: string;
  effectiveDate?: string;
  expirationDate?: string;
  includedUnits?: string;
  name?: string;
  remainingUnits?: string;
  sharingOfferId?: string;
  soc?: string;
  subsectionId?: string;
  subsectionName?: string;
  unitOfMeasure?: string;
  usageCategoryCode?: string;
  usageCategoryGroupName?: string;
  usageCategoryName?: string;
  usedUnits?: string;
}
