import { BillPeriod } from '../bills/bill-period.interface';
import { SubscriptionUsageBuckets } from './subscription-usage-buckets.interface';
import { SubscriptionPlanInfo } from './subscription-plan-info.interface';
export interface AccountSubscriptionUsage {
  period?: BillPeriod;
  billSequence?: number;
  sharedBuckets?: SubscriptionUsageBuckets;
  individualBuckets?: SubscriptionUsageBuckets;
  planInfo?: SubscriptionPlanInfo;
}
