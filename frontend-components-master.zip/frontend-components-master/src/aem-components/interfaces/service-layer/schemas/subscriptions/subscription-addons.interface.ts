export interface SubscriptionAddons {
  sku?: string;
  description?: string;
  status?: string;
  type?: string;
  price?: number;
  onPromotion?: boolean;
  hasPromotionalOfferButNotEligible?: boolean;
}
