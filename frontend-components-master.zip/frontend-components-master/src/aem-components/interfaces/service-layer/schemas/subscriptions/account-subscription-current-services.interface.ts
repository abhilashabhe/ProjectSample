import { SubscriptionService } from './subscription-service.interface';

export interface AccountSubscriptionCurrentServices {
  accountLevelServices: SubscriptionService[];
  subscriptionLevelServices: SubscriptionService[];
}
