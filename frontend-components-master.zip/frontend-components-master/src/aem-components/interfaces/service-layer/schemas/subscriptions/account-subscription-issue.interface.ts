import {AccountSubscriptionIssuePrimary} from './account-subscription-issue-primary.interface';
export interface AccountSubscriptionIssue {
  properties: Array<AccountSubscriptionIssuePrimary>;

}
