export interface UnlockSimResponse {
  code: string;
  message: string;
}
