import { LoanDetails } from '../carts/loan-details.interface';

export interface Subscriber {
  subscriberDisplayName: string;
  statusInd: [
    {
      value: string;
    }
  ];
  armnfo: {
    channelExclusiveInd: boolean,
    tier: string;
    eligibleDate: string;
    eligibleInd: boolean;
  };
  deviceTabId: string;
  siebelOffers: string[];
  leaseDetails: {
    leaseTermStatus: string;
    amountToPurchase: number;
    amountToTurnIn: number;
    deviceTurnInCredit: number;
    eligibleTunInDevice: boolean;
    givebackDeviceEnsembleId: string;
    givebackDeviceEsn: string;
    checkStatusList: [
      {
        value: string;
      }
      ];
    leaseStatus: number;
  };
  subscriberId: string;
  ptn: string;
  deviceModelName: string;
  deviceEnsembleId: string;
  loanDetails: LoanDetails;
}
