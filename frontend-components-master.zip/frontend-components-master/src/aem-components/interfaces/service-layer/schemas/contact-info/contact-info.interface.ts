export interface IGetContactInfo {
  contactNumber: string;
  communicationEmailAddress?: string;
  communicationMethod?: string;
  securityCommunicationMethod?: string;
  securityCommunicationSMS?: string;
  securityEmailAddress?: string;
  textCapablePTNs?: Array<string>;
}
