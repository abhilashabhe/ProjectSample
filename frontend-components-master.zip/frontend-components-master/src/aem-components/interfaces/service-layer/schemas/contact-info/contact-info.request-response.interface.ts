export interface IPutContactInfo {
  responseMessage: string;
}
