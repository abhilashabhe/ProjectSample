import { IGetAccountRequestInterface } from '../accounts/account.api-requests.interface';

export interface IContactInfoRequestDataInterface {
  contactNumber: string;
  communicationEmailAddress?: string;
  communicationMethod?: string;
  securityCommunicationMethod?: string;
  securityCommunicationSMS?: string;
  securityEmailAddress?: string;
  textCapablePTNs?: Array<string>;
}

export interface IContactInfoRequestInterface extends IGetAccountRequestInterface {
  data: IContactInfoRequestDataInterface;
}
