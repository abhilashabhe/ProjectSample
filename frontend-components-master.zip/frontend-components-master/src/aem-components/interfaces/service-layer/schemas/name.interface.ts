export interface Name {
  firstName?: string;
  lastName?: string;
}
