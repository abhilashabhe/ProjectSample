export interface CardInfo {
  cardNum: string;
  expDate: string;
  secCode: string;
  nameOnCard: string;
  zipCode: string;
  isPinlessDebit?: boolean;
}
