export interface BankInfo {
  routingNum: string;
  AcctNum?: string;
}
