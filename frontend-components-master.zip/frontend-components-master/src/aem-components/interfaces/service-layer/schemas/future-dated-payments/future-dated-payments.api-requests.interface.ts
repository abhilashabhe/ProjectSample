import { IGetAccountRequestInterface } from '../accounts/account.api-requests.interface';
import { AccountFutureDatePaymentsPrimary } from './account-future-dated-payments.interface';

export interface IPostFutureDatedPayments {
  createFDP: AccountFutureDatePaymentsPrimary;
}

export interface IPostFutureDatedPaymentsRequestInterface extends IGetAccountRequestInterface {
  data: IPostFutureDatedPayments;
}

export interface IPutFutureDatedPayments {
  modifyFDP: AccountFutureDatePaymentsPrimary;
}

export interface IPutFutureDatedPaymentsRequestInterface extends IGetAccountRequestInterface {
  data: IPutFutureDatedPayments;
}
