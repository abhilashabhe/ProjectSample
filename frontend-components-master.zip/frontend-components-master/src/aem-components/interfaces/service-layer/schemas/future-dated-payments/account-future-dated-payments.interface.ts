import { BankInfo } from './bank-info.interface';
import { CardInfo } from './card-info.interface';

export interface AccountFutureDatePaymentsPrimary {
  allowDup?: boolean;
  sourceId: string;
  sourceType: string;
  paymentMethodToken?: string;
  paymentMethodId?: string;
  paymentAmount: number;
  paymentDate: string;
  paymentMethod: string;
  paymentSubMethod?: string;
  bankInfo?: BankInfo;
  cardInfo?: CardInfo;
}

