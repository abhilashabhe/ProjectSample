export interface SecurityInfo {
  pin?: string;
}
