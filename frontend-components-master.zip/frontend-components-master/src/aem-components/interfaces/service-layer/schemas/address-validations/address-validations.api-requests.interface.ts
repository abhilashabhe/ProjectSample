import { IServiceInput } from '../..';

export interface IAddressValidationsRequest extends IServiceInput {
  data: {
    attention?: string;
    address1?: string;
    address2?: string;
    city?: string;
    urbanization?: string;
    state?: string;
    zip?: string;
    zip4Code?: string;
    country?: string;
  };
}
