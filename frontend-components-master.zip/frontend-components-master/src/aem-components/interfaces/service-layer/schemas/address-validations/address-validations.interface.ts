
export interface AddressValidations {
    isValid?: boolean;
}
