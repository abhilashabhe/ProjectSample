export interface Contact {
  email?: string;
  phone?: string;
}
