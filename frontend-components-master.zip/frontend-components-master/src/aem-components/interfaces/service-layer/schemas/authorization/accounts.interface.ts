import { IServiceInput } from '../..';
export interface Accounts extends IServiceInput {
  accountId?: string;
  mdn?: string;
  role?: string;
  subscriptions?: string[];
  permissions?: string[];
}
