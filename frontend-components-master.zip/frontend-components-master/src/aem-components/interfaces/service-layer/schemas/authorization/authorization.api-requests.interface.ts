import { IServiceInput } from '../..';

export interface IGetAuthorizationRequest extends IServiceInput {
  queryParams: {
    EBKey: string;
  };
}
export interface GetAuthorizationForAccountId extends IServiceInput {
  queryParams: {
    accountId: string;
  };
}
