import { IServiceInput } from '../..';
import {Accounts} from './accounts.interface';
export interface Authorization extends IServiceInput {
  userId?: string;
  username?: string;
  accounts?: Accounts[];
  scopes?: string[];
  earlyLifeUser?: Boolean;
}
