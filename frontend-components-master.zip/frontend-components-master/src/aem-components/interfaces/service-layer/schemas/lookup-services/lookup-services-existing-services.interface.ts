import { IServiceType } from './lookup-services-service-type.interface';

export interface ILookUpServicesExistingService {
  serviceSOCSKU: string;
  serviceCategoryID: string;
  serviceType: IServiceType;
  serviceName: string;
  serviceEffectDate?: string;
  serviceExpirationDate?: string;
  requiresWarningOnRemoval?: boolean;
  socPrice: number;
  systemRemoved: boolean;
  userRemovable?: boolean;
  oneTime: boolean;
  dependingSOCs?: string[];
  prohibitiveSOCs?: string[];
  requiredSOCs?: string[];
}
