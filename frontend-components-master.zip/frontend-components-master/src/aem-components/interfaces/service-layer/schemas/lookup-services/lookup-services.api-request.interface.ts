import { IServiceInput } from '../..';
import { INewAccountInfo } from './lookup-services-newaccount-info.interface';
import { ILineDetail, ILineTypeValue } from './lookup-services-line-details.interface';
export type IApplicationID = 'SHOP'|'SPO'|'MYSPRINT'|'SUPPORT';

export interface IPostLookUpServicesRequest extends IServiceInput {
  data: {
    applicationId: IApplicationID;
    ban: string;
    zipCode: string;
    salesChannelCode: string;
    newAccountInfo: INewAccountInfo;
    lineDetail: ILineDetail[];
  };
}

export interface IGetLookUpServicesRequest extends IServiceInput {
  queryParams: {
    applicationId?: IApplicationID;
    salesChannelCode?: string;
    accountType?: string;
    accountSubType?: string;
    corpId?: string;
    creditClass?: string;
    zipCode?: string;
    filter?: string;
    lineDetail?: {
      lineType?: ILineTypeValue,
      itemID?: string;
      contractId?: string;
      newPlanSOC?: string;
    }
  };
}
