import {INewDeviceInfo} from './lookup-services-newdevice-info.interface';
import {IFilter} from './lookup-services-filter.interface';

export type ILineTypeValue = 'GROSS_ADD'|'CHANGE_PLAN'|'CHANGE_SERVICES'|'ESN_SWAP';

export interface ILineDetail  {
    uniqueId: string;
    lineType: ILineTypeValue;
    subscriberID?: string;
    newDeviceInfo: INewDeviceInfo;
    newPlanSOC?: string;
    filter: IFilter[];
}
