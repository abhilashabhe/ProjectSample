import {IAccountInfoDetail} from './lookup-services-accountinfo-details.interface';

export interface INewAccountInfo {
  accountInfo: IAccountInfoDetail;
  creditClass: string;
}
