import { ILookUpServicesServiceCategoryDTO } from './lookup-services-service-category-dto.interface';
import { ILookUpServicesNewService } from './lookup-services-newservices.interface';

export interface ILookUpServicesNewServiceCategory {
  serviceCategoryDTO: ILookUpServicesServiceCategoryDTO;
  newServices: ILookUpServicesNewService[];
}
