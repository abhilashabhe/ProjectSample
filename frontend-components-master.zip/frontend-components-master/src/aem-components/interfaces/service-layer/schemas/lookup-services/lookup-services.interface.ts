import {ILookUpServicesServiceLineDetail} from './lookup-services-service-line-details.interface';

export interface ILookUpService {
  serviceLineDetails: ILookUpServicesServiceLineDetail[];
}
