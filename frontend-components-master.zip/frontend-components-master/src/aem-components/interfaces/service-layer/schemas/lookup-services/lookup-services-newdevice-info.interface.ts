export interface INewDeviceInfo {
    itemID: string;
    contractId?: string;
}
