export interface IAccountInfoDetail {
  accountType: string;
  accountSubType: string;
  corpId: string;
}
