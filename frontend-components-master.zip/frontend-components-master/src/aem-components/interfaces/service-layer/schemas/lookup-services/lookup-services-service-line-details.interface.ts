import {ILookUpServicesNewServiceCategory} from './lookup-services-newservice-categories.interface';
import {ILookUpServicesExistingServiceCategory} from './lookup-services-existing-service-categories.interface';

export interface ILookUpServicesServiceLineDetail {
  uniqueId: string;
  subscriptionCharacteristics: string[];
  newServiceCategories: ILookUpServicesNewServiceCategory[];
  existingServiceCategories: ILookUpServicesExistingServiceCategory[] ;
}
