import { ILookUpServicesServiceCategoryDTO } from './lookup-services-service-category-dto.interface';
import { ILookUpServicesExistingService } from './lookup-services-existing-services.interface';


export interface ILookUpServicesExistingServiceCategory {
  serviceCategoryDTO: ILookUpServicesServiceCategoryDTO;
  existingServices: ILookUpServicesExistingService[];
}
