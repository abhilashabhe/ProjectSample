export type IFilterKeyValue = 'FILTER_DOWNLOADABLE_APP_ID';

export interface IFilter {
    filterKey: IFilterKeyValue;
    filterValue: string;
}
