import { IServiceType } from './lookup-services-service-type.interface';
export type IMessagingAddOnStatus = 'HAS_CORRESPONDING_MESSAGING_ADD_ONS_ON_EXISTING_SUB'|'HAS_NO_CORRESPONDING_MESSAGING_ADD_ONS_ON_EXISTING_SUB'|'HAS_NO_APPLICABLE_CORRESPONDING_MESSAGING_ADD_ONS';

export interface ILookUpServicesNewService {
  serviceSOCSKU: string;
  socBasePrice: number;
  socFinalPrice: number;
  oneTime: boolean;
  requiresTnCOnSelection?: boolean;
  requiresWarningOnRemoval?: boolean;
  requiresWarningOnSelection?: boolean;
  preselect: boolean;
  allowUserToEdit: boolean;
  doNotAllowUserToAdd: boolean;
  devicePromotable: boolean;
  serviceType: IServiceType;
  dependingSOCs?: string[];
  prohibitiveSOCs?: string[];
  requiredSOCs?: string[];
  messagingAddOnStatus: IMessagingAddOnStatus;
}
