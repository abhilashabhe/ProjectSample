export interface ILookUpServicesServiceCategoryDTO {
  serviceCategoryID: string;
  singleSelect: boolean;
  mandatory: boolean;
  topSelling: boolean;
}
