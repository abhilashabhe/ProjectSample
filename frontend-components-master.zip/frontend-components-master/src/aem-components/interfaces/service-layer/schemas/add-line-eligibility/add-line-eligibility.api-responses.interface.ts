import { AddLineEligibilty } from './add-line-eligibility.interface';

export interface IGetAddLineEligibilityResponse {
  addLineEligibility?: AddLineEligibilty;
}
