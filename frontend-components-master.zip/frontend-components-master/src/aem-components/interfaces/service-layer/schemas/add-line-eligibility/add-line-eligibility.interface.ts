export interface AddLineEligibilty {
  isEligible?: boolean;
}
