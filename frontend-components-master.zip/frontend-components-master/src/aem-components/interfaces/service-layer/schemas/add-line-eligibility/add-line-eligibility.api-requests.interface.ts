import { IServiceInput } from '../..';

export interface IAddLineEligibilityInterface extends IServiceInput {
  pathParams: {
    accountId: string;
  };
};
