export interface Period {
  start?: Date;
  end?: Date;
}
