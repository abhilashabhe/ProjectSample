export interface SimSKUPricingInfo {
  finalPrice: string;
  basePrice: number;
}
