import { IServiceInput } from '../..';

export interface IValidateDeviceRequest extends IServiceInput {
  pathParams: {
    serialNo: string;
  };
}

export interface IValidateSimSkuRequest extends  IServiceInput {
  pathParams: {
    serialNo: string;
    simSkuId: string;
  };
}
