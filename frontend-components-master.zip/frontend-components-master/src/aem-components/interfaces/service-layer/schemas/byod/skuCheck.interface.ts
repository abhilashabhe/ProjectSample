export interface SkuCheck {
  isCompatible: boolean;
}
