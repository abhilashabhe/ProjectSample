import { SimKitInfo } from './simKitInfo.interface';

export interface ByodDetails {
  serialNo: string;
  deviceSKU: string;
  netCompatibility?: string;
  simKitInfo: SimKitInfo[];
}
