
import { SimSKUPricingInfo } from './simSKUPricingInfo.interface';

export interface SimKitInfo {
  simSKU: string;
  simPartNumber?: string;
  simPriority?: number;
  simSKUPricingInfo: SimSKUPricingInfo;
}
