export interface MacItem {
  amount?: number;
  duration?: number;
  effectivateDate?: string;
  isAssociatedToDevicePurchaseMethod?: boolean;
  macDescription?: string;
  macId?: string;
  macName?: string;
  macSequenceNumber?: number;
  monthlyDiscountAmount?: number;
}
