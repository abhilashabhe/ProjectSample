import { PortInFieldResponseReseller } from './port-in-field-response-reseller.interface';
export interface ServiceProviderPortFieldMapInfo {
  ospId?: string;
  enableUpdatePortin?: string;
  longMessage?: string;
  portInFieldResponseReseller?: PortInFieldResponseReseller[];
}
