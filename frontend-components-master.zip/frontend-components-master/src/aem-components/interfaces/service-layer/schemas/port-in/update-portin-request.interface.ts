import { UpdatePortInRequestResponse } from './update-port-in-request-response.interface';
export interface UpdatePortinRequest {
  updatePortInRequestResponse: UpdatePortInRequestResponse;
}
