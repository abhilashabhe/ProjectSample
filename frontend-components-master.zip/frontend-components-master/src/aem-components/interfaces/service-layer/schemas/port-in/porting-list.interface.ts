export interface PortingList {
  phoneNumber?: string;
  highLevelStatusDesc?: string;
  statusCode?: string;
  messageText?: string;
  lastActivityDate?: string;
  firstName?: string;
  businessName?: string;
  lastName?: string;
  deviceSerialNumber?: string;
  actionAllowedCode?: string;
  requestDate?: string;
  orderElement?: string;
  errorElementList?: string;
  bannerColorFlag?: string;
}
