export interface PortInFieldResponseReseller {
  portRequestFieldName?: string;
  portRequestFieldKey?: string;
  optionalInd?: string;
  guidanceMessage?: string;
}
