export interface UpdatePortInRequestResponse {
  message: string;
}
