import {IServiceInput} from '../../';
export interface IGetPortListRequest extends IServiceInput {
  pathParams: {
    accountId: string;
  };
  queryParams: {
    blockNumber: number;
    blockSize: number;
  };
}
export interface IGetServiceProviderPortFieldMapInfoRequest extends IServiceInput {
  pathParams: {
    portInMdn: string;
  };
}
export interface IUpdatePortinRequest extends IServiceInput {
  pathParams: {
    portInMdn: string;
  };
  data: {
    accountId?: string;
    password?: string;
    ssnTaxId?: string;
    addressLine1?: string;
    city?: string;
    state?: string;
    zipCode?: string;
  };
}
