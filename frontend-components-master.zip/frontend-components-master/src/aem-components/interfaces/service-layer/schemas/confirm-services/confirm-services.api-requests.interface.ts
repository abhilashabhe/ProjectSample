import { IServiceInput } from '../..';

export interface IConfirmServicesRequest extends IServiceInput {
  pathParams: {
    accountid: string;
    subscriptionid: string;
  };
  data: {
    subscriberID: string;
    userRemovedServices: string[];
    newlySelectedServices: string[];
    ioBlackbox?: string;
  };
}
