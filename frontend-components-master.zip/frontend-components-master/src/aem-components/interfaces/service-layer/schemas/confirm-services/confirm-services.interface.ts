export interface IConfirmService {
  data: {
    orderKey: string;
    statusCode: string;
  };
}
