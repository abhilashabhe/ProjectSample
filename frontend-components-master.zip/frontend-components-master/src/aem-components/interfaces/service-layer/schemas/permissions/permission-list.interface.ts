export type IPermissionType = 'THIRDPARTY'| 'MARKETING'| 'ADVERTISING'| 'ACCOUNTACCESS'| 'WIFICALLING';
export type IPermission = 'Allow' | 'Deny';

export interface IPermissionList {
  permissionType: IPermissionType;
  permission: IPermission;
  isCapable?: string;
}
