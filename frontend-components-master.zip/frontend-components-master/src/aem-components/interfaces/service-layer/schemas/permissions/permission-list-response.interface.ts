export type IPermissionType = 'THIRDPARTY'| 'MARKETING'| 'ADVERTISING'| 'ACCOUNTACCESS'| 'WIFICALLING';

export interface IPermissionResponse {
  permissionType: IPermissionType;
  responseMessage: string;
  isCapable?: string;
  socConflicts?: Array<string>;
}
