import { IPermissionList } from './permission-list.interface';

export interface IGetPermissions {
  permissionList: Array<IPermissionList>;
}
