import { IPermissionResponse } from './permission-list-response.interface';

export interface IPostPermissions {
  permissionList: Array<IPermissionResponse>;
}
