import { IGetAccountSubscriptionRequestInterface } from '../accounts/account.api-requests.interface';
export type IPermissionType = 'THIRDPARTY'| 'MARKETING'| 'ADVERTISING'| 'ACCOUNTACCESS'| 'WIFICALLING';
export type IPermission = 'Allow' | 'Deny';

export interface IPermissionsRequestDataInterface {
  permissionType: IPermissionType;
  permission: IPermission;
  socConflicts?: Array<string>;
}

export interface IPermissionsRequestInterface extends IGetAccountSubscriptionRequestInterface {
  data: IPermissionsRequestDataInterface;
}
