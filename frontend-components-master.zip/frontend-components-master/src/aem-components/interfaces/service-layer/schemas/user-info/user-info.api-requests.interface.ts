import { IServiceInput } from '../..';

export interface IPostUserInfo extends IServiceInput {
  data: {
    accountType: string;
    accountSubType: string;
    corpID?: string | null;
    source?: string;
    submissionDate?: string;
    verificationStatus?: string;
    referralPath?: string;
  };
}
