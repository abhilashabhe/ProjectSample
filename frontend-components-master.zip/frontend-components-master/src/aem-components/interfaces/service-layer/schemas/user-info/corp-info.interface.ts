export interface CorpInfo {
  corpID: string | null;
  accountType: string;
  accountSubType: string;
  corpName: string;
}
