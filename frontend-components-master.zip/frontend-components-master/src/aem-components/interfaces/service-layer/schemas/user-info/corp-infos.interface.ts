import { CorpInfo } from './corp-info.interface';

export interface CorpInfos {
  corpInfos: CorpInfo[];
}
