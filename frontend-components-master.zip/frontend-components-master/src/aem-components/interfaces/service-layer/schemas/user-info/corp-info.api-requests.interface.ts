import { IServiceInput } from '../..';

export interface IGetCorpInfoRequest extends IServiceInput {
  queryParams: {
    emailDomain: string;
  };
}
