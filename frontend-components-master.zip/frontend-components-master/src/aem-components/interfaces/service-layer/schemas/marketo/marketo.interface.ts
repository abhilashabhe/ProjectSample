export interface MarketoResponse {
  formId: string;
  followUpUrl: string;
  aliId: number;
}
