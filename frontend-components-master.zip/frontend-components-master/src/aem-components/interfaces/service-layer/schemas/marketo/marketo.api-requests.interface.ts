export interface PostMarketo {
  data: {
    _mktoReferrer?: string;
    aARTaccountSubtype?: string;
    aARTaccountType?: string;
    aARTcorporationName?: string;
    aARTemailDomain?: string;
    bizILCorpID?: string;
    bizILOfferedCorpID?: string;
    bizILVertical?: string;
    company?: string;
    country?: string;
    cr?: string;
    emailAddress?: string;
    firstName?: string;
    followupLpId: number;
    formid: number;
    formVid?: number;
    iTSourceCode?: number;
    kw?: string;
    lastName?: string;
    leadSource?: string;
    lpId: number;
    lpurl?: string;
    munchkinId?: string;
    phone?: string;
    q?: string;
    Unsubscribe?: boolean;
    urlparameter?: string;
    solutionInterestBizIL?: boolean;
    subId: number;
  };
}



