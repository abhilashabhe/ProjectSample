export interface Accessory {
  id?: string;
  name?: string;
  price?: number;
  finalPrice?: number;
  inventoryStatus?: string;
  manufacturer?: string;
  sellDate?: string;
}
