import { IServiceInput } from '../..';

export interface IGetAccessoriesRequest extends IServiceInput {
  queryParams: {
    deviceId: string;
    accountType?: string;
    accountSubType?: string;
  };
}
export interface IGetAccessoryRequest extends IServiceInput {
  pathParams: {
    accessoryId: string;
    accountType?: string;
    accountSubType?: string;
  };
}
