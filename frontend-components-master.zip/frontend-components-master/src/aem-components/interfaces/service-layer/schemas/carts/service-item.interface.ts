import { Discount } from './discount.interface';
export interface ServiceItem {
  catalogReferenceID: string;
  chargeType: string;
  isMandatory: boolean;
  isShowInCart: boolean;
  mandatoryFromGroup: boolean;
  name: string;
  postPurchaseDiscounts: Array<Discount>;
  price: number;
  serviceCommerceItemID: string;
  serviceSOCSKU: string;
  serviceStatus: string;
}
