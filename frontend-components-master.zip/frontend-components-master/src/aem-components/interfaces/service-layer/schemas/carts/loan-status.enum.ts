export class LoanStatusEnum {
  static get INSTALLMENT_BILLING(): string {
    return 'INSTALLMENT_BILLING';
  };

  static get LEASE(): string {
    return 'LEASE';
  };
}
