import { IServiceInput } from '../..';
import { PackageTypeEnum } from './package-type.enum';
import { PackageSourceEnum } from './package-source.enum';
import { SubscriptionLineInfo } from './subscription-line-info.interface';
import { CartsTradeInInfo } from './carts-trade-in-info.interface';

export interface IBaseCartRequest extends IServiceInput {
  pathParams: {
    cartId: string;
  };
}

export interface IBaseCartPackageRequest extends IServiceInput {
  pathParams: {
    cartId: string;
    packageId: string;
  };
}

export interface IBaseCartCouponRequest extends IServiceInput {
  pathParams: {
    cartId: string;
    couponId: string;
  };
}

export interface IBaseCartSubpackageRequest extends IServiceInput {
  pathParams: {
    cartId: string;
    packageId: string;
    subpackageId: string;
  };
}

export interface IBaseCartDeviceRequest extends IServiceInput {
  pathParams: {
    cartId: string;
    packageId: string;
    subpackageId: string;
    deviceId: string;
  };
}

export interface IBaseCartServiceRequest extends IServiceInput {
  pathParams: {
    cartId: string;
    packageId: string;
    subpackageId: string;
    serviceId: string;
  };
}

export interface IBaseCartAccessoryRequest extends IServiceInput {
  pathParams: {
    cartId: string;
    packageId: string;
    subpackageId: string;
    accessoryId?: string;
  };
}

export interface IPutCartRequest extends IBaseCartRequest {
  data: BaseRequestCart;
}

export interface IPostCartPackagesRequest extends IBaseCartPackageRequest {
  data: BaseRequestPackage;
}

export interface IPutCartPackageRequest extends IBaseCartPackageRequest {
  data: BaseRequestPackage;
}

export interface IPostCartSubpackageRequest extends IBaseCartSubpackageRequest {
  data: {
    subpackages: BaseRequestSubpackage[];
  };
}

export interface IPutCartSubpackageRequest extends IBaseCartSubpackageRequest {
  data: BaseRequestSubpackage;
}

export interface IPutCartDeviceRequest extends IBaseCartDeviceRequest {
  data: {
    device: BaseRequestDevice;
  };
}

export interface IPostCartServicesRequest extends IBaseCartServiceRequest {
  data: {
    services: BaseRequestService[];
  };
}

export interface IPostCartAccessoriesRequest extends IBaseCartAccessoryRequest {
  data: {
    accessories: BaseRequestAccessory[];
  };
}

export interface IPutCartAccessoryRequest extends IBaseCartAccessoryRequest {
  data: {
    quantity: number;
  };
}

export interface IPostCouponRequest extends IBaseCartRequest {
  data: IdPackage;
}

export interface IPostCartSaveRequest extends IBaseCartRequest {
  data: IdPackage;
}

export interface ILoadCartRequest extends IServiceInput {
  data: IdPackage;
}

export interface IGetCartSaveRequest extends IServiceInput {
  pathParams: {
    cartIdentifier: string
  };
}

// PRIVATE INTERFACES //

export interface BaseRequestAccessory {
  itemID?: string;
  quantity?: number;
}

export interface IdPackage {
  id: string;
}

export interface BaseRequestService {
  serviceSOCSKU?: string;
  serviceStatus?: string;
}

export interface BaseRequestPlan {
  planSOCSKU?: string;
}

export interface BaseRequestPlanForAddToCart extends BaseRequestPlan {
  isShared?: boolean;
}

export interface BaseRequestDevice {
  itemID?: string;
  contractInfo?: {
    contractId?: string;
  };
  offerGroupInfo?: {
    offerGroupCode: string;
    promoCode?: string;
  };
  tradeInInfo?: CartsTradeInInfo;
}

export interface BaseRequestByodDevice {
  serialNo?: string;
  brandCode?: string;
  existingSIMInfo?: {
    iccId: string;
  };
}

export interface BaseRequestSubpackage {
  device?: BaseRequestDevice;
  byodDevice?: BaseRequestByodDevice;
  plan?: BaseRequestPlan;
  services?: BaseRequestService[];
  accessories?: BaseRequestAccessory[];
  currentSubscriberInfo?: SubscriptionLineInfo;
  subPackageId?: string;
}

export interface BaseRequestPackage {
  packageId?: string;
  packageSourceUrl?: string;
  packageType?: PackageTypeEnum;
  packageSource?: PackageSourceEnum;
  quantity?: number;
  subpackages?: BaseRequestSubpackage[];
}

export interface BaseRequestCartOverride {
  shoppingZipCode?: string;
  accountType?: string;
  accountSubType?: string;
  creditRange?: string;
  corpId?: string;
  packages?: BaseRequestPackage[];
  [key: string]: any;
}

export interface BaseRequestCart {
  shoppingZipCode?: string;
  accountType?: string;
  accountSubType?: string;
  creditRange?: string;
  corpId?: string;
  packages: BaseRequestPackage[];
  [key: string]: any;
}

export interface IUpdateCurrentCartRequest {
  data: {
    packages: BaseRequestPackage[];
  }
}
