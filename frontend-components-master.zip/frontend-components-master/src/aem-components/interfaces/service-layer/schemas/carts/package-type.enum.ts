
export type PackageType
  = 'GROSS_ADD'
  | 'CP'
  | 'UPG'
  | 'MOT'
  | 'AO'
  | 'NONE'
  | 'AAP_CP'
  | 'BYOD';

export class PackageTypeEnum {
  static get GROSS_ADD(): string {
    return 'GROSS_ADD';
  };

  static get NONE(): string {
    return 'NONE';
  };

  static get CP(): string {
    return 'CP';
  };

  static get UPG(): string {
    return 'UPG';
  };

  static get MOT(): string {
    return 'MOT';
  }

  static get AO(): string {
    return 'AO';
  };

  static get AAP_CP(): string {
    return 'AAP_CP';
  }

  static get BYOD(): string {
    return 'BYOD';
  }
}
