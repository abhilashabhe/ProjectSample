import { Contract } from './contract.interface';
import { DevicePrice } from './device-price.interface';
import { OfferGroupInfo } from './offer-group-info.interface';
import { ExistingSIMInfo } from './existing-sim-info.interface';
export interface BYODDeviceItem {
  brandCode?: string;
  catalogReferenceID?: string;
  contractInfo?: Contract;
  deviceCommerceItemID?: string;
  deviceNickName?: string;
  devicePrice?: DevicePrice;
  earlyUpgrade?: boolean;
  existingSIMINfo?: ExistingSIMInfo;
  imageURL?: string;
  itemId?: string;
  name?: string;
  offerGroupInfo?: OfferGroupInfo;
  preOrder?: boolean;
  serialNo?: string;
  tradeInInfo?: string;
  tradeInRequired?: boolean;
}
