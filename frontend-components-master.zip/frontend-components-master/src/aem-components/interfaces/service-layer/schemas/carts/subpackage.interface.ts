import { SubpackageTypeEnum } from './subpackage-type.enum';
import { BYODDeviceItem } from './byod-device-item.interface';
import { DeviceItem } from './device-item.interface';
import { CartPlanItem } from './plan-item.interface';
import { ServiceItem } from './service-item.interface';
import { AccessoryItem } from './accessory-item.interface';
import { SubscriptionLineInfo } from './subscription-line-info.interface';

export interface Subpackage {
  subPackageId?: string;
  subPackageType?: SubpackageTypeEnum;
  isPortInNeeded?: boolean;
  device?: DeviceItem;
  byodDevice?: BYODDeviceItem;
  plan?: CartPlanItem;
  services?: Array<ServiceItem>;
  accessories?: Array<AccessoryItem>;
  currentSubscriberInfo?: SubscriptionLineInfo;
}
