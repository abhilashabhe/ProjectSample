import { Discount } from './discount.interface';

export interface AccessoryPrice {
  discountedPrice?: number;
  originalPrice?: number;
  prePurchaseDiscounts?: Array<Discount>;
  postPurchaseDiscounts?: Array<Discount>;
}
