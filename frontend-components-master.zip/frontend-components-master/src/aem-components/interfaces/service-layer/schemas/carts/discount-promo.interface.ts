import { Discount } from './discount.interface';

export interface DiscountWithPromo extends Discount {
  promoTitle?: string;
  promoLongDescription?: string;
}
