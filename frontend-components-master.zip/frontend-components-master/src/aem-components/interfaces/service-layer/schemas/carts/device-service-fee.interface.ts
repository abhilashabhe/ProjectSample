import { DeviceServiceFeeTypeEnum } from './device-service-fee-type.enum';

export interface DeviceServiceFee {
  serviceFeeType?: DeviceServiceFeeTypeEnum;
  serviceFeeBasePrice?: number;
  serviceFeeDiscount?: number;
}
