export class SubpackageTypeEnum {
  static get GROSS_ADD(): string {
    return 'GROSS_ADD';
  }

  static get CP(): string {
    return 'CP';
  }

  static get UPG(): string {
    return 'UPG';
  }

  static get AO(): string {
    return 'AO';
  }
}
