import { PackageSourceEnum } from './package-source.enum';

describe('Package Source Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof PackageSourceEnum.EXPRESS_GROSS_ADD).toBe('string');
    expect(typeof PackageSourceEnum.EXPRESS_UPG).toBe('string');
    expect(typeof PackageSourceEnum.FRONT_END_2_0).toBe('string');
    expect(typeof PackageSourceEnum.FRONT_END_3_0).toBe('string');
    expect(typeof PackageSourceEnum.SPO).toBe('string');
  });

});
