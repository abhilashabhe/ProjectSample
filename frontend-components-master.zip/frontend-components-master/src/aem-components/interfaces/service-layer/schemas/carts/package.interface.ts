import { PackageTypeEnum } from './package-type.enum';
import { PackageSourceEnum } from './package-source.enum';
import { OldCarrierInfo } from './old-carrier-info.interface';
import { Subpackage } from './subpackage.interface';

export interface Package {
  packageId?: string;
  packageType?: PackageTypeEnum;
  packageSource?: PackageSourceEnum;
  packageSourceURL?: string;
  oldCarrierInfo?: OldCarrierInfo;
  subpackages?: Array<Subpackage>;
  byod?: boolean;
}
