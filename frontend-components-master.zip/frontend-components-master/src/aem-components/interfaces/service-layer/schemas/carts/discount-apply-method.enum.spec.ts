import { DiscountApplyMethodEnum } from './discount-apply-method.enum';

describe('Discount Apply Method Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof DiscountApplyMethodEnum.INSTANT).toBe('string');
    expect(typeof DiscountApplyMethodEnum.INVOICE_CREDIT).toBe('string');
    expect(typeof DiscountApplyMethodEnum.MAIL_IN_REBATE).toBe('string');
  });

});
