export interface Coupon {
  id?: string;
  applied?: boolean;
  promotionId?: string;
  promotionDescription?: string;
}
