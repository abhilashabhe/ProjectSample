export interface CartsTradeInInfo {
  deviceCarrier?: string;
  deviceEsn: string;
  deviceManufacturer?: string;
  productId?: string;
  subscriberDevice?: boolean;
};
