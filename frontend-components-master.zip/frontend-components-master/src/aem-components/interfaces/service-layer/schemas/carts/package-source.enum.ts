export class PackageSourceEnum {
  static get FRONT_END_2_0(): string {
    return 'FRONT_END_2_0';
  };

  static get FRONT_END_3_0(): string {
    return 'FRONT_END_3_0';
  };

  static get SPO(): string {
    return 'SPO';
  };

  static get EXPRESS_UPG(): string {
    return 'EXPRESS_UPG';
  };

  static get EXPRESS_GROSS_ADD(): string {
    return 'EXPRESS_GROSS_ADD';
  };

  static get VML(): string { 
    return 'VML'; 
  };
}
