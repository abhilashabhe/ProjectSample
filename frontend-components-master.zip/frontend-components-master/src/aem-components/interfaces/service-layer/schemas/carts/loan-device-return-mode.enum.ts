export class LoanDeviceReturnModeEnum {
  static get GIVE_BACK_FOR_INSTALLMENT_BILLING(): string {
    return 'GIVE_BACK_FOR_INSTALLMENT_BILLING';
  };

  static get BUY_FOR_LEASE(): string {
    return 'BUY_FOR_LEASE';
  };

  static get TURN_IN_FOR_LEASE(): string {
    return 'TURN_IN_FOR_LEASE';
  };
}
