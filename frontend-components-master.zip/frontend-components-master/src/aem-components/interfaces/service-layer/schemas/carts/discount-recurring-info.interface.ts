export interface DiscountRecurringInfo {
  recurringTerm?: string;
  recurringTermDesc?: string;
}
