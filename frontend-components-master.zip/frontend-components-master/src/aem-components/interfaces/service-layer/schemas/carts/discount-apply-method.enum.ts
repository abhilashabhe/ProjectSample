export class DiscountApplyMethodEnum {
  static get INSTANT(): string {
    return 'INSTANT';
  }

  static get MAIL_IN_REBATE(): string {
    return 'MAIL_IN_REBATE';
  }

  static get INVOICE_CREDIT(): string {
    return 'INVOICE_CREDIT';
  }
}
