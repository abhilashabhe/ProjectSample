import { DeviceServiceFeeTypeEnum } from './device-service-fee-type.enum';

describe('Device Service Fee Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof DeviceServiceFeeTypeEnum.ACTIVATION_SERVICE_FEE).toBe('string');
    expect(typeof DeviceServiceFeeTypeEnum.UPGRADE_SERVICE_FEE).toBe('string');
  });

});
