import { LoanStatusEnum } from './loan-status.enum';
import { LoanDeviceReturnModeEnum } from './loan-device-return-mode.enum';

export interface LoanDetails {
  loanStatus?: LoanStatusEnum;
  deviceReturnMode?: LoanDeviceReturnModeEnum;
  deviceRemainingAmount?: number;
  currentDeviceItemId?: string;
  currentDeviceESN?: string;
  appleLock?: boolean;
  payOffAmount?: number;
}
