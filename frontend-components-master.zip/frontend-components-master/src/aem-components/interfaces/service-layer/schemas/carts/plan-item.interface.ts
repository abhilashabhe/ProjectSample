import { DiscountWithPromo } from './discount-promo.interface';
import { MacItem } from '../mac-item.interface';
import { RequiredAddon } from '../plans/required-addon.interface';
export interface CartPlanItem {
  catalogReferenceID?: string;
  name?: string;
  planCommerceItemID?: string;
  planRequiredSocs?: Array<RequiredAddon>;
  planSOCSKU?: string;
  postPurchaseDiscounts?: Array<DiscountWithPromo>;
  price?: number;
  pricePlanMACList?: Array<MacItem>;
  isShared?: boolean;
}
