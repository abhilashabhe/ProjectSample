export class CreditRangeEnum {
  static get GOOD_CREDIT(): string {
    return 'GOOD_CREDIT';
  }

  static get BUILDING_CREDIT(): string {
    return 'BUILDING_CREDIT';
  }

  static get NO_CREDIT_CHECK(): string {
    return 'NO_CREDIT_CHECK';
  }
}
