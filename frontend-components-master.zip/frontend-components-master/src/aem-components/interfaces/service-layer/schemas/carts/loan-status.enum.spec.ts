import { LoanStatusEnum } from './loan-status.enum';

describe('Loan Status Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof LoanStatusEnum.INSTALLMENT_BILLING).toBe('string');
    expect(typeof LoanStatusEnum.LEASE).toBe('string');
  });

});
