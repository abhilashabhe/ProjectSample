import { LoanDeviceReturnModeEnum } from './loan-device-return-mode.enum';

describe('Loan Device Return Mode Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof LoanDeviceReturnModeEnum.BUY_FOR_LEASE).toBe('string');
    expect(typeof LoanDeviceReturnModeEnum.GIVE_BACK_FOR_INSTALLMENT_BILLING).toBe('string');
    expect(typeof LoanDeviceReturnModeEnum.TURN_IN_FOR_LEASE).toBe('string');
  });

});
