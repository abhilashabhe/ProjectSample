import { LoanDetails } from './loan-details.interface';

export interface SubscriptionLineInfo {
  subscriptionID?: string;
  subscriberID?: string;
  ptn?: string;
  loanDetails?: LoanDetails;
}
