import { Contract } from './contract.interface';
import { DevicePrice } from './device-price.interface';
import { OfferGroupInfo } from './offer-group-info.interface';
export interface DeviceItem {
  catalogReferenceID?: string;
  contractInfo?: Contract;
  deviceCommerceItemID?: string;
  deviceNickName?: string;
  devicePrice?: DevicePrice;
  earlyUpgrade?: boolean;
  imageURL?: string;
  itemID?: string;
  name?: string;
  offerGroupInfo?: OfferGroupInfo;
  preOrder?: boolean;
  tradeInInfo?: string;
  tradeInRequired?: boolean;
}
