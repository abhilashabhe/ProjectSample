import { AccessoryPrice } from './accessory-price.interface';

export interface AccessoryItem {
  name?: string;
  imageURL?: string;
  accessoryCommerceItemID?: string;
  itemID?: string;
  catalogReferenceID?: string;
  quantity?: number;
  isUpsellAccessory?: boolean;
  accessoryPrice?: AccessoryPrice;
}
