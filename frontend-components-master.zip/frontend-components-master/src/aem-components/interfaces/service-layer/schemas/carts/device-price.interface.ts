import { Discount } from './discount.interface';
import { DiscountWithPromo } from './discount-promo.interface';
import { MacItem } from '../mac-item.interface';
import { DeviceServiceFee } from './device-service-fee.interface';

export interface DevicePrice {
  depositAmount?: number;
  deviceMACList?: Array<MacItem>;
  deviceServiceFee?: DeviceServiceFee;
  discountedPrice?: number;
  discountedPriceWithServices?: number;
  firstMonthInstallmentPrice?: number;
  firstMonthInstallmentPriceWithServices?: number;
  lastMonthInstallmentPrice?: number;
  originalPrice?: number;
  prePurchaseDiscounts?: Array<Discount>;
  postPurchaseDiscounts?: Array<DiscountWithPromo>;
}
