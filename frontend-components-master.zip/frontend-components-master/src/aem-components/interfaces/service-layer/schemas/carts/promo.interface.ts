import { UserAttributes } from '../user/user-attributes.interface';
/*
  Run this in the console over an Array of Promos to reproduce the below list:
  [...new Set(promos.reduce((keys, p) => [...keys, ...Object.keys(p)], []))].sort()

  All unique object keys found on all promo objects:
  atstskulist
  cartdescription
  cartdetails
  clickorcall
  corpidskulist
  contractskulist
  ctatext
  description
  deviceskulist
  discount
  discounttype
  displaypriority
  header
  includeondevicewall
  orderconfirmation
  partoffunnel
  pathlist
  planskulist
  promoid
  promotype
  siebelblacklist
  siebelsublist
  userstatelist
*/


export type PartOfFunnel = 'both' | 'upper' | 'cart';
export type PromoType = 'instant' | 'oneTime' | 'recurring' | 'Strikethrough Monthly Amount';
export type DiscountType = 'AMT' | 'PER';

export type PromoPredicate = (p: NormalizedPromo) => boolean;
export type PromoFilter = (ps: NormalizedPromo[]) => NormalizedPromo[];

export interface AtStSkuListItem      { at: string; st: string; }
export interface ContractSkuListItem  { contractType: string; }
export interface CorpIdSkuListItem    { corpid: string; }
export interface DeviceSkuListItem    { deviceSku: string; }
export interface PathListItem         { pathType: string; }
export interface PlanSkuListItem      { planSku: string; }
export interface SiebelIdListItem     { siebelId: string; }
export interface SiebelSubListItem    { siebelSub: string; }
export interface NbaIdListItem        { nbaofferid: string; }
export interface UserStateListItem    { userState: string; }

export interface ExtendedUserAttributes extends UserAttributes {
  siebelIds: number[];
  siebelSubIds: number[];
  nbaIds: string[];
}

export interface Promo {
  atstskulist?: AtStSkuListItem[];
  contractskulist?: ContractSkuListItem[];
  corpidskulist?: CorpIdSkuListItem[];
  deviceskulist?: DeviceSkuListItem[];
  pathlist?: PathListItem[];
  planskulist?: PlanSkuListItem[];
  siebelidlist?: SiebelIdListItem[];
  nbaofferidlist?: NbaIdListItem[];
  siebelsublist?: SiebelSubListItem[];
  userstatelist?: UserStateListItem[];
  /* TODO: Figure out what type this is supposed to be */
  siebelblacklist?: any[];

  cartdescription?: string;
  cartdetails?: string;
  clickorcall?: boolean;
  ctatext?: string;
  description?: string;
  discount?: string;
  discounttype?: DiscountType;
  displaypriority?: string;
  header?: string;
  imagealt?: string;
  imageurl?: string;
  includeondevicewall?: boolean;
  legal?: string;
  orderconfirmation?: string;
  partoffunnel?: PartOfFunnel;
  promoid?: string;
  promotype?: PromoType;
}

export interface PromoQualifierLists {
  atstSkus?: string[];
  contractSkus?: string[];
  corpIdSkus?: string[];
  deviceSkus?: string[];
  paths?: string[];
  planSkus?: string[];
  siebelIds?: number[];
  siebelSubIds?: number[];
  nbaIds?: string[];
  userStates?: string[];
}

export interface NormalizedPromo extends Promo {
  index: number;
  domTargetId: string;
  qualifierLists: PromoQualifierLists;
}

export interface AemPromoAsDatatype {
  datatype: 'PromosExplorerDataUse';
  values: Promo;
}

export interface GetAEMDevicePromosResponse {
  data: AemPromoAsDatatype[][];
}
