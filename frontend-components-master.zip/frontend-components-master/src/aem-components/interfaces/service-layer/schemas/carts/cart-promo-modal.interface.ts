export interface CartModalPromo {
  isClickOrCall?: boolean ;
  modalId?: string;
  title?: string;
  imageUrl?: string;
  imageAlt?: string;
  description?: string;
  type?: string;
}
