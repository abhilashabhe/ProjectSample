export interface OfferGroupInfo {
  offerGroupCode?: string;
  offerGroupCodeDescription?: string;
  promoCode?: string;
  tradeInChargeBackAmount?: number;
}
