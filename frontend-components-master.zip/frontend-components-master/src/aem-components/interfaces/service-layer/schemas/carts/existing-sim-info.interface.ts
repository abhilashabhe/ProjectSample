export interface ExistingSIMInfo {
  iccId?: string;
}
