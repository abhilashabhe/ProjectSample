export class DiscountClassificationEnum {
  static get DISCOUNT(): string {
    return 'DISCOUNT';
  }

  static get SURCHARGE(): string {
    return 'SURCHARGE';
  }

  static get PROMOTION(): string {
    return 'PROMOTION';
  }
}
