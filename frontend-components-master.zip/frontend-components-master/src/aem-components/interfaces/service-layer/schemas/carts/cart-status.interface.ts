// TODO: Need raml spec to better define this interface
export interface CartStatus {
  errors: any[];
  information: any[];
}
