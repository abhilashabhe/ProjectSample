import { SubpackageTypeEnum } from './subpackage-type.enum';

describe('Subpackage Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof SubpackageTypeEnum.AO).toBe('string');
    expect(typeof SubpackageTypeEnum.CP).toBe('string');
    expect(typeof SubpackageTypeEnum.GROSS_ADD).toBe('string');
    expect(typeof SubpackageTypeEnum.UPG).toBe('string');
  });

});
