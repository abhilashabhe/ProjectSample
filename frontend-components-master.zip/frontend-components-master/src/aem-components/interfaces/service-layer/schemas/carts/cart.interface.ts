import { CartPrice } from './cart-price.interface';
import { Package } from './package.interface';
import { PackageType } from './package-type.enum';

export interface Cart {
  accountType?: string;
  accountSubType?: string;
  byod?: boolean;
  cartId: string;
  cartType?: PackageType;
  corpId?: string;
  creditRange?: string;
  shoppingZipCode?: string;
  previewDate?: Date;
  cartPrice?: CartPrice;
  packages?: Array<Package>;
  remainingLineLimit: number;
  status?: any; // TODO: Define this
}

export interface CartItemCount {
  newlineCount?: number;
  changePlanLineCount?: number;
  upgradeLineCount?: number;
  accessoryCount?: number;
}

export interface CartSummary {
  id?: string;
  version?: string;
  profileId?: string;
  ban?: string;
  accountType?: string;
  accountSubType?: string;
  corpId?: string;
  shoppingZipCode?: string;
  subscribersInCart?: string[];
  itemsCount?: CartItemCount;
  status?: string;
  creditClass?: string;
  authorizedLineLimit?: number;
  remainingLineLimit?: number;
  aslLimit?: number;
  aslRequired?: boolean;
  creditCheckApplicationNumber?: number;
  creditRange?: string;
  creditSource?: string;
}
