export interface Contract {
  contractId?: string;
  creditCheckNeeded?: boolean;
  offerGroupCode?: string;
  paymentDuration?: number;
  purchaseMethod?: string;
}
