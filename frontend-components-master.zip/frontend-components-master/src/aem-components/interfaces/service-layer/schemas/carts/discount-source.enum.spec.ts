import { DiscountSourceEnum } from './discount-source.enum';

describe('Discount Source Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof DiscountSourceEnum.BOGO).toBe('string');
    expect(typeof DiscountSourceEnum.LOAN).toBe('string');
    expect(typeof DiscountSourceEnum.SIEBEL).toBe('string');
    expect(typeof DiscountSourceEnum.UPG_ARM).toBe('string');
    expect(typeof DiscountSourceEnum.UPG_NOW).toBe('string');
    expect(typeof DiscountSourceEnum.UPG_UFP).toBe('string');
    expect(typeof DiscountSourceEnum.WEB).toBe('string');
  });

});
