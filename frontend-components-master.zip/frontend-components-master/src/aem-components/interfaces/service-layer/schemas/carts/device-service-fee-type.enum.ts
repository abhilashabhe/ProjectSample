export class DeviceServiceFeeTypeEnum {
  static get ACTIVATION_SERVICE_FEE(): string {
    return 'ACTIVATION_SERVICE_FEE';
  }

  static get UPGRADE_SERVICE_FEE(): string {
    return 'UPGRADE_SERVICE_FEE';
  }
}
