export interface CartPrice {
  totalTaxesAndFees?: number;
  totalTax?: number;
  aslFee?: number;
  aslFeeApplied?: boolean;
  todaysTotalCharge?: number;
  firstMonthInvoiceTotalCharge?: number;
  subsequentMonthsInvoiceTotalCharge?: number;
  totalMonthlyPriceBeforeDiscount?: number;
  shippingCharge?: number;
  oneTimeInvoiceCreditTotal?: number;
  recurringInvoiceCreditTotal?: number;
  estimatedTax?: boolean;
}
