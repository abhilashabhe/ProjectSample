import { PackageTypeEnum } from './package-type.enum';

describe('Package Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof PackageTypeEnum.AAP_CP).toBe('string');
    expect(typeof PackageTypeEnum.AO).toBe('string');
    expect(typeof PackageTypeEnum.CP).toBe('string');
    expect(typeof PackageTypeEnum.GROSS_ADD).toBe('string');
    expect(typeof PackageTypeEnum.UPG).toBe('string');
  });

});
