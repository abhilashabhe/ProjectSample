export interface OldCarrierInfo {
  gbLevel?: string;
  oldCarrier?: string;
  oldCarrierPrice?: string;
}
