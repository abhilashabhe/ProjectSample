import { DiscountClassificationEnum } from './discount-classification.enum';

describe('Discount Classification Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof DiscountClassificationEnum.DISCOUNT).toBe('string');
    expect(typeof DiscountClassificationEnum.PROMOTION).toBe('string');
    expect(typeof DiscountClassificationEnum.SURCHARGE).toBe('string');
  });

});
