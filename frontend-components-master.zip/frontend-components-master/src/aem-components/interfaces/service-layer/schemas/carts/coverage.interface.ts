export interface Coverage {
  presentSale?: boolean;
  warnUser?: boolean;
}
