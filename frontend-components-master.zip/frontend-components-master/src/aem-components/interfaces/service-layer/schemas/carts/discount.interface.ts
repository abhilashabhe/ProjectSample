import { DiscountClassificationEnum } from './discount-classification.enum';
import { DiscountApplyMethodEnum } from './discount-apply-method.enum';
import { DiscountSourceEnum } from './discount-source.enum';
import { DiscountRecurringInfo } from './discount-recurring-info.interface';

export interface Discount {
  amount?: number;
  applyMethod?: DiscountApplyMethodEnum;
  classification?: DiscountClassificationEnum;
  couponCode?: string;
  label?: string;
  promotionId: string;
  recurringInfo?: DiscountRecurringInfo;
  source?: DiscountSourceEnum;
  webExclusive?: boolean;
}
