export class DiscountSourceEnum {
  static get UPG_ARM(): string {
    return 'UPG_ARM';
  }

  static get UPG_UFP(): string {
    return 'UPG_UFP';
  }

  static get UPG_NOW(): string {
    return 'UPG_NOW';
  }

  static get SIEBEL(): string {
    return 'SIEBEL';
  }

  static get BOGO(): string {
    return 'BOGO';
  }

  static get LOAN(): string {
    return 'LOAN';
  }

  static get WEB(): string {
    return 'WEB';
  }
}
