export interface AccountPlanInfo {
  pricePlanChangeType: string;
  pricePlanChangeDate: string;
  pricePlanCode: string;
  pricePlanName: string;
  planType: string;
  sharedUsageExclusionInd: string;
  isSingleSubOnSharedPlan: string;
}
