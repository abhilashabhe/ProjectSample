export interface Ebill {
    enrolledInEBill?: boolean;
    enrolledInText?: boolean;
    enrolledInEMail?: boolean;
    emailId?: string;
    optedForMail?: boolean;
    billLanguage?: string;
    billFormatType?: string;
    billSupressionInd?: string;
    billDeliveryMethod?: string;
    phoneNumber?: string;
    contractLineItemNumberSuppressionInd?: string;
}
