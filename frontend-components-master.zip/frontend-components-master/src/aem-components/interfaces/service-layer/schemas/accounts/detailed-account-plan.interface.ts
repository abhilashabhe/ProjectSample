import { IDetailedAccountSubscription } from './detailed-account-subscription.interface';

export interface IDetailedAccountPlan {
  planCode?: string;
  planId?: string;
  name?: string;
  description?: string;
  spanishLongDesc?: string;
  spanishPlanTypeDesc?: string;
  planType?: string;
  totalBasePrice?: number;
  totalFinalPrice?: number;
  subscriptionList?: IDetailedAccountSubscription[];
}
