import { AccountPlan } from './account-plan.interface';
export interface AccountPlans {
  accountPlansResponse: AccountPlan[];
}
