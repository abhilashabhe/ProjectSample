import { EquipmentInfo } from './equipment-info.interface';
import { IDetailedSubscriptionSoc } from './detailed-subscription-soc.interface';
import { IDetailedSubscriptionMac } from './detailed-subscription-mac.interface';

export interface IDetailedAccountSubscription {
  subscriptionId?: string;
  ptn?: string;
  planCode?: string;
  firstName?: string;
  lastName?: string;
  callerId?: string;
  rank?: string;
  dataShareAddOnIndicator?: boolean;
  primaryLineIndicator?: boolean;
  adjustedSpeedInd?: boolean;
  autoBuyUpInd?: boolean;
  effectiveDate?: string;
  isSingleSubOnSharedPlan?: boolean;
  equipmentInfo?: EquipmentInfo;
  socInfoList?: IDetailedSubscriptionSoc;
  planBasePrice?: number;
  planFinalPrice?: number;
  planMrcPrice?: number;
  planMacList?: IDetailedSubscriptionMac[];
  addOnMacList?: IDetailedSubscriptionMac[];
}
