export interface EquipmentInfo {
  itemId: string;
  name: string;
}
