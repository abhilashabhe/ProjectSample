export interface ILostStolenInfo {
  lostStolenInd?: boolean;
  effectiveDate?: string;
  expirationDate?: string;
}
