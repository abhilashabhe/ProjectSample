export interface AllowanceInfo {
  voiceAmount: string;
  skuId: string;
  dataUnit: string;
  textAmount: string;
  ensembleId: string;
  dataAmount: string;
}
