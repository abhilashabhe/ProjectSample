export interface NotificationRequestInterface {
  notificationMethod: string;
  preferenceOpted: string;
  flow: string;
  notificationSetting: string;
}
