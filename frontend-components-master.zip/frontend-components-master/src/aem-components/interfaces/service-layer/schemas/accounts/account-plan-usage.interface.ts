import {SubscriptionListInfo} from './account-plan-subscription-usage.interface';
export interface AccountPlanUsage {
  plancode: string;
  planname: string;
  plantype: string;
  subscriberList: SubscriptionListInfo[];
}
