
export type DetailedSocType =
  'ADDON_SOC'
  | 'MRC_SOC'
  | 'PLAN_INCLUDED_SOC'
  | 'UPCHARGE_SOC'
  | 'DEVICES_ACCESS_LEVEL_SOC';

export interface IDetailedSubscriptionSoc {
  serviceSOCSKU?: string;
  socType?: DetailedSocType;
  socName?: string;
  spanishSocDesc?: string;
  price?: number;
  startDate?: string;
  endDate?: string;
  sharingGroupId?: string;
}
