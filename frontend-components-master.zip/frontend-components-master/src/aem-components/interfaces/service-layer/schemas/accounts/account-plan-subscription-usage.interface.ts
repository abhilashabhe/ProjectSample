import {BillPeriod} from '../bills/bill-period.interface';
import {AccountPlanInfo} from './account-plan-usage-plan-info.interface';
import {UsageBuckets} from './account-plan-usage-buckets.interface';

export interface SubscriptionListInfo {
  subscriberId: string;
  billPeriod: BillPeriod;
  billSequence: number;
  planInfo: AccountPlanInfo;
  sharedUsageExclusionInd: string;
  sharedBuckets: UsageBuckets;
  individualBuckets: UsageBuckets;
}
