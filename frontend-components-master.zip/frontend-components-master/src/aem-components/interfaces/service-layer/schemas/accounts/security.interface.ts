export interface SecurityInterface {
  pin?: string;
  question?: {
    answer?: string;
    type?: string;
  };
}
