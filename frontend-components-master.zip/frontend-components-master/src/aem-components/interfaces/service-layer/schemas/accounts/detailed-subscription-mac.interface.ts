
export interface IDetailedSubscriptionMac {
  macId?: string;
  macStatus?: string;
  effectiveDate?: string;
  expirationDate?: string;
  amount?: number;
  duration?: string;
  macDesc?: string;
}
