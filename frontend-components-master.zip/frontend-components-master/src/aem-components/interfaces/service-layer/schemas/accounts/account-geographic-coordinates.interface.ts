export interface AccountGeographicCoordinates {
  latitude: number;
  longitude: number;
}
