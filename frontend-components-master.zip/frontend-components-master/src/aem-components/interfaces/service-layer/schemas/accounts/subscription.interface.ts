import { EquipmentInfo } from './equipment-info.interface';
import { ILostStolenInfo } from './lost-stolen-info.interface';

export interface SubscriptionInfo {
  adjustedSpeedInd: boolean;
  autoBuyUpInd: boolean;
  callerId: string;
  subscriptionId: string;
  ptn: string;
  planCode: string;
  firstName: string;
  lastName: string;
  rank?: string;
  dataShareAddOnIndicator: boolean;
  primaryLineIndicator: boolean;
  effectiveDate: string;
  equipmentInfo: EquipmentInfo;
  isSingleSubOnSharedPlan: boolean;
  lostStolenInfo: ILostStolenInfo;
  itemId?: string;
}
