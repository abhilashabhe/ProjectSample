export interface AccountStatusInterface {
  message: string;
}
