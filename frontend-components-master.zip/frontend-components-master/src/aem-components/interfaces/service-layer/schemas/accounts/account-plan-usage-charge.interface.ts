export interface Charge {
  amount: number;
  currency: string;
}
