import {Charge} from './account-plan-usage-charge.interface';
export interface BuyUpOption {
  id: number;
  volume: number;
  uom: string;
  charge: Charge;
}
