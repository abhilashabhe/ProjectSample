export interface TextCapablePtns {
  textCapablePTNs?: Array<string>;
}
