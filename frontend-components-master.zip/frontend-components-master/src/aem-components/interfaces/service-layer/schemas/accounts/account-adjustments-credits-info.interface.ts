export interface AdjustmentsCreditsInfo {
  value: number;
  description: string;
  date: string;
}
