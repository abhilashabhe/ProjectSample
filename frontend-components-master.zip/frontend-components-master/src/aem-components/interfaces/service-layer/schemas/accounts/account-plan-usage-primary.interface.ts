import {OnlineChargeInfo} from './account-plan-usage-charge-info.interface';
import {CurrentTierInfo} from './account-plan-usage-current-tier.interface';
import {BuyUpOption} from './account-plan-usage-buyup-option.interface';
export interface AccountPlanUsagePrimary {
  name?: string;
  category?: string;
  usageCategoryCode: string;
  usageCategoryName: string;
  usageCategoryGroupName: string;
  soc: null;
  sharingOfferId: string;
  effectiveDate: string;
  expirationDate: string;
  subsectionId: string;
  subsectionName: string;
  displayOrder: string;
  unitOfMeasure?: string;
  includedUnits?: string;
  usedUnits?: string;
  additionalUsedUnits?: string;
  additionalCharge?: string;
  bucketType?: string;
  unlimited: boolean;
  shared: boolean;
  onlineChargeInfo: OnlineChargeInfo;
  currentTierInfo: CurrentTierInfo;
  buyUpOptions: BuyUpOption[];
}
