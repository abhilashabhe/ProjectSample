export interface DeviceInterface {
    // Device id
    id: string;

    // The caller ID text
    callerId: string;

    // The device model name
    modelName: string;

    // The 10-digit telephone number without dashes or any other formatting
    ptn: string;
}
