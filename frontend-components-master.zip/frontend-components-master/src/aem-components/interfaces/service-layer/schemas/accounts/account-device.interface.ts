export interface AccountDevice {
  id?: string;
  callerID?: string;
  subscriptionDisplayName?: string;
  modelName?: string;
  ptn?: number;
}
