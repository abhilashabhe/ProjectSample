import { AdjustmentsCreditsInfo } from './account-adjustments-credits-info.interface';
export interface AccountAdjustmentsAndCredits {
  items: AdjustmentsCreditsInfo[];
}
