import {IServiceInput} from '../../';
import {AccountGeographicCoordinates} from './account-geographic-coordinates.interface';
import {AccountSubscriptionIssueType} from '../subscriptions/account-subscription-issue-type.interface';
import {BillingContact} from './billing-contact.interface';
import {SecurityQuestionInterface} from '../accounts/securityQuestion.interface';
import {NotificationRequestInterface} from '../accounts/notification.interface';

import {Ebill} from '../accounts/ebill.interface';

export interface IGetAccountRequestInterface extends IServiceInput {
  pathParams: {
    accountId: string;
  };
};

export interface IGetAccountPlanRequestInterface extends IServiceInput {
  pathParams: {
    accountId: string;
    planId: string;
  };
}

export interface IGetAccountSubscriptionRequestInterface extends IServiceInput {
  pathParams: {
    accountId: string;
    subscriptionId: string;
  };
};

export interface IPostAccountSubscriptionRequestInterface extends IGetAccountSubscriptionRequestInterface {
  data: BaseRequestIssues;
}

export interface PostIssuesRequest {
  geographicCoordinates: Array<AccountGeographicCoordinates>;
  type: Array<AccountSubscriptionIssueType>;
  reportedDateTime: string;
}

export interface BaseRequestIssues {
  properties: Array<PostIssuesRequest>;

}

export interface IPutBillingContactInterface extends IGetAccountRequestInterface {
  data: BillingContact;
};

export interface IPutEbillInterface extends IGetAccountRequestInterface {
  data: Ebill;
};

export interface IPutSecurityQuestionInterface extends IGetAccountRequestInterface {
   data: {
     services: PostSecurityInfo[];
   };
 }

export interface PostSecurityInfo {
  question: SecurityQuestionInterface;
  pin: string;
  currentPin: string;
 }

export interface IpostPinValidationInterface extends IGetAccountRequestInterface {
  data: {
    services: PostPinValidation[];
  };
}

export interface PostPinValidation {
   pin: string;
 }

export interface IpostNotificationMsgInterface extends IGetAccountRequestInterface {
  data: {
    notificationRequest: NotificationRequestInterface;
  };
}
