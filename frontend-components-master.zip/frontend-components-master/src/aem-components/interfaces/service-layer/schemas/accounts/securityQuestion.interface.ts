export interface SecurityQuestionInterface {
  type: string;
  answer: string;
  currentQuestionType?: string;
  currentAnswer?: string;
}
