import { AllowanceInfo } from './allowance-info.interface';
import { SubscriptionInfo } from './subscription.interface';

export interface AccountPlan {
  planCode: string;
  planId: string;
  name: string;
  description: string;
  spanishPlanTypeDesc: string;
  spanishLongDesc: string;
  type: string;
  allowanceInfo: AllowanceInfo;
  subscriptionList: SubscriptionInfo[];
}
