export interface FinancialStatus {
  aslAccount: boolean;
  totalDue: number;
  pastDueAmount?: number;
  pastDue?: boolean;
  estimatedAmount?: number;
  billAmount: number;
  arBalance?: number;
  adjustmentsAndCredits: number;
  recentPaymentsTotal: number;
  dueDate: string;
  nextDueDate?: string;
  lastPayment: number;
  lastPaymentDate: string;
  recentBillSequenceNumber: number;
  billPeriodStartDate?: string;
  billPeriodEndDate?: string;
  aslNetBalance?: number;
  aslSpendingLimit?: number;
  aslPercentageUsed?: number;
  aslBanSuspensionLimit?: number;
  monthlyRecurringCharge?: number;
}
