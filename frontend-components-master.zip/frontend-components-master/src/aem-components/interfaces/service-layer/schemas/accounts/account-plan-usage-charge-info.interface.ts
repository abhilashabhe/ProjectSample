export interface OnlineChargeInfo {
  ocsCounterStatus: string;
  meteringCategory: string;
  lastThresholdInd: string;
  budgetControlOfferId: string;
  overageRate: string;
}
