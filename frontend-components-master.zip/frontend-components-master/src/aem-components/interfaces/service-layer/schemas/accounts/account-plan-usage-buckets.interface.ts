import {AccountPlanUsagePrimary} from './account-plan-usage-primary.interface';
export interface UsageBuckets {
  talk?: AccountPlanUsagePrimary[];
  'push to talk'?: AccountPlanUsagePrimary[];
  text?: AccountPlanUsagePrimary[];
  data?: AccountPlanUsagePrimary[];
}
