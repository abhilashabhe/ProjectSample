export interface AccountPlanPendingChange {
  pendingPlanCode: string;
  pendingPlanName: string;
  pendingChangeIndicator: boolean;
  pendingChangeReason: string;
  effectiveFrom: string;
}
