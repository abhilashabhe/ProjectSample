export interface CurrentTierInfo {
  tierNumber: string;
  includedvolume: string;
  usedVolume: string;
  remainingvolume: string;
  uom: string;
}
