import { Address } from '../address.interface';
export interface BillingContact {
    firstName: string;
    lastName: string;
    address: Address;
    phoneNumber?: string;
    forceUpdate: boolean;
}
