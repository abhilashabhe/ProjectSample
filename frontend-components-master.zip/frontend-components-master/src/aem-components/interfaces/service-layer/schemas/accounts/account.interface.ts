
export interface Account {
  id?: string;
  type?: string;
  subtype?: string;
  billCycleDay?: number;
  firstName?: string;
  lastName?: string;
  creditClass?: string;
  creditClassDesc?: string;
  accountStatus?: string;
}
