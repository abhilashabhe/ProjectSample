export interface PaymentMethodValidatorResponse {
  isPinlessDebit: boolean;
  isValid: boolean;
}
