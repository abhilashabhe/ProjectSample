import { MinMaxAmountsInfo } from './min-max-amounts-info.interface';

export type ITransactionType = 'BILL_PAY'|'ACTIVATION';

export interface MinMaxAmounts {
  transactionType: ITransactionType;
  guest: MinMaxAmountsInfo;
  nonWallet: MinMaxAmountsInfo;
  wallet: MinMaxAmountsInfo;
}
