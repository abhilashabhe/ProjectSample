import { MinMaxAmounts } from './min-max-amounts.interface';

export interface PaymentChannelPolicy {
  walletMaxPO: number;
  minMaxAmounts: MinMaxAmounts[];
}
