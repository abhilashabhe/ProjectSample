import { IServiceInput } from '../../';
import { PaymentMethod } from './account-payment-methods.interface';
import { AccountPayment } from './account-payment.interface';
import { IGetAccountRequestInterface } from '../accounts/account.api-requests.interface';

export interface IGetAccountPaymentMethods extends IServiceInput {
  accountId: string;
  paymentMethodId: string;
}

export interface IPostAccountPaymentMethods extends IGetAccountRequestInterface {
  data: PaymentMethod ;
}

export interface IPutAccountPaymentMethods extends IGetAccountPaymentMethods {
  data: PaymentMethod ;
}

export interface IDeleteAccountPaymentMethods extends IGetAccountPaymentMethods {
  data: PaymentMethod ;
}

export interface IPostAccountPayment extends IGetAccountRequestInterface {
  data: AccountPayment ;
}
