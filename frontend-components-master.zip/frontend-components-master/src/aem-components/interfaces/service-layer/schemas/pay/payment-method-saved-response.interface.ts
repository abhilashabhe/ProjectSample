import { IPaymentMethodType } from './payment-method-validator.api-requests.interface';
export interface PaymentMethodSavedResponse {
  id: string;
  paymentMethodToken: string;
  nickname: string;
  type: IPaymentMethodType;
}
