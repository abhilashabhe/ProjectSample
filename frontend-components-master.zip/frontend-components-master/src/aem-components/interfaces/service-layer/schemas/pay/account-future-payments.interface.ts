export interface FuturePayment {
  amount?: number;
  paymentType?: string;
  date?: string;
  confirmationNumber?: string;
  creditCardType?: string;
  expDate?: string;
  nickname?: string;
  number?: string;
  paymentMethodId?: string;
  type?: string;
}
