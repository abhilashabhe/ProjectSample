export interface AccountPayment {
  amount: number;
  paymentMethodId: string;
  type: string;
  creditCardType: string;
  debitCardType: string;
  routingNumber: string;
  number: string;
  expDate: string;
  securityCode: string;
  zip: string;
  isPinlessDebit: boolean;

}
