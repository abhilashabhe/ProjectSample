export interface NegativeListed {
  isNegativeListed: boolean;
}
