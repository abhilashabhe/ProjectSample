export type ICardType = 'VISA'|'MASTERCARD'|'AMEX'|'DISCOVER';
export type IPaymentMethodType = 'CREDIT_CARD'|'DEBIT_CARD'|'CHECKING_ACCOUNT'|'SAVINGS_ACCOUNT';

export interface PaymentMethodValidator {
  type: IPaymentMethodType;
  creditCardType?: ICardType;
  number: string;
  routingNumber?: string;
  expDate?: string;
  zip?: string;
  securityCode?: string;
}
