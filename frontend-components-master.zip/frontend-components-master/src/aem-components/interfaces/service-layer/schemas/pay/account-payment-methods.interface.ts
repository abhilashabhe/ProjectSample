export interface PaymentMethod {
  id?: string;
  type?: string;
  creditCardType?: string;
  routingNumber?: string;
  number?: string;
  expDate?: string;
  nickname?: string;
  isAutopay?: boolean;
  isPrimary?: boolean;
  zip?: string;
  securityCode?: string;
  isPinlessDebit?: boolean;
  address1?: string;
  address2?: string;
  city?: string;
  state?: string;
  paymentMethodToken?: string;
}
