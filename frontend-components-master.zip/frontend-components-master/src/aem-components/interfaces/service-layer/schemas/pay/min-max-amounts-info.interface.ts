export interface MinMaxAmountsInfo {
  minAmount: number;
  maxAmount: number;
  ceilingAmount: number;
}
