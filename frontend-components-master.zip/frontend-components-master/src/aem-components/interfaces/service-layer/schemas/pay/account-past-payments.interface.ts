export interface PastPayment {
  action: string;
  amount: number;
  date: string;
  number: number;
  creditCardType: string;
  type: string;
  autopayInd: boolean;
  paymentMethodId: string;
  confirmationNumber: string;
  nickname: string;
  loan: string;
}
