export interface Address {
  attention?: string;
  address1?: string;
  address2?: string;
  city?: string;
  urbanization?: string;
  state?: string;
  zip?: string;
  zip4code?: string;
  country?: string;
}

export interface AddressStateOption {
  stateAbbr: string;
  stateFullName: string ;
}
