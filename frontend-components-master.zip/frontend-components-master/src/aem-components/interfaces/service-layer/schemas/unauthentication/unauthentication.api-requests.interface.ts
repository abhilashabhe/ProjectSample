import { IServiceInput } from '../..';

export interface IPerformUnauthenticationRequest extends IServiceInput {
    data: {};
}
