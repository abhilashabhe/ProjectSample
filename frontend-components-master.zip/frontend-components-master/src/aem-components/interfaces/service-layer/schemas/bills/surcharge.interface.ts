export interface Surcharge {
  surchargeName?: string;
  surchargeFeeValue?: number;
}
