export interface GovernmentTax {
  name?: string;
  type?: string;
  value?: number;
}
