import { BillPeriod } from './bill-period.interface';
import { Surcharge } from './surcharge.interface';
import { GovernmentTax } from './government-tax.interface';
export interface Bill {
  id?: string;
  planName?: string;
  amountDue?: number;
  dueDate?: Date;
  billPeriod?: BillPeriod;
  surcharge?: Surcharge;
  governmentTax?: GovernmentTax;
}
