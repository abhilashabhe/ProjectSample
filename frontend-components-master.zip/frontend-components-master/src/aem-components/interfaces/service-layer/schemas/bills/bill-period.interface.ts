export interface BillPeriod {
  start?: string;
  end?: string;
}
