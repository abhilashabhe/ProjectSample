/*
  Interface definitions are based on the RAML spec found here:
  https://github.com/SprintDigital/digital-apis/blob/target_spec_raml1.0/types/order-types.raml
*/

import { AccountAddress } from './accountAddress.interface';

export type IPaymentType = 'NEW_CARD'|'EXISTING_CARD'|'BILL_TO_ACCOUNT';
export type ICreditCardType = 'Discover'|'MasterCard'|'Amex'|'Visa'|'Diners';

export type INewPaymentAddress = 'OPTIONAL'|'MANDATORY'|'NOT_ALLOWED';

export interface ICreditCard {
  cardNumber: string;
  expirationDate: Date;
  creditCardType: ICreditCardType;
}

export interface IAccountCreditCardInfo extends ICreditCard {
  walletEntryUniqueID: string;
}

export interface IOrderCreditCard extends ICreditCard {
  nameOnCard: string;
  securityCode: string;
}

export interface IOrderPaymentOptions {
  type: IPaymentType[];
  accountCreditCards: IAccountCreditCardInfo[];
  creditCards: ICreditCardType[];
  isBillToAccountAllowed: boolean;
  newPaymentAddress: INewPaymentAddress;
  isDifferentCreditCardZipCodeAllowed?: boolean;
}

export interface IAccountCreditCardInfoId {
  walletEntryUniqueID: string;
  securityCode: string;
}

export interface IOrderPaymentSelection {
  paymentType: IPaymentType;
  orderCreditCardInfo?: IOrderCreditCard;
  accountCreditCardInfo?: IAccountCreditCardInfoId;
  paymentAddress?: AccountAddress;
  isDifferentCreditCardZipCodeAllowed?: boolean;
}
