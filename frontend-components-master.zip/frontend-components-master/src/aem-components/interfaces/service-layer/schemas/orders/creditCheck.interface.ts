export type CreditCheckType
  = 'CREDIT_CHECK_TYPE_FEIN'
  | 'CREDIT_CHECK_TYPE_SSN_DOB'
  | 'CREDIT_CHECK_TYPE_DOB'
  | 'CREDIT_CHECK_TYPE_DOB_ONLY'
  | 'CREDIT_CHECK_TYPE_NONE';

export interface CreditClass {
  accountSubType?: string;
  accountType?: string;
  applicationNumber?: string;
  aslLimit?: number;
  aslRequired?: string;
  creditClass?: string;
  lineLimit?: number;
}

export interface CreditCheckOptions {
  creditCheckType?: CreditCheckType[];
}

export interface CreditCheck {
  applicationNumber?: string;
  companyName?: string;
  creditCheckType: CreditCheckType;
  dateOfBirth?: string;
  doFinanceChatCheck?: boolean;
  doNotValidateSSNInBillingSystem?: boolean;
  fein?: string;
  ssn?: string;
}
