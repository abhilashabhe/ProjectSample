import {SecurityQuestion} from './securityQuestion.interface';

export interface SecurityQuestionOptions {
  securityQuestions: [SecurityQuestion];
}
