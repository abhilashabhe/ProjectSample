import {AccountAddress} from './accountAddress.interface';
export interface AccountRequest {
  name?: {
    firstName?: string;
    lastName?: string;
  };
  contact?: {
    phone?: string;
    email?: string;
  };
  address?: AccountAddress;
}

export interface UpdateAccountRequestResponse {
  errors?: any[];
  correctedAddress?: {
    address1?: string;
    address2?: string;
    urbanization?: string;
    zip?: string;
    city?: string;
    state?: string;
  };
}
