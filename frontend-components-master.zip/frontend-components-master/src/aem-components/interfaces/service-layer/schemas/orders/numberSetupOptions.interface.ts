import {SubscriptionLineOptions} from './subscriptionLineOptions.interface';

export interface NumberSetupOptions {
  atleastOnePortInNeeded: boolean;
  requiredCarrier: boolean;
  defaultNPA: string;
  subscriptionLineOptions: SubscriptionLineOptions[];
}
