export interface SubscriptionLineOptions {
  uniqueID: string;
  isPortInMandatory: boolean;
}
