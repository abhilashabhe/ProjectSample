export interface OrderStatus {
  complete?: string[];
  incomplete?: string[];
  errors?: string[];
  status?: string;
}
