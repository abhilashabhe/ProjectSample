import { IServiceInput } from '../..';
import { AccountRequest } from './account-request.interface';
import { Delivery, PISDelivery } from './delivery.interface';
import { Shipping } from './shipping.interface';
import { Address } from '../address.interface';
import { Cart } from '../carts/cart.interface';
import { SecurityQuestion } from './securityQuestion.interface';
import { NumberSetup } from './numberSetup.interface';

export interface IGetOrderRequest extends IServiceInput {
  pathParams: {
    orderId: string;
  };
}

export interface IPostOrdersRepresentative extends IGetOrderRequest {
  data: {
    representativeId: string;
  }
}

export interface IPostOrderConfirmation extends IServiceInput {
  pathParams: {
    orderId: string;
    confirmationId: string;
  };
}

export interface IGetOrderConfirmation {
  delivery: {
    shippingAddress: Address;
    shippingDuration: string;
  };
  contact: AccountRequest;
  pin: string;
  payment: {
    cardType: string;
    cardNumber: string;
  };
  orderConfirmationId: string;
  generatedConfirmationId: string;
  securityQuestions: SecurityQuestion;
  numberSetUpInfo: NumberSetup;
  cart: Cart;
}

export interface IUpdateAccountRequestInterface extends IGetOrderRequest {
  data: AccountRequest;
}

export interface IUpdateSecurityQuestion extends IGetOrderRequest {
  data: {
    securityQuestionCode: string;
    securityQuestionAnswer: string;
  };
}

export interface IUpdateAccountPin extends IGetOrderRequest {
  data: {
    securityPin: string;
  };
}

export interface IUpdateCreditCheckInterface extends IGetOrderRequest {
  data: {
    doNotValidateSSNInBillingSystem: string;
    ssn: string;
    dateOfBirth: string;
    fein: string;
    companyName: string;
    creditCheckType: string;
  };
}

export interface IUpdateDeliveryInterface extends IGetOrderRequest {
  data: Delivery | PISDelivery;
}

export interface IGetAgreementsInterface extends IServiceInput {
  pathParams: {
    orderId: string;
    agreementsType: string;
  };
}

export interface IUpdateAgreementsInterface extends IServiceInput {
  pathParams: {
    orderId: string;
    agreementsType: string;
  };
  data: {
    agreements: [{
      key: string;
      accepted: boolean;
    }]
  };
}

export interface IUpdatePaymentInterface extends IGetOrderRequest {
  data: {
    paymentType: string;
    orderCreditCardInfo: {
      creditCardType: string;
      nameOnCard: string;
      cardNumber: string;
      expirationDate: string;
      securityCode: string;
      zipCode: string;
    };
    accountCreditCardInfo: string;
  };
}

export interface IPostOrdersShipping extends IGetOrderRequest {
  data: Shipping;
}
