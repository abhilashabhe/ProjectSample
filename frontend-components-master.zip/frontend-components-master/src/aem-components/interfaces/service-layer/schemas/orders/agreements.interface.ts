export interface Agreements {
  agreements: [{
    key: string;
    accepted: boolean;
  }];
}
