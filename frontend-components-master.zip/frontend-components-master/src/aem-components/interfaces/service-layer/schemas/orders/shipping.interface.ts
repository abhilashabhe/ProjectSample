import { Address } from '../address.interface';

export interface ShippingAddress {
  attention?: string;
  address1?: string;
  address2?: string;
  city?: string;
  urbanization?: string;
  state?: string;
  zip?: string;
  zip4code?: string;
  country?: string;
}

export interface Shipping {
  code?: string;
  alternateShippingAddress?: Address;
}

export interface ShippingOptions {
  isShippingAddressAlterable?: boolean;
  defaultShippingAddress?: ShippingAddress;
  shippingOptions?: Array<ShippingOption>;
}

export interface ShippingOption {
  code?: string;
  description?: string;
  chargeCode?: string;
  shippingDuration?: string;
  isDefaultShippingMethod?: boolean;
}
