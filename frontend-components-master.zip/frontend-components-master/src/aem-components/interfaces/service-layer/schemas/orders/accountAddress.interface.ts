export interface AccountAddress {
  address1?: string;
  address2?: string;
  urbanization?: string;
  zip?: string;
  city?: string;
  state?: string;
}
