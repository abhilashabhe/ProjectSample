import {SubscriptionPortInInfo} from './subscriptionPortInInfo.interface';
import {PortInAccount} from './portInAccount.interface';
export interface NumberSetup {
  carrier: string;
  validateAccountInfoOffline: boolean;
  subscriptionPortInInfo: SubscriptionPortInInfo[];
  portInAccount: PortInAccount;
}
