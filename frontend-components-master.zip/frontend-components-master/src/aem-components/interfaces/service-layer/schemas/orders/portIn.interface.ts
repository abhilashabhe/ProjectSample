export interface PortIn {
  type: string;
}

export interface PortInRequest {
  params: {
    orderId: string
    portIn: string
  };
}
