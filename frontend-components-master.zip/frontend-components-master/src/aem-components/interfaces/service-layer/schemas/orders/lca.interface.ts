export interface LCA {
  description: string;
}

export interface LCARequest {
  params: {
    orderId: string
    lca: string
  };
}
