import {AccountAddress} from './accountAddress.interface';
import { Name } from '../name.interface';
export interface PortInAccount {
  accountType: string;
  companyName: string;
  ssn: string;
  fein: string;
  accountName: Name;
  accountPin: string;
  accountAddress: AccountAddress;
}
