export interface SecurityQuestion {
  securityQuestionCode: string;
  securityQuestionText: string;
}
