import { Address } from '../address.interface';

export type DeliveryType = 'STH' | 'PIS' | 'EXP';

export interface Delivery {
  deliveryType?: DeliveryType;
}

export interface DeliveryOption {
  deliveryType?: DeliveryType;
  deliveryDescription?: string;
}

export interface PISDelivery extends Delivery {
  storeId?: string;
  duration?: string;
  storeAppointment?: string;
  storeName?: string;
  storeHours?: string;
  storeAddress?: Address;
  contactInformation?: PISDeliveryContactInfo;
  searchCriteriaInfo?: PISDeliverySearchCriteria;
}

export interface PISDeliveryContactInfo {
  firstName?: string;
  lastName?: string;
  contactNumber?: string;
  emailAddress?: string;
  canBeContactedForAppointmentUpdates?: boolean;
  sprintCustomer?: boolean;
}

export interface PISDeliverySearchCriteria {
  currentSelectedAddress?: string;
  currentSelectedDistance?: string;
  currentSelectedAvailability?: string;
}
