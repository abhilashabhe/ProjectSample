/* tslint:disable:no-empty-interface */
export interface Order {

}
