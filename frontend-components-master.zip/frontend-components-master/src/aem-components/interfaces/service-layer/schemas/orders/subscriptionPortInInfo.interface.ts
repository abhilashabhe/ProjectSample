export interface SubscriptionPortInInfo {
  uniqueId: string;
  selectedLineType: string;
  ptn: string;
}
