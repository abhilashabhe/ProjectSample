export interface IAlternateDevice {
  deviceSku: string;
  deviceName: string;
  deviceDescription: string;
  deviceColorName: string;
  deviceIconImage: string;
  deviceSize2Image: string;
  deviceSize3Image: string;
  deviceSize4Image: string;
  deviceSmallImage: string;
  installmentAmount: number;
  lastInstallmentAmount: number;
  residualAmount: number;
  activationFee: number;
  downPaymentAmount: number;
  deviceEnsembleId: string;
}

export interface IAlternateDeviceInfo {
  packageId: string;
  contractTerm: string;
  purchaseMethod: string;
  alternateDeviceList: IAlternateDevice[];
}

export interface IAlternateDeviceResponse {
  validated: boolean;
  alternateDeviceInfo: IAlternateDeviceInfo;
  contractName: string;
}
