export interface AccountPin {
  securityPin: string;
}
