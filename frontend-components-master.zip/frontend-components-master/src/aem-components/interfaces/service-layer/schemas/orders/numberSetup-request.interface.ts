import {SubscriptionPortInInfo} from './subscriptionPortInInfo.interface';
import {PortInAccount} from './portInAccount.interface';
export interface NumberSetupRequest {
  carrier: string;
  validateAccountInfoOffline: boolean;
  subscriptionPortInInfo: SubscriptionPortInInfo[];
  portInAccount?: PortInAccount;
}
