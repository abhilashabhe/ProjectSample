export interface AgreementsOptions {
  agreements: [{
    key: string;
    accepted: boolean;
  }];
}
