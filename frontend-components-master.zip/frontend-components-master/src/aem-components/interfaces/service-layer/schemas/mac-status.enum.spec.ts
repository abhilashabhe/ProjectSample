import { MacStatusEnum } from './mac-status.enum';

describe('Mas Status Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof MacStatusEnum.NEW_MAC).toBe('string');
  });

});
