export interface UpgradeEligibility {
  MessageBody: string;
  MessageHeader: string;
  ShopUrl: string;
  UPGEligibilityCode: string;
  displayFindAStore: string;
}
