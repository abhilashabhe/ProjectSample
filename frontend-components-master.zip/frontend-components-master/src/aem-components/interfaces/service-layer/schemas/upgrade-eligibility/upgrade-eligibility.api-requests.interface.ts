import {IServiceInput} from '../../';
export interface IGetUpgradeEligibilityRequest extends IServiceInput {
  queryParams: {
    phoneNumber?: string;
    billingZipcode?: string;
  };
}
