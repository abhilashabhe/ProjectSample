import { IServiceInput } from '../..';

export interface IGetDeviceRequest extends IServiceInput {
  pathParams: {
    deviceId: string;
  };
  queryParams?: {
    accountType?: string;
    accountSubType?: string;
  };
}

export interface IGetDevicePricesRequest extends IServiceInput {
  pathParams: {
    deviceId: string;
  };
  queryParams: {
    accountType?: string;
    accountSubType?: string;
    creditClass?: string;
    flow?: string;
    subscriptionId?: string;
  };
}

export interface IGetDevicesPricesRequest extends IServiceInput {
  queryParams: {
    accountType?: string;
    accountSubType?: string;
    creditClass?: string;
    subscriptionId?: string;
    flow?: string;
  };
}
