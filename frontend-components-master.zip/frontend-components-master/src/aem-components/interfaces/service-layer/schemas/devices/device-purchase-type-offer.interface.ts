export interface PurchaseTypeOffer {
  description: string;
  groupCode: string;
  promoCode: string;
  tradeInChargeAmount: string;
  tradeInRequired: boolean;
}
