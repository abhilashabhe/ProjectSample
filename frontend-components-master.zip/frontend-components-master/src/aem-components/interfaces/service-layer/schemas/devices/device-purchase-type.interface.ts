import { PurchaseTypeOffer } from './device-purchase-type-offer.interface';
export interface PurchaseType {
  contractId: string;
  contractName: string;
  type: string;
  downPayment: number;
  firstMonthInstallment: number;
  lastMonthInstallment: number;
  duration: number;
  offer?: PurchaseTypeOffer;
}
