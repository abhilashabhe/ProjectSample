export interface Color {
  hex?: string;
  name?: string;
}
