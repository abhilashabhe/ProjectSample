export class MemoryUnitEnum {

  static get GB(): string {
    return 'GB';
  }

}
