import {PurchaseType} from './device-purchase-type.interface';

export interface DevicePrices {
  id: string;
  purchaseTypes: PurchaseType[];
}
