import { Color } from './color.interface';

export interface Device {
  id?: string;
  productId?: string;
  familyId?: string;
  defaultDeviceId?: string;
  isDefaultDevice?: boolean;
  familyNameKey?: string;
  productName?: string;
  name?: string;
  manufacturer?: string;
  memory?: string;
  description?: string;
  supportsNoCreditCheck?: boolean;
  deviceType?: string;
  color?: Color;
  inventoryStatus?: 'IN_STOCK' | 'OUT_OF_STOCK' | 'BACK_ORDER' | 'PRE_ORDER';
  isPreOrder?: boolean;

  /** Properties that are present in response but not in RAML */
  defaultSkuId?: string;
  familyName?: string;
  preOrderEndDate?: string;
  skuId?: string;
}
