import { MemoryUnitEnum } from './memory-unit.enum';

describe('Memory Unit Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof MemoryUnitEnum.GB).toBe('string');
  });

});
