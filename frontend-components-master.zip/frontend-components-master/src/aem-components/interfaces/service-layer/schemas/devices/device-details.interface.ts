import { MemoryUnitEnum } from './memory-unit.enum';
import { Color } from './color.interface';
import { LowCoverage } from './low-coverage.interface';
export interface DeviceDetails {
  memory?: string;
  memoryUnit?: MemoryUnitEnum;
  networkIdentifier?: string;
  color?: Color;
  lowCoverage?: LowCoverage;
  coverageMapUrl?: string;
  coverageMapLinkUrl?: string;
  isPreOrder?: boolean;
  isCallToOrder?: boolean;
}
