export interface LowCoverage {
  low3g?: boolean;
  low4g?: boolean;
  low4glte?: boolean;
}
