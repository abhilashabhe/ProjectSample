import { IServiceInput } from '../..';

export interface IGetTutorialRequest extends IServiceInput {
  pathParams: {
    wdsId: string;
    tutorialId: string;
    sprintId: string;
  };
}


