import { IServiceInput } from '../..';

export interface IGetAEMGenericItemDataRequest extends IServiceInput {
  pathParams: {
    searchKey: string;
    searchValue: string;
  };
}

export interface IGetAEMDevicePromoRequest extends  IServiceInput {
  pathParams: {
    skuList: string;
  };
}

export interface IGetAEMSearchArticlesRequest extends IServiceInput {
  pathParams: {
    search: string;
  };
}

export interface IGetAEMKnowledgeRequest extends IServiceInput {
  pathParams: {
    search: string;
  };
}
