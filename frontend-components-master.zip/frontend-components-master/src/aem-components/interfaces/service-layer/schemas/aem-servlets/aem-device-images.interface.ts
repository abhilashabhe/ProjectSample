export interface AEMDeviceImages {
  deviceData?: AEMDeviceImage[];
}

export interface AEMDeviceImage {
  displayname?: string;
  identifier?: string;
  image?: string[];
  colorname?: string;
  ensemblid?: string;
  hexcode?: string;
  derivedinventorystatus?: string;
  availabilitystatus?: string;
  purchaseoptionname?: string;
  url?: string;
}
