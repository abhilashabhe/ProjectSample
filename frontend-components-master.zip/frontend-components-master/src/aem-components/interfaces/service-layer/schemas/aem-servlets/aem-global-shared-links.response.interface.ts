export interface AEMGlobalSharedLinksResponse {
  adminPage: {
    sharedlinkdestination: string;
    sharedlinkkey: string;
  };
}

export interface AEMGlobalSharedLinks {
  [key: string]: string;
}
