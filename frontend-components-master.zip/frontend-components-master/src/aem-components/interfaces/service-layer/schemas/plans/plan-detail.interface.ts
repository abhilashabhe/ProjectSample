import { SystemRequiredAddon } from './system-required-addon.interface';
import { MacItem } from '../mac-item.interface';
export interface PlanDetail {
  socSku?: string;
  systemRequiredAddons?: Array<SystemRequiredAddon>;
  macList?: Array<MacItem>;
}
