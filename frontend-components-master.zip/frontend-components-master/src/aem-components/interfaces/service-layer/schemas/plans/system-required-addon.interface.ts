import { MacItem } from '../mac-item.interface';
export interface SystemRequiredAddon {
  socSku?: string;
  priceChanges?: number;
  macList?: Array<MacItem>;
  type?: string;
  charge?: number;
}
