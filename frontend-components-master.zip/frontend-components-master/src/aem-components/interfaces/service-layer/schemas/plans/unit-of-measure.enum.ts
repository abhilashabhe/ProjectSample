export class UnitOfMeasureEnum {
  static get GB(): string {
    return 'gb';
  }

  static get KB(): string {
    return 'kb';
  }

  static get MB(): string {
    return 'mb';
  }

  static get MESSAGES(): string {
    return 'messages';
  }

  static get MINUTES(): string {
    return 'minutes';
  }
}
