import { SocStatusEnum } from './soc-status.enum';
import { SocTypeEnum } from './soc-type.enum';
import { MacItem } from '../mac-item.interface';

export interface RequiredAddon {
  requiredSocSku?: string;
  requiredSOCDescription?: string;
  requiredSOCMACList: Array<MacItem>;
  socStatus?: SocStatusEnum;
  socType?: SocTypeEnum;
  price?: number;
  onPromotion?: boolean;
  hasPromotionalOfferButNotEligible?: boolean;
}
