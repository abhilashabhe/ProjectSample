import { PlanTypeEnum } from './plan-type.enum';
import { UnitOfMeasureEnum } from './unit-of-measure.enum';
import { DeviceCategoryEnum } from './device-category.enum';
import { ContractTypeEnum } from './contract-type.enum';

export interface Plan {
  carryForward?: boolean;
  duration?: number;
  exclusivePlan?: boolean;
  id?: string;
  includedDataAmount?: string | number;
  includedDataUnits?: UnitOfMeasureEnum;
  includedMinutes?: number;
  maxDevices?: number;
  minDevices?: number;
  name?: string;
  planId?: string;
  planSOCSKU?: string;
  planType?: PlanTypeEnum;
  price?: number;
  supportedContractTypes?: Array<ContractTypeEnum>;
  supportedDeviceCategory?: DeviceCategoryEnum;
  shared?: boolean;
  socId?: string;
}

export interface AccountPlansLookup {
  planCategories: AccountPlanCategory[];
}

export interface AccountPlanCategory {
  categoryId: string;
  planProducts: AccountPlanProduct[];
}

export interface AccountPlanProduct {
  productId: string;
  planType: string;
  exclusive: boolean;
  existingInAccount: boolean;
  voiceAmount: number;
  textAmount: number;
  dataAmount: number;
  saleStatus: string;
  dataUnit: string;
  linesMinLimit: number;
  linesMaxLimit: number;
  totalBasePrice: number;
  totalFinalPrice: number;
  linesDetail: AccountPlanProductLineDetails[];
}

export interface AccountPlanProductLineDetails {
  uniqueId: string;
  planSOCSKU: string;
  planBasePrice: number;
  planFinalPrice: number;
  planMRCPrice: number;
  lineRank: number;
  systemRequiredAddons: AccountPlanProductSystemRequiredAddons[];
  planMACList: AccountPlanMAC[];
}

export interface AccountPlanProductSystemRequiredAddons {
  serviceSOCSKU: string;
  socType: string;
  price: number;
  promotionApplied: boolean;
  hasPromotionButExceedLineLimit: boolean;
  requiredMACList?: AccountPlanMAC[];
}

export interface AccountPlanMAC {
  macId: string;
  macDescription?: string;
  macName?: string;
  associatedToDevicePurchaseMethod: boolean;
  macStatus: string;
  effectiveDate: string;
  expirationDate: string;
  amount: number;
  duration: number;
}
