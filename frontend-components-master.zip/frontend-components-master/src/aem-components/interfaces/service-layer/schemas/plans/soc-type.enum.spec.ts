import { SocTypeEnum } from './soc-type.enum';

describe('SOC Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof SocTypeEnum.DEVICE_ACCESS_LEVEL_SOC).toBe('string');
    expect(typeof SocTypeEnum.MRC_SOC).toBe('string');
    expect(typeof SocTypeEnum.PLAN_INCLUDED_SOC).toBe('string');
    expect(typeof SocTypeEnum.PROMOTIONAL_SOC).toBe('string');
    expect(typeof SocTypeEnum.UNKNOWN_SOC).toBe('string');
    expect(typeof SocTypeEnum.UPCHARGE_SOC).toBe('string');
  });

});
