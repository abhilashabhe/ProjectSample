import { UnitOfMeasureEnum } from './unit-of-measure.enum';

describe('Unit of Measure Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof UnitOfMeasureEnum.GB).toBe('string');
    expect(typeof UnitOfMeasureEnum.KB).toBe('string');
    expect(typeof UnitOfMeasureEnum.MB).toBe('string');
    expect(typeof UnitOfMeasureEnum.MESSAGES).toBe('string');
    expect(typeof UnitOfMeasureEnum.MINUTES).toBe('string');
  });

});
