export class DeviceCategoryEnum {
  static get FEATURE_PHONE(): string {
    return 'featurePhone';
  }

  static get SMART_PHONE(): string {
    return 'smartPhone';
  }

  static get TABLET(): string {
    return 'tablet';
  }

  static get DATA_CARD(): string {
    return 'dataCard';
  }

  static get HOTSPOT(): string {
    return 'hotspot';
  }

  static get MACHINE_TO_MACHINE(): string {
    return 'machineToMachine';
  }
}
