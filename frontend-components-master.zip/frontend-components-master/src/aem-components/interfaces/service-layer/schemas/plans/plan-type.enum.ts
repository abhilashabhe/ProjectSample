export class PlanTypeEnum {
  static get SINGLE(): string {
    return 'SINGLE';
  }

  static get SHARED(): string {
    return 'SHARED';
  }

  static get HYBRID_SHARING(): string {
    return 'HYBRID_SHARING';
  }

  static get GROUP(): string {
    return 'GROUP';
  }

  static get LTS_DATA(): string {
    return 'LTS_DATA';
  }
}
