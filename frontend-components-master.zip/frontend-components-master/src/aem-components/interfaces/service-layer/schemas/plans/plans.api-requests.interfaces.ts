import { IServiceInput } from '../..';
import { ILineTypeValue } from '../lookup-services/lookup-services-line-details.interface';
import { IApplicationID } from '../lookup-services/lookup-services.api-request.interface';

export interface IGetPlanRequest extends IServiceInput {
  params: {
    planId: string;
    deviceId: string;
    accountType: string;
    accountSubType: string;
    csa: string;
    deviceSaleType?: string;
    numberOfSubscribers?: string;
    planType?: string;
    salesChannel?: string;
  };
}

export interface IGetATGPlanRequest extends IServiceInput {
  params: {
    planId: string;
  };
}

export interface IGetPlansRequest extends IServiceInput {
  params: {
    deviceId: string;
    accountType: string;
    accountSubType: string;
    csa: string;
    deviceSaleType?: string;
    numberOfSubscribers?: string;
    planType?: string;
    salesChannel?: string;
    category?: string;
  };
}

export interface IGetPlanPendingChangeRequest extends IServiceInput {
  params: {
    accountId: string;
    planId: string;
  };
}

export interface IGetAccountPlansRequest extends IServiceInput {
  queryParams: {
    ban?: string;
    applicationId?: IApplicationID;
    salesChannelCode?: string;
    accountType?: string;
    accountSubType?: string;
    corpId?: string;
    creditClass?: string;
    zipCode?: string;
    lineDetail?: {
      lineType?: ILineTypeValue,
      itemID?: string;
      subscriberID?: string;
      contractId?: string;
      quantity?: number | string;
    }
  };
}

export interface AccountPlanLinesDetail {
  uniqueId?: string;
  lineType?: string;
  subscriberID?: string;
  newDeviceInfo?: {
    itemID?: string;
    contractId?: string;
  };
}

export interface IGetAccountPlansRequest extends IServiceInput {
  data: {
    applicationId?: string;
    ban?: string;
    newAccountInfo?: {
      accountInfo?: {
        accountType?: string;
        accountSubType?: string;
        corpId?: string;
      };
      creditClass?: string;
    };
    zipCode?: string;
    salesChannelCode?: string;
    linesDetail?: AccountPlanLinesDetail[];
  };
}
