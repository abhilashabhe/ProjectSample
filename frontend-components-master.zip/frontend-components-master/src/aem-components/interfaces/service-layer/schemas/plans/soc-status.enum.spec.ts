import { SocStatusEnum } from './soc-status.enum';

describe('SOC Status Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof SocStatusEnum.CARRY_FORWARD_REQUIRED_SOC).toBe('string');
    expect(typeof SocStatusEnum.NEW_REQUIRED_SOC).toBe('string');
    expect(typeof SocStatusEnum.SYSTEM_REMOVED_REQUIRED_SOC).toBe('string');
  });

});
