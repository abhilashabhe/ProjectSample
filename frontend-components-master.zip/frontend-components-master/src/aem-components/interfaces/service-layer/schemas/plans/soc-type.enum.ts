export class SocTypeEnum {
  static get MRC_SOC(): string {
    return 'MRC_SOC';
  }

  static get UPCHARGE_SOC(): string {
    return 'UPCHARGE_SOC';
  }

  static get PROMOTIONAL_SOC(): string {
    return 'PROMOTIONAL_SOC';
  }

  static get PLAN_INCLUDED_SOC(): string {
    return 'PLAN_INCLUDED_SOC';
  }

  static get DEVICE_ACCESS_LEVEL_SOC(): string {
    return 'DEVICE_ACCESS_LEVEL_SOC';
  }

  static get UNKNOWN_SOC(): string {
    return 'UNKNOWN_SOC';
  }
}
