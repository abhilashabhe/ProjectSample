import { Discount } from '../carts/discount.interface';
import { MacItem } from '../mac-item.interface';
import { RequiredAddon } from './required-addon.interface';
export interface PlanItem {
  catalogReferenceId?: string;
  name?: string;
  planCommerceItemId?: string;
  planRequiredSocs?: Array<RequiredAddon>;
  planSocSku?: string;
  postPurchaseDiscounts?: Array<Discount>;
  price?: number;
  pricePlanMACList?: Array<MacItem>;
}
