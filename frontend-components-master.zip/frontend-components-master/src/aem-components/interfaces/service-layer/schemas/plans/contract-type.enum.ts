export class ContractTypeEnum {
  static get SUBSIDY(): string {
    return 'SUBSIDY';
  }

  static get LEASE(): string {
    return 'LEASE';
  }

  static get INSTALLMENT_BILLING(): string {
    return 'INSTALLMENT_BILLING';
  }

  static get RETAIL(): string {
    return 'RETAIL';
  }

  static get BYOD(): string {
    return 'BYOD';
  }
}
