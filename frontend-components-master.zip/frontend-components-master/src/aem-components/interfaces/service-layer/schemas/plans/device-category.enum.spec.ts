import { DeviceCategoryEnum } from './device-category.enum';

describe('Device Category Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof DeviceCategoryEnum.DATA_CARD).toBe('string');
    expect(typeof DeviceCategoryEnum.FEATURE_PHONE).toBe('string');
    expect(typeof DeviceCategoryEnum.HOTSPOT).toBe('string');
    expect(typeof DeviceCategoryEnum.MACHINE_TO_MACHINE).toBe('string');
    expect(typeof DeviceCategoryEnum.SMART_PHONE).toBe('string');
    expect(typeof DeviceCategoryEnum.TABLET).toBe('string');
  });

});
