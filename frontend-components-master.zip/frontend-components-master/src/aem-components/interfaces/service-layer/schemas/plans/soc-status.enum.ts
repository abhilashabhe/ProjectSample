export class SocStatusEnum {
  static get NEW_REQUIRED_SOC(): string {
    return 'NEW_REQUIRED_SOC';
  }

  static get CARRY_FORWARD_REQUIRED_SOC(): string {
    return 'CARRY_FORWARD_REQUIRED_SOC';
  }

  static get SYSTEM_REMOVED_REQUIRED_SOC(): string {
    return 'SYSTEM_REMOVED_REQUIRED_SOC';
  }
}
