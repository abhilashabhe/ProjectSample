import { ContractTypeEnum } from './contract-type.enum';

describe('Contract Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof ContractTypeEnum.BYOD).toBe('string');
    expect(typeof ContractTypeEnum.INSTALLMENT_BILLING).toBe('string');
    expect(typeof ContractTypeEnum.LEASE).toBe('string');
    expect(typeof ContractTypeEnum.RETAIL).toBe('string');
    expect(typeof ContractTypeEnum.SUBSIDY).toBe('string');
  });

});
