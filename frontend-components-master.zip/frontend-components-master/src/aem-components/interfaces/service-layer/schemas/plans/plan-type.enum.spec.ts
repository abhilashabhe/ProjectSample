import { PlanTypeEnum } from './plan-type.enum';

describe('Plan Type Enum', () => {

  it('should expose enum values as strings', () => {
    expect(typeof PlanTypeEnum.GROUP).toBe('string');
    expect(typeof PlanTypeEnum.HYBRID_SHARING).toBe('string');
    expect(typeof PlanTypeEnum.LTS_DATA).toBe('string');
    expect(typeof PlanTypeEnum.SHARED).toBe('string');
    expect(typeof PlanTypeEnum.SINGLE).toBe('string');
  });

});
