export interface BingResourceSet<T> {
  estimatedTotal?: number;
  resources?: T[];
}
