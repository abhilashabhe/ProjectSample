import { BingPoint } from './bing-point.interface';

export interface BingGeocodePoint extends BingPoint {
  calculationMethod?: string;
  usageTypes?: string[];
}
