import { BingResourceSet } from './bing-resource-set.interface';

export interface BingResult<T> {
  authenticationResultCode?: string;
  brandLogoUri?: string;
  copyright?: string;
  statusCode?: number;
  statusDescription?: string;
  traceId?: string;
  resourceSets?: BingResourceSet<T>[];
}
