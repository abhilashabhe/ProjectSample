export interface BingAddress {
  addressLine?: string;
  adminDistrict?: string;
  adminDistrict2?: string;
  countryRegion?: string;
  formattedAddress?: string;
  locality?: string;
  postalCode?: string;
  countryRegionIso2?: string;
}
