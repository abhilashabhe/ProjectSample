export interface BingPoint {
  point?: string;
  coordinates?: number[];
}
