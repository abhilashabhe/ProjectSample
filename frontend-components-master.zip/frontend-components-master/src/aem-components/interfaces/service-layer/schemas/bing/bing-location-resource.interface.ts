import { BingPoint } from './bing-point.interface';
import { BingAddress } from './bing-address.interface';
import { BingGeocodePoint } from './bing-geocode-point.interface';

export interface BingLocationResource {
  __type?: string;
  bbox?: number[];
  name?: string;
  point?: BingPoint;
  address?: BingAddress;
  confidence?: string;
  entityType?: string;
  geocodePoints?: BingGeocodePoint[];
  matchCodes?: string[];
}
