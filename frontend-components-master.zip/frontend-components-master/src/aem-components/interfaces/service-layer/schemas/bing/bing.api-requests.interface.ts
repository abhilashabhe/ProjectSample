import { IServiceInput } from '../..';

interface BingLocationsQueryParamsBase {
  includeNeighborhood?: string;
  inclnb?: string;
  include?: string;
  incl?: string;
  [param: string]: any;
}

export interface IGetBingLocationsRequest extends IServiceInput {
  queryParams: BingLocationsQueryParamsBase & {
    query?: string;
    q?: string;
    maxResults?: string;
    maxRes?: string;
  };
}

export interface IGetBingLocationByPointRequest extends IServiceInput {
  queryParams: BingLocationsQueryParamsBase;
  pathParams: {
    lat: number;
    long: number;
  };
}
