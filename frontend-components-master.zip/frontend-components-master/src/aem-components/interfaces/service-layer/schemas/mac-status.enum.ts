export class MacStatusEnum {
  static get NEW_MAC(): string {
    return 'NEW_MAC';
  }
}
