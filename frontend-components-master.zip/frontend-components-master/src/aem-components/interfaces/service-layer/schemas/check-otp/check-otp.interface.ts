export interface CheckOtpRequest {
  checkotp: {
    referrer: string,
    referrerUrl: string;
  };
}

export interface CheckOtpResponse {
  checkotp: {
    otpinfo: {
      otpValidated: string;
      createdOn: Date;
      otpbp: string;
    };
  };
}
