import { IServiceInput } from '../..';

export interface IPostMakeNoAccOneTimePaymentRequest extends IServiceInput {
  cardNumber: string;
  expDate: string;
  cvvCode: string;
  nameOnCard: string;
  zipCode: string;
  paymentMethod: string;
  providedEmail: string;
  cardTypeDesc: string;
}

export interface IPostValidateCardRequest extends IServiceInput {
  cardNumber: string;
}
