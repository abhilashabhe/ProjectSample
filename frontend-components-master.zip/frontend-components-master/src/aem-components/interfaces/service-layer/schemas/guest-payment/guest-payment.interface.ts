export interface GuestPaymentValidation {
    validated: boolean;
    successInfo: {
      cardType: string;
      cardTypeDesc: string;
      paymentMethod: string;
    };
}

export interface PaymentResponse {
    validated: boolean;
    successInfo: {
      successMessage: string;
      confirmationNumber: string;
      amount: string;
      posted: string;
      paidWith: string;
      cardNumber: string;
      email: string;
    };
}
