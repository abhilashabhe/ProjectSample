
export interface ISprintApiConfig {
  baseURL: string;
  mockServices: boolean;
}
