export interface ISprintStreamEvent<T> extends Event {
  type: string;
  payload: T;
}
