import { Observable } from 'rxjs/Observable';
import { ConnectableObservable } from 'rxjs/observable/ConnectableObservable';
import { ISprintApiConfig } from './sprint-api-config.interface';
import { IServiceKeys } from '../../service-layer/resources';
import { IServiceMap, IServiceDefinition, IStreamMap } from '../../service-layer/lib/internal.interfaces';
export { IServiceKeys } from '../../service-layer/resources';
export * from './sprint-api-config.interface';
export * from './service-input.interface';
export * from './service-error.interface';
export * from './sprint-stream-event.interface';

// The identifier for this component when it is registered
export const SERVICE_LAYER = 'SprintStreams';

export interface ServiceKeyListMap {
  [lookupValue: string]: IServiceKeys[];
};


export interface IServiceLayer {
  apiConfig: ISprintApiConfig;
  serviceKeysByTreeId: ServiceKeyListMap;
  serviceKeysByHttpMethod: ServiceKeyListMap;

  /**
   * @internal
   */
  sprintServiceList: IServiceDefinition[];
  /**
   * @internal
   */
  sprintStreams: IStreamMap;
  /**
   * @internal
   */
  sprintServices: IServiceMap;

  authenticate(): Promise<any>;
  getStream(key: IServiceKeys): ConnectableObservable<any>;
  getStreamRunner(key: IServiceKeys): (input: any) => Observable<any>;
  getStreamRunnerWithCache(key: IServiceKeys): (input: any) => Observable<any>;
  clearStreamRunnerCache(key: IServiceKeys, input?: any): void;
  getStreamOfType(key: IServiceKeys, type: 'data'|'errors'|'loading'): Observable<any>;
  getMergedStreamsOfType(type: 'data'|'errors'|'loading', ...keys: IServiceKeys[]): Observable<any>;
  getErrorStream(key: IServiceKeys): ConnectableObservable<any>;
  getLoadingStream(key: IServiceKeys): ConnectableObservable<any>;
}

export type IServiceLayerFactory =
  () => IServiceLayer;
