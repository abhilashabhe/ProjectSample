export interface IServiceError {
  errorCode: string;
  errorMessage: string;
  errorParameter?: string;
  errorInfo?: string;
  field?: string;
  fieldCollectionId?: string;
  url?: string;
  displayMessage?: string;
}

