export type ServiceParamValue = string | number | string[] | number[] | boolean | undefined;

export interface ServiceQueryParams {
  [param: string]: ServiceParamValue | ServiceQueryParams;
};

export interface IServiceInput {
  data?: object;
  queryParams?: ServiceQueryParams;
  pathParams?: {[param: string]: ServiceParamValue};
}

export interface IStreamDomEvent extends Event {
  type: string;
  payload: IServiceInput;
}
