import { Observable } from 'rxjs/Observable';
import * as Schemas from '../service-layer/schemas/index';

// The identifier for this component when it is registered
export const PROMO_SERVICE = 'PromoService';

export type IPromoServiceFactory =
  () => IPromoService;

export interface IPromoService extends IPromoServiceFactory {
  promos$: Observable<Schemas.Promo[]>;
  getPromos(devices: Array<string>): Observable<Schemas.Promo[]>;
  createPromoRequestFromSkus(planSOCSKUs: string[]): Observable<Schemas.Promo[]>;
  createExclusiveQualifierListFilter(planSkus: string, planSocs: string[]): Schemas.PromoFilter;
  createQualifierListFilter(deviceSkus: string, deviceIds: string[]): Schemas.PromoFilter;
  getFilteredPromos(): Observable<Schemas.NormalizedPromo[]>;
}
