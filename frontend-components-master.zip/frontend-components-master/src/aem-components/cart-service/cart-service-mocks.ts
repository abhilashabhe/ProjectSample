import * as Schemas from '../interfaces/service-layer/schemas';
import {AOObject} from './cart-service';

export default class Mocks {
  testDevice: Schemas.BaseRequestDevice = {
    itemID: '190198072221',
    contractInfo: {
      contractId: '0-yr-ib'
    }
  };
  testTablet: Schemas.BaseRequestDevice = {
    itemID: '888462834759',
    contractInfo: {
      contractId: '0-yr-ib'
    }
  };
  testPlan: Schemas.BaseRequestPlanForAddToCart = {
    planSOCSKU: 'LSD133AS',
    isShared: true
  };
  testTabletPlan: Schemas.BaseRequestPlanForAddToCart = {
    planSOCSKU: 'LS130ASTM',
    isShared: true
  };
  otherTestPlan: Schemas.BaseRequestPlanForAddToCart = {
    planSOCSKU: 'LSD133GG',
    isShared: true
  };
  testService: Schemas.BaseRequestService = {
    serviceSOCSKU: 'TEPPLUS',
    serviceStatus: 'NEW'
  };
  otherTestService: Schemas.BaseRequestService | Schemas.ServiceItem = {
    serviceSOCSKU: '77601080',
    serviceStatus: 'NEW'
  };
  testTabletService: Schemas.BaseRequestService = {
    serviceSOCSKU: 'AAPP',
    serviceStatus: 'NEW'
  };

  addDeviceTestSubpackage: Schemas.BaseRequestSubpackage = {
    device: this.testDevice,
    plan: this.testPlan,
    services: [ this.testService ]
  };

  addSharedDeviceTestSubpackage: Schemas.BaseRequestSubpackage = {
    device: this.testDevice,
    plan: this.otherTestPlan,
    services: [ this.testService ]
  };

  addTabletTestSubpackage: Schemas.BaseRequestSubpackage = {
    device: this.testTablet,
    plan: this.testTabletPlan,
    services: [ this.testTabletService ]
  };

  subscriptionLineInfo: Schemas.SubscriptionLineInfo = {
    subscriptionID: '987654321',
    ptn: '123456789',
    loanDetails: {
      loanStatus: 'INSTALLMENT_BILLING',
      deviceReturnMode: 'GIVE_BACK_FOR_INSTALLMENT_BILLING',
      deviceRemainingAmount: 100,
      currentDeviceItemId: '654321',
      currentDeviceESN: '123456',
      appleLock: false
    }
  };

  addUpgradeTestSubpackage: Schemas.BaseRequestSubpackage = {
    device: this.testDevice,
    currentSubscriberInfo: this.subscriptionLineInfo
  };

  addDeviceTestPackage: Schemas.BaseRequestPackage = {
    packageType: 'GROSS_ADD',
    packageSource: 'VML',
    quantity: 1,
    subpackages: [ this.addDeviceTestSubpackage ]
  };

  addSharedDeviceTestPackage: Schemas.BaseRequestPackage = {
    packageType: 'GROSS_ADD',
    packageSource: 'VML',
    subpackages: [ this.addSharedDeviceTestSubpackage ]
  };

  addTabletTestPackage: Schemas.BaseRequestPackage = {
    packageType: 'GROSS_ADD',
    packageSource: 'VML',
    subpackages: [ this.addTabletTestSubpackage ]
  };

  addUpgradeTestPackage: Schemas.BaseRequestPackage = {
    packageType: 'UPG',
    packageSource: 'VML',
    subpackages: [ this.addUpgradeTestSubpackage ]
  };

  testAccessories: Schemas.AccessoryItem[] = [
    {
      itemID: '12345',
      quantity: 1
    },
    {
      itemID: '54321',
      quantity: 2
    }
  ];

  AOSubpackage: Schemas.Subpackage = {
    subPackageId: '12345',
    subPackageType: 'GROSS_ADD',
    accessories: this.testAccessories
  };

  AOPackage: Schemas.Package = {
    packageSource: 'VML',
    packageType: 'AO',
    subpackages: [ this.AOSubpackage ]
  };

  AOObject: any = {
    hasAOPackage: true,
    AOPackage: this.AOPackage
  };
  NoAOObject: AOObject = {
    hasAOPackage: false,
    AOPackage: null
  };

  sharedPlan: Schemas.Plan = {
    name: '24GB Better Choice XL',
    planSOCSKU: 'LSD133AS',
    price: 105.0,
    planType: 'SHARED'
  };

  otherSharedPlan: Schemas.Plan = {
    name: '24GB Better Choice XXL',
    planSOCSKU: 'LSD134GG',
    price: 105.0,
    planType: 'SHARED'
  };

  iphone732GB: Schemas.DeviceItem & any = {
    name: 'Apple iPhone 7 32GB',
    imageURL: '/catalog/images/devices/apple/iphone_7/sliver/device_35x60_a.gif',
    deviceCommerceItemID: 'ci51234001726',
    itemID: '190198072221',
    catalogReferenceID: '106800225',
    deviceNickName: null,
    contractInfo: {
      contractId: '0-yr-ib',
      purchaseMethod: 'InstallmentBilling',
      paymentDuration: 24,
      creditCheckNeeded: true,
      offerGroupCode: null
    },
    devicePrice: {
      discountedPrice: 0.0,
      originalPrice: 649.99,
      prePurchaseDiscounts: [],
      postPurchaseDiscounts: [ {
        amount: 0.0,
        classification: 'PROMOTION',
        applyMethod: 'INVOICE_CREDIT',
        source: 'WEB',
        webExclusive: null,
        label: 'iPhone 7 Free Express Shipping',
        recurringInfo: null,
        promotionId: '105600005',
        couponCode: null
      } ],
      deviceMACList: [],
      firstMonthInstallmentPrice: 27.09,
      lastMonthInstallmentPrice: 26.92,
      depositAmount: 0.0,
      deviceServiceFee: {
        serviceFeeType: 'ACTIVATION_FEE',
        serviceFeeBasePrice: 30.0,
        serviceFeeDiscount: 0.0
      }
    },
    tradeInInfo: null,
    offerGroupInfo: null,
    tradeInRequired: false,
    earlyUpgrade: false,
    preOrder: false
  };

  tepPlus: Schemas.ServiceItem = {
    name: 'Total Equipment Protection Plus',
    serviceCommerceItemID: 'ci51234001728',
    serviceSOCSKU: 'TEPPLUS',
    catalogReferenceID: '81400517',
    serviceStatus: 'NEW',
    price: 13.0,
    postPurchaseDiscounts: [],
    isMandatory: true,
    mandatoryFromGroup: false,
    isShowInCart: true,
    chargeType: 'MRC_CHARGE'
  };

  lastSubpackage: (Schemas.Subpackage | Schemas.BaseRequestSubpackage) & any = {
    subPackageId: 'ci51234001725',
    subPackageType: 'GROSS_ADD',
    device: this.iphone732GB,
    plan: this.sharedPlan,
    services: [ this.tepPlus ],
    accessories: [],
    currentSubscriberInfo: null
  };

  otherLastSubpackage: (Schemas.Subpackage | Schemas.BaseRequestSubpackage) & any = {
    subPackageId: 'ci51234001725',
    subPackageType: 'GROSS_ADD',
    device: this.iphone732GB,
    plan: this.sharedPlan,
    services: [ this.tepPlus ],
    accessories: [],
    currentSubscriberInfo: null
  };

  devicePackage: Schemas.Package & any = {
    packageId: 'ci51234001724',
    packageType: 'GROSS_ADD',
    packageSource: '3_0_FRONT_END',
    packageSourceURL: null,
    subpackages: [ <Schemas.Subpackage>this.lastSubpackage ]
  };

  testCart: Schemas.Cart & any = {
    cartId: 'o2339226795',
    cartType: 'GROSS_ADD',
    shoppingZipCode: '66251',
    accountType: 'I',
    accountSubType: 'I',
    corpId: null,
    cartPrice: {
      totalTax: 69.89,
      aslFee: 7.99,
      todaysTotalCharge: 69.89,
      firstMonthInvoiceTotalCharge: 175.09,
      subsequentMonthsInvoiceTotalCharge: 145.09,
      totalMonthlyPriceBeforeDiscount: 145.09,
      oneTimeInvoiceCreditTotal: 0.0,
      recurringInvoiceCreditTotal: 0.0,
      shippingCharge: 0.0,
      aslFeeApplied: false,
      estimatedTax: true
    },
    status: null,
    packages: [ this.devicePackage, this.AOPackage ],
    creditRange: null
  };

  emptyCart: { [key: string]: any } = {
    cartId: 'o2339226795',
    cartType: 'GROSS_ADD',
    shoppingZipCode: '66251',
    accountType: 'I',
    accountSubType: 'I',
    corpId: null,
    cartPrice: {},
    status: null,
    packages: [],
    creditRange: null
  };

  sharedPlanPackage: { [key: string]: any } = {
    packageId: 'ci51234001724',
    packageType: 'GROSS_ADD',
    packageSource: '3_0_FRONT_END',
    packageSourceUrl: null,
    oldCarrierInfo: {
      gbLevel: null,
      oldCarrier: null,
      oldCarrierPrice: 0.0
    },
    subpackages: [ {
      subPackageId: 'ci51234001725',
      subPackageType: 'GROSS_ADD',
      device: this.iphone732GB,
      plan: this.sharedPlan,
      services: [ this.tepPlus ],
      accessories: [],
      currentSubscriberInfo: null,
      portInNeeded: false
    } ]
  };

  otherSharedPlanPackage: { [key: string]: any } = {
    packageId: 'ci51234001724',
    packageType: 'GROSS_ADD',
    packageSource: '3_0_FRONT_END',
    packageSourceUrl: null,
    oldCarrierInfo: {
      gbLevel: null,
      oldCarrier: null,
      oldCarrierPrice: 0.0
    },
    subpackages: [ {
      subPackageId: 'ci51234001725',
      subPackageType: 'GROSS_ADD',
      device: this.iphone732GB,
      plan: this.otherSharedPlan,
      services: [ this.tepPlus ],
      accessories: [],
      currentSubscriberInfo: null,
      portInNeeded: false
    } ]
  };

  aemPlanAPIResponse: { [key: string]: any } = [ {
    name: ' 24GB Better Choice XL - 5off w/AutoPay',
    id: 'pln10330002prd',
    planSkuId: '107400023',
    disabledForPackageTypes: [ 'MAO', 'UPG' ],
    planType: 'SHARED',
    minDevices: 1,
    maxDevices: 10,
    includedDataUnits: { 'unitOfMeasure': 'GB' },
    exclusivePlan: true,
    availabilityStatus: 'Sellable',
    includedDataAmount: '24',
    socId: 'LSD133AS'
  } ];

  deviceAndAOPackages: { [key: string]: any } = [
    this.devicePackage,
    this.AOPackage
  ];

  defaultBaseRequest: Schemas.BaseRequestCart & { [key: string]: any } = {
    packages: []
  };

  testBaseRequestOverride: { [key: string]: any } = {
    accountType: 'I',
    accountSubType: 'I',
    creditRange: 'GOOD_CREDIT'
  };

  testBaseRequest: Schemas.BaseRequestCart & { [key: string]: any } = {
    accountType: 'I',
    accountSubType: 'I',
    creditRange: 'GOOD_CREDIT',
    shoppingZipCode: '',
    corpId: '',
    packages: []
  };

  testCartWithAOPackage: { [key: string]: any } = {
    cartId: 'o2339226795',
    cartType: 'GROSS_ADD',
    shoppingZipCode: '66251',
    accountType: 'I',
    accountSubType: 'I',
    corpId: null,
    cartPrice: {
      totalTax: 69.89,
      aslFee: 7.99,
      todaysTotalCharge: 69.89,
      firstMonthInvoiceTotalCharge: 175.09,
      subsequentMonthsInvoiceTotalCharge: 145.09,
      totalMonthlyPriceBeforeDiscount: 145.09,
      oneTimeInvoiceCreditTotal: 0.0,
      recurringInvoiceCreditTotal: 0.0,
      shippingCharge: 0.0,
      aslFeeApplied: false,
      estimatedTax: true
    },
    status: null,
    packages: [ this.devicePackage, this.AOPackage ],
    creditRange: null
  };

  AOTestPackage: { [key: string]: any } = {
    packageType: 'AO',
    packageSource: 'VML',
    subpackages: [
      {
        accessories: this.testAccessories
      }
    ]
  };
}
