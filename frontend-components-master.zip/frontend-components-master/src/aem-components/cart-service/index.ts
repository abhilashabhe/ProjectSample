import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import { CART_SERVICE } from '../interfaces/cart-service';
import factory from './cart-service';

declare var sprintApp: ISprintApp;

(function init() {
  sprintApp.attachComponentFactory(CART_SERVICE, factory);
})();
