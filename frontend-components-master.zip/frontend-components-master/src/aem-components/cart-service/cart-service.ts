import { Observable } from 'rxjs/Observable';
import { ConnectableObservable } from 'rxjs/observable/ConnectableObservable';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import {ICartsServiceKeys} from '../service-layer/resources/carts/carts.resource-tree';
import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import { ICartService, ICartServiceFactory } from '../interfaces/cart-service/index';
import { IServiceLayerFactory, IServiceLayer } from '../interfaces/service-layer/index';
import { SERVICE_LAYER } from '../interfaces/service-layer';
import * as Schemas from '../interfaces/service-layer/schemas/index';
import {IServiceKeys} from '../service-layer/resources/resource.globals';
import { IUpdateCurrentCartRequest } from '../interfaces/service-layer/schemas/carts/carts.api-requests.interface';
declare const sprintApp: ISprintApp;
declare const Cookies: Cookies.CookiesStatic;

export interface AOObject {
  hasAOPackage: boolean;
  AOPackage: Schemas.Package | null;
}

export class CartService implements ICartService {
  // build base cart request object
  private baseRequest: Schemas.BaseRequestCart = {
    packages: []
  };

  // build base package request object
  private baseRequestPackage: Schemas.BaseRequestPackage = {
    packageType: 'GROSS_ADD',
    packageSource: 'VML',
    subpackages: []
  };

  // build base package request object
  private baseByodRequestPackage: Schemas.BaseRequestPackage = {
    packageType: 'BYOD_GA',
    packageSource: 'VML',
    subpackages: []
  };

  private loaderSelector = '[data-overlay="add-to-cart"]';
  private serviceLayer$: Observable<IServiceLayer>;
  private servicesArray: IServiceKeys[] = ['putCart', 'postCartPackages', 'putCartSubPackage', 'postCartSubPackages', 'postCartServices', 'postCartAccessories', 'deleteCart'];
  private loaderSilenced$ = new BehaviorSubject(false);

  cartStream$: ConnectableObservable<Schemas.Cart | null>;
  cartSummaryStream$: ConnectableObservable<Schemas.CartSummary>;
  itemCount$: Observable<Schemas.CartItemCount>;
  isCartEmpty$: Observable<boolean>;
  cartId$: Observable<string>;
  packages$: Observable<Schemas.Package[]>;
  subpackages$: Observable<Schemas.Subpackage[]>;
  lastPackage$: Observable<Schemas.Package | null>;
  lastSubPackage$: Observable<Schemas.Subpackage | null>;
  plans$: Observable<Schemas.Plan[]>;
  planIds$: ConnectableObservable<string[]>;
  AOPackage$: Observable<Schemas.Package | null>;
  hasAOPackage$: Observable<boolean>;
  AOObject$: ConnectableObservable<AOObject>;

  cartReady$: Observable<boolean>;
  lastAddedService$: Observable<Schemas.ServiceItem | null>;
  lastAddedDevice$: Observable<Schemas.Device | null>;
  hasAOPackage = false;
  isCartEmpty = true;
  cartLoader: HTMLElement;
  remainingLineLimit$: Observable<number>;

  static serviceLayerPromise(): Promise<IServiceLayer> {
    return sprintApp.getComponentFactory<IServiceLayerFactory>(SERVICE_LAYER)
      .then((serviceLayerFactory: IServiceLayerFactory) => serviceLayerFactory());
  }

  constructor() {

    this.cartLoader = <HTMLElement>document.querySelector(this.loaderSelector);

    this.serviceLayer$ = Observable.fromPromise(CartService.serviceLayerPromise());

    // get a reference to sprint streams for api calls
    this.cartStream$ = this.serviceLayer$
      .mergeMap( (serviceLayer) => {
        return serviceLayer.getStream('getCarts');
      })
      .map((response: { data: Schemas.Cart[] }) => response.data)
      .map((carts: Schemas.Cart[]) => {
        return (carts.length > 0 ? carts[0] : null);
      })
      .filter( (cart: Schemas.Cart) => cart !== null)
      .publishReplay(1);

    this.cartStream$.connect();

    this.cartSummaryStream$ = this.serviceLayer$
      .mergeMap( (serviceLayer) => {
        return serviceLayer.getStream('getCartSummary');
      })
      .map(res => res.data)
      .publishReplay(1);

    this.cartSummaryStream$.connect();

    this.isCartEmpty$ = this.cartStream$
      .map( (cart: Schemas.Cart) => (!cart.packages || cart.packages.length <= 0));

    this.cartId$ = this.cartStream$
      .map( (cart: Schemas.Cart) => cart.cartId);

    this.remainingLineLimit$ = Observable.merge(
      this.cartStream$,
      this.cartSummaryStream$
    )
      .map( (cart: Schemas.Cart | Schemas.CartSummary) => cart.remainingLineLimit || 0);

    this.itemCount$ = this.cartSummaryStream$
      .map(summary => summary.itemsCount);

    this.packages$ = this.cartStream$
      .map( (cart: Schemas.Cart) => cart.packages || []);

    this.subpackages$ = this.packages$
      .map( (packages: Schemas.Package[]) => {
        return packages.reduce( (subpackages: Schemas.Subpackage[], _package: Schemas.Package) => subpackages.concat(..._package.subpackages!), []);
      });

    this.lastPackage$ = this.packages$
      .map(_packages => _packages.filter(p => p.packageType !== Schemas.PackageTypeEnum.AO))
      .map((packages: Schemas.Package[]): Schemas.Package => packages[packages.length - 1]);


    this.lastSubPackage$ = this.lastPackage$
      .map( (_package: Schemas.Package) => {
        return (_package && _package.subpackages ? _package.subpackages[_package.subpackages.length - 1] : null);
      });

    this.lastAddedDevice$ = this.subpackages$
      .map( (subpackages: Schemas.Subpackage[]): Schemas.Subpackage[] => {
        return subpackages.filter(subpackage => !!(subpackage.device));
      })
      .filter((subpackages: Schemas.Subpackage[]) => {
        return subpackages.length > 0;
      })
      .map( (subpackages: Schemas.Subpackage[]) => {
        return subpackages[subpackages.length - 1].device || null;
      });

    this.lastAddedService$ = this.lastSubPackage$
      .map( (subpackage: Schemas.Subpackage) => {
        return (subpackage.services && subpackage.services.length ? subpackage.services[subpackage.services.length - 1] : null);
      });

    this.plans$ = this.subpackages$
      .map( (subpackages: Schemas.Subpackage[]) => {
        return subpackages.reduce( (plans: Schemas.Plan[], subpackage: Schemas.Subpackage) => (subpackage.plan ? plans.concat(subpackage.plan) : plans), [] );
      });

    this.planIds$ = this.plans$
      .map( (plans: Schemas.Plan[]) => {
        return plans.reduce( (ids: string[], plan: Schemas.Plan) => ids.concat(plan.planSOCSKU!), []);
      })
      .map((plans: string[]) => {
        const set = new Set(plans);
        return Array.from(set);
      })
      .publishReplay(1);

    this.planIds$.connect();

    this.AOPackage$ = this.packages$
      .map( (packages: Schemas.Package[]) => {
        const arr = packages.filter( (_package: Schemas.Package) => _package.packageType === Schemas.PackageTypeEnum.AO);
        return (arr.length > 0 ? arr[0] : null);
      });

    this.hasAOPackage$ = this.AOPackage$.map( (_package: Schemas.Package) => !!(_package));

    this.AOObject$ = Observable.combineLatest(
        this.hasAOPackage$,
        this.AOPackage$,
        (hasAOPackage: boolean, AOPackage: Schemas.Package) => ({hasAOPackage: hasAOPackage, AOPackage: AOPackage})
      )
      .publishReplay(1);

    this.AOObject$.connect();

    // Hack to get calls to go through new services
    Cookies.set('EXP_COOKIE', '2.0', { path: '/' });

    // set up cart ready
    this.cartReady$
      = Observable.combineLatest(
          this.AOObject$,
          this.serviceLayer$
            .mergeMap(serviceLayer => serviceLayer.getLoadingStream('getCarts'))
            .filter( loading => !loading)
        )
        .mapTo(true);

    // get loading streams for cart calls
    this.serviceLayer$
      .mergeMap( (serviceLayer) => {
        return serviceLayer.getMergedStreamsOfType('loading', ...this.servicesArray);
      })
      .combineLatest(
        this.loaderSilenced$,
        (loading, isSilenced) => loading && !isSilenced
      )
      .distinctUntilChanged()
      .subscribe( (loading: boolean) => {
        this.toggleLoader(loading);
      });
  }

  /**
   * method to overwrite/set base request
   * @param baseRequest
   * @returns {{}&Schemas.BaseRequestCart}
   */
  initializeBaseRequest(baseRequest: Schemas.BaseRequestCartOverride): Schemas.BaseRequestCart {
    Object.entries(baseRequest).map( ([key, value]: [string, any]) => {
      if (this.baseRequest.hasOwnProperty(key)) {
        this.baseRequest[key] = value;
      }
    });

    return Object.assign({}, this.baseRequest);
  }

  /**
   * method to update credit range in the cart
   * @param creditRange
   * @returns {any}
   */
  updateCartCreditRange(creditRange: Schemas.CreditRangeEnum): Observable<{}> {
    return this.updateCartAttribute({
      creditRange: creditRange
    });
  }

  /**
   * method to update credit range in the cart
   * @param creditRange
   * @returns {any}
   */
  updateCartCreditClass(creditClass: string): Observable<{}> {
    return this.updateCartAttribute({
      creditClass: creditClass
    });
  }

  /**
   * method to update credit range in the cart
   * @param creditRange
   * @returns {any}
   */
  updateCartZipCode(zipCode: string): Observable<{}> {
    return this.updateCartAttribute({
      shoppingZipCode: zipCode
    });
  }

  /**
   * method to add accessories to cart
   * @param accessories
   * @param subpackageId
   * @returns {any}
   */
  addAccessories(accessories: Schemas.BaseRequestAccessory[], packageId?: string, subpackageId?: string, byodFlag?: boolean): Observable<{}> {
    return Observable.combineLatest(
      this.serviceLayer$,
      this.cartId$,
      this.AOObject$,
      this.packages$,
      this.subpackages$
    )
    .take(1)
    .mergeMap( ([serviceLayer, cartId, AO, packages, subpackages]) => {
      let _package: Schemas.BaseRequestPackage;

      if (packageId && subpackageId) {

        // find subpackage
        const targetSubpackage = subpackages.filter( (subpackage: Schemas.Subpackage) => subpackage.subPackageId === subpackageId)[0];
        if (!targetSubpackage) {
          return Observable.throw({errorCode: 'addToCart:subpackagenotfound'});
        }

        // find package
        const targetPackage = packages.filter( ({packageId: pid}: Schemas.Package) => pid === packageId)[0];

        if (!targetPackage) {
          return Observable.throw({errorCode: 'addToCart:packagenotfound'});
        }

        return serviceLayer.getStreamRunner('postCartAccessories')({
          pathParams: {
            cartId: cartId,
            packageId: targetPackage.packageId,
            subpackageId: targetSubpackage.subPackageId
          },
          data: {
            accessories: accessories
          }
        });
      }
      else if (AO.hasAOPackage && AO.AOPackage) {

        return serviceLayer.getStreamRunner('postCartAccessories')({
          pathParams: {
            cartId: cartId,
            packageId: AO.AOPackage.packageId,
            subpackageId: AO.AOPackage.subpackages![0].subPackageId
          },
          data: {accessories}
        });
      }
      else {
        _package = Object.assign({}, this.baseRequestPackage);
        _package.packageType = 'AO';
        _package.subpackages = [{
          accessories: accessories
        }];
        if ( byodFlag ) {
          return this.addByodPackageToCart(_package);
        } else {
          return this.addPackageToCart(_package);
        }
      }
    });
  }

  /**
   * method to add a package to the cart
   * @param packageToAdd
   * @returns {Observable<any>}
   */
  addByodPackageToCart(packageToAdd: Schemas.BaseRequestPackage): Observable<{}> {
    let data: any;
    let streamKey: ICartsServiceKeys = 'putCart';

    return Observable.combineLatest(
      this.isCartEmpty$,
      this.cartId$
    )
    .take(1)
    .mergeMap( ([isCartEmpty, cartId]) => {

      // if cart is empty, we put
      if (isCartEmpty) {
        data = Object.assign({}, this.baseRequest);
        data.packages = [packageToAdd];
      } else {
        // otherwise we post
        streamKey = 'postCartPackages';
        data = {
          packages: [packageToAdd]
        };
      }

      // get service layer ref and make call
      return this.serviceLayer$
        .mergeMap( (serviceLayer) => {
          return serviceLayer.getStreamRunner(streamKey)({
            pathParams: {
              cartId: cartId
            },
            data: data
          });
        });
    });
  }
  /**
   * method to add a device to cart
   * @param device
   * @param plan
   * @param service
   * @param accessories
   * @param quantity
   * @returns {any}
   */
  addDevice(device: Schemas.BaseRequestDevice, plan?: Schemas.BaseRequestPlanForAddToCart, service?: Schemas.BaseRequestService | Schemas.BaseRequestService[], accessories?: Schemas.BaseRequestAccessory[], quantity?: number): Observable<{}> {
    const _package: Schemas.BaseRequestPackage = Object.assign({packageType: 'GROSS_ADD', quantity: quantity! || 1}, this.baseRequestPackage);
    _package.subpackages.push(this.buildDeviceSubPackage(device, plan!, service!, accessories!));

    return this.addPackageToCart(_package);
  }

  /**
   * method to add a byodDevice to cart
   * @param byodDevice
   * @param plan
   * @returns {any}
   */
  addByodDevice(byoddevice: Schemas.BaseRequestByodDevice, plan?: Schemas.BaseRequestPlanForAddToCart): Observable<{}> {
    const _package: Schemas.BaseRequestPackage = Object.assign({packageType: 'BYOD_GA'}, this.baseByodRequestPackage);
    _package.subpackages = [ this.buildByodDeviceSubPackage(byoddevice, plan!) ];

    return this.addPackageToCart(_package);
  }

  /**
   * method to add a tablet to cart
   * @param device
   * @param plan
   * @param service
   * @param accessories
   * @returns {any}
   */
  addTablet(device: Schemas.BaseRequestDevice, plan?: Schemas.BaseRequestPlan, service?: Schemas.BaseRequestService | Schemas.BaseRequestService[], accessories?: Schemas.BaseRequestAccessory[]): Observable<{}> {
    const _package: Schemas.BaseRequestPackage = Object.assign({packageType: 'GROSS_ADD'}, this.baseRequestPackage);
    _package.subpackages = [ this.buildDeviceSubPackage(device, plan!, service!, accessories!) ];

    return this.addPackageToCart(_package);
  }


  /**
   * method to add an upgrade to cart
   * @param device
   * @param subscriber
   * @returns {Observable<any>}
   */
  addUpgradeDevice(device: Schemas.BaseRequestDevice, subscriber: Schemas.SubscriptionLineInfo): Observable<{}> {
    const _package: Schemas.BaseRequestPackage = Object.assign(this.baseRequestPackage, {packageType: 'UPG'});
    _package.subpackages = [{
      device: device,
      currentSubscriberInfo: subscriber
    }];

    return this.addPackageToCart(_package);
  }

  /**
   * method to add a service to the cart
   * @param service
   * @returns {any}
   */
  addService(service: Schemas.BaseRequestService): Observable<{}> {
    return Observable.combineLatest(
      this.serviceLayer$,
      this.isCartEmpty$,
      this.cartId$,
      this.lastPackage$,
      this.lastSubPackage$,
      this.cartReady$
    )
    .take(1)
    .mergeMap( ([serviceLayer, isCartEmpty, cartId, lastPackage, lastSubpackage]) => {
      const servicesArray = [service];

      if (isCartEmpty || !lastPackage || !lastSubpackage) {
        return Observable.throw({errorCode: 'addToCart:flow:addDeviceBeforeService'});
      }

      return serviceLayer.getStreamRunner('postCartServices')({
        pathParams: {
          cartId: cartId,
          packageId: lastPackage.packageId,
          subpackageId: lastSubpackage.subPackageId
        },
        data: {services: servicesArray}
      });
    });
  }

  /**
   * method to delete cart
   * @returns {any}
   */
  deleteCart(): Observable<{}> {
    return Observable.combineLatest(
      this.serviceLayer$,
      this.cartId$,
      this.cartReady$
    )
    .take(1)
    .mergeMap( ([serviceLayer, cartId]) => {
      return serviceLayer.getStreamRunner('deleteCart')({
        pathParams: {
          cartId: cartId
        }
      });
    });
  }

  /**
   * method to retrieve cart
   */
  getNewCart(): Observable<Schemas.Cart | null> {
    return this.serviceLayer$
      .mergeMap( (serviceLayer) => {
        return serviceLayer.getStreamRunner('getCarts')({});
      })
      .map((response: { data: Schemas.Cart[] }) => response.data)
      .map((carts: Schemas.Cart[]) => {
        return (carts.length > 0 ? carts[0] : null);
      })
      .filter( (cart: Schemas.Cart) => cart !== null);
  }

  /**
   * method to add a package to the cart
   * @param packageToAdd
   * @returns {Observable<any>}
   */
  addPackageToCart(packageToAdd: Schemas.BaseRequestPackage): Observable<{}> {
    const payload: IUpdateCurrentCartRequest = {
      data: {
        packages: [packageToAdd]
      }
    };

    return this.serviceLayer$.mergeMap(serviceLayer => serviceLayer.getStreamRunner('updateCurrentCartPackages')(payload));
  }

  /**
   * method to add subpackage to a package in cart
   * @param packageId
   * @param subpackage
   * @returns {Observable<any>}
   */
  addCartSubpackage(packageId: string, subpackage: Schemas.BaseRequestSubpackage): Observable<{}> {
    return Observable.combineLatest(
      this.serviceLayer$,
      this.cartId$
    )
    .take(1)
    .mergeMap( ([serviceLayer, cartId]) => {
      return serviceLayer.getStreamRunner('postCartSubPackages')({
        pathParams: {
          cartId: cartId,
          packageId: packageId
        },
        data: {
          subpackages: [subpackage]
        }
      });
    });
  }

  /**
   *
   * @param device
   * @param plan
   * @param service
   * @param accessories
   */
  private buildDeviceSubPackage(device: Schemas.BaseRequestDevice, plan: Schemas.BaseRequestPlan, service: Schemas.BaseRequestService | Schemas.BaseRequestService[], accessories: Schemas.BaseRequestAccessory[]): Schemas.BaseRequestSubpackage {
    const subpackage: Schemas.BaseRequestSubpackage = {
      device: device
    };

    if (plan) {
      subpackage.plan = {
        planSOCSKU: plan.planSOCSKU
      };
    }

    if (service) {
      subpackage.services = Array.isArray(service) ? [...service] : [service];
    }

    if (accessories) {
      subpackage.accessories = accessories;
    }

    return subpackage;
  }

  /**
   *
   * @param device
   * @param plan
   * @param service
   * @param accessories
   */
  private buildByodDeviceSubPackage(byoddevice: Schemas.BaseRequestByodDevice, plan: Schemas.BaseRequestPlan): Schemas.BaseRequestSubpackage {
    const subpackage: Schemas.BaseRequestSubpackage = {
      byodDevice: byoddevice
    };

    if (plan) {
      subpackage.plan = {
        planSOCSKU: plan.planSOCSKU
      };
    }
    return subpackage;
  }

  /**
   *
   * @param loading
   */
  private toggleLoader(loading: boolean) {
    if (!this.cartLoader) {
      this.cartLoader = <HTMLElement>document.querySelector(this.loaderSelector);
    }

    if (this.cartLoader) {
      if (loading) {
        this.cartLoader.classList.add('is-active');
      } else {
        this.cartLoader.classList.remove('is-active');
      }
    }
  }

  private updateCartAttribute(data: any): Observable<any> {
    this.loaderSilenced$.next(true);
    return Observable.combineLatest(
      this.serviceLayer$,
      this.cartId$
    )
      .take(1)
      .mergeMap( ([serviceLayer, cartId]) => {
        return serviceLayer.getStreamRunner('putCart')({
          pathParams: {
            cartId: cartId
          },
          data: data
        });
      })
      .do(
        _ => this.loaderSilenced$.next(false),
        _ => this.loaderSilenced$.next(false)
      );
  }
}


// Cart Service should be treated as a singleton
let cartService: ICartService;
// Export factory as default function to simplify the encapsulation.
const factory: ICartServiceFactory = function ServiceLayerFactory(): ICartService {
  cartService = cartService || new CartService();
  return cartService;
};

export default factory;
