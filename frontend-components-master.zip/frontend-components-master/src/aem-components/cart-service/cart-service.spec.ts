/* tslint:disable */
import { Observable } from 'rxjs/Observable';
import {CartService} from './cart-service';
import factory from '../service-layer/service-layer';
import Mocks from './cart-service-mocks';
import { IServiceLayer } from '../interfaces/service-layer/index';
import { ICartService } from '../interfaces/cart-service/index';
import * as Schemas from '../../../src/aem-components/interfaces/service-layer/schemas';
import {ISprintApp, AuthModule} from '../interfaces/aem-bridge/sprint-app.interface';

declare const sprintApp: ISprintApp;

sprintApp.authModule = (sprintApp.authModule || {}) as AuthModule;
sprintApp.authModule.getUser
  = (): any => {
      return {
        userAttributes: {
          accountType: 'I',
          accountSubType: 'I'
        }
      };
    };

describe('Cart Service Loaded with Empty Cart', () => {
  let cartService: ICartService;
  let mocks: Mocks;
  let serviceLayer: IServiceLayer;
  let addPackageToCartFake: any;
  let getStreamRunnerFake: any;

  beforeEach(() => {
    mocks = new Mocks();
    serviceLayer = factory();

    spyOn(serviceLayer, 'getStream').and.callFake(() => Observable.of({
      data: [ mocks.emptyCart ]
    }));

    getStreamRunnerFake = () => () => Observable.of({
      data: [mocks.sharedPlan]
    });
    spyOn(serviceLayer, 'getStreamRunner').and.callFake(getStreamRunnerFake);

    Object.defineProperty(CartService, 'serviceLayerPromise', new Promise( () => {
      return serviceLayer;
    }));

    cartService = new CartService();
    addPackageToCartFake = (_package: Schemas.BaseRequestPackage) => Observable.of(_package);
    spyOn(cartService, 'addPackageToCart').and.callFake(addPackageToCartFake);
  });

  it('should load', () => {
    expect(cartService).toBeDefined();
  });

  it('should load observables with empty test cart data', (done) => {

    Observable.combineLatest(
      cartService.cartStream$,
      cartService.isCartEmpty$,
      cartService.cartId$,
      cartService.packages$,
      cartService.AOPackage$,
      cartService.AOObject$,
      (
        (cart,
         empty,
         id,
         packages,
         aoPackage,
         aoObject
        ) =>
          ([
            cart,
            empty,
            id,
            packages,
            aoPackage,
            aoObject
          ])
      )
    )
      .take(1)
      .subscribe(([
        cart,
        empty,
        id,
        packages,
        aoPackage,
        aoObject
      ]) => {
        expect(cart).toEqual(mocks.emptyCart);
        expect(empty).toBe(true);
        expect(id).toBe(mocks.emptyCart['cartId']);
        expect(packages).toEqual([]);
        expect(aoPackage).toBe(null);
        expect(aoObject).toEqual( {hasAOPackage: false, AOPackage: null} );
        done();
      });
  });

  it('should add a tablet to an empty cart', (done) => {
    const testPackage = Object.assign({}, mocks.addTabletTestPackage);
    delete (<Schemas.BaseRequestPlanForAddToCart>testPackage.subpackages![0].plan).isShared;
    cartService.addTablet(mocks.testTablet, mocks.testTabletPlan, mocks.testTabletService)
      .subscribe( _package => {
        expect(_package).toEqual(testPackage);
        done();
      });
  });

  it('should add device to empty cart as its own package', (done) => {
    const testPackage = Object.assign({}, mocks.addDeviceTestPackage);
    delete (<Schemas.BaseRequestPlanForAddToCart>testPackage.subpackages![0].plan).isShared;

    cartService.addDevice(mocks.testDevice, mocks.testPlan, mocks.testService)
      .subscribe(_package => {
        expect(_package).toEqual(testPackage);
        done();
      });
  });

  it('should add upgrade device to cart', (done) => {
    cartService.addUpgradeDevice(mocks.testDevice, mocks.subscriptionLineInfo)
      .subscribe( _package => {
        expect(_package).toEqual(mocks.addUpgradeTestPackage);
        done();
      });
  });

  it('should fail to add a service to empty cart', (done) => {
    cartService.addService(mocks.otherTestService)
      .subscribe(
        () => {
          // Do nothing
        },
        err => {
          expect(err.errorCode).toBe('addToCart:flow:addDeviceBeforeService');
          done();
        }
      );
  });

  it('should add accessories to cart without AO package', (done) => {
    cartService.addAccessories(mocks.testAccessories).subscribe( (_package: Schemas.BaseRequestPackage) => {
      expect(_package).toEqual(mocks.AOTestPackage);
      done();
    });
  });
});
//
describe('Cart Service Loaded with Test Cart', () => {
  let cartService: ICartService;
  let mocks: Mocks;
  let serviceLayer: IServiceLayer;
  let getStreamRunnerFake: any;
  let addPackageToCartFake: any;

  beforeEach(() => {
    mocks = new Mocks();
    serviceLayer = factory();

    spyOn(serviceLayer, 'getStream').and.callFake(() => Observable.of({
      data: [ mocks.testCart ]
    }));

    getStreamRunnerFake = () => () => Observable.of({
      data: [mocks.sharedPlan]
    });
    spyOn(serviceLayer, 'getStreamRunner').and.callFake(getStreamRunnerFake);

    Object.defineProperty(CartService, 'serviceLayerPromise', new Promise( () => {
      return serviceLayer;
    }));

    cartService = new CartService();
    addPackageToCartFake = (_package: Schemas.BaseRequestPackage) => Observable.of(_package);
    spyOn(cartService, 'addPackageToCart').and.callFake(addPackageToCartFake);

    spyOn(cartService, 'addCartSubpackage').and.callFake((id: string, subpackage: Schemas.BaseRequestSubpackage) => Observable.of({
      id: id,
      subpackage: subpackage
    }));
  });

  it('should load observables with test cart data', (done) => {

    Observable.combineLatest(
      cartService.cartStream$,
      cartService.isCartEmpty$,
      cartService.cartId$,
      cartService.packages$,
      cartService.subpackages$,
      cartService.lastPackage$,
      cartService.lastSubPackage$,
      cartService.lastAddedDevice$,
      cartService.lastAddedService$,
      cartService.plans$,
      cartService.planIds$,
      cartService.AOPackage$,
      cartService.hasAOPackage$,
      cartService.AOObject$,
      (
        (cart,
         empty,
         id,
         packages,
         subpackages,
         lastPackage,
         lastSubpackage,
         lastAddedDevice,
         lastAddedService,
         plans,
         planIds,
         aoPackage,
         hasAOPackage,
         aoObject
        ) =>
          ([
            cart,
            empty,
            id,
            packages,
            subpackages,
            lastPackage,
            lastSubpackage,
            lastAddedDevice,
            lastAddedService,
            plans,
            planIds,
            aoPackage,
            hasAOPackage,
            aoObject
          ])
      )
    )
      .take(1)
      .subscribe(([
        cart,
        empty,
        id,
        packages,
        subpackages,
        lastPackage,
        lastSubpackage,
        lastAddedDevice,
        lastAddedService,
        plans,
        planIds,
        aoPackage,
        hasAOPackage,
        aoObject
      ]) => {
        expect(cart).toBe(mocks.testCart);
        expect(empty).toBe(false);
        expect(id).toBe(mocks.testCart.cartId);
        expect(packages).toBe(mocks.testCart.packages);
        expect(subpackages).toEqual([mocks.lastSubpackage, mocks.AOSubpackage]);
        expect(lastPackage).toEqual(mocks.devicePackage);
        expect(lastSubpackage).toEqual(mocks.lastSubpackage);

        expect(lastAddedDevice).toEqual(mocks.iphone732GB);
        expect(lastAddedService).toEqual(mocks.tepPlus);
        expect(plans).toEqual([mocks.sharedPlan]);
        expect(planIds).toEqual([mocks.sharedPlan.planSOCSKU]);
        expect(aoPackage).toBe(mocks.AOPackage);
        expect(hasAOPackage).toBe(true);
        expect(aoObject).toEqual(mocks.AOObject);
        done();
      });
  });

  it('should to add service to last package', (done) => {
    const testPlan = Object.assign({}, mocks.sharedPlan);
    testPlan.shared = true;
    const testSubpackage = Object.assign({}, mocks.lastSubpackage);
    (<Array<Schemas.BaseRequestService>>testSubpackage.services).push(mocks.otherTestService);

    getStreamRunnerFake = () => (obj: any) => {
      expect(obj).toEqual({
        pathParams: {
          cartId: mocks.testCart.cartId,
          packageId: mocks.devicePackage.packageId,
          subpackageId: testSubpackage
        },
        data: [mocks.otherTestService]
      });

      return Observable.of('success');
    };

    cartService.addService(mocks.otherTestService)
      .subscribe(() => {
        done();
      });
  });

  it('should add accessories to cart with AO package', (done) => {
    const testPackage = Object.assign({}, mocks.AOPackage);
    testPackage.subpackages!.push({accessories: mocks.testAccessories});

    getStreamRunnerFake = () => (obj: any) => {
      expect(obj).toEqual({
        pathParams: {
          cartId: mocks.testCart.cartId,
          packageId: mocks.AOPackage.packageId,
          subpackageId: mocks.AOSubpackage.subPackageId
        },
        data: [mocks.testAccessories]
      });

      return Observable.of('success');
    };

    cartService.addAccessories(mocks.testAccessories).subscribe( (_package: Schemas.BaseRequestPackage) => {
      done();
    });
  });

});
