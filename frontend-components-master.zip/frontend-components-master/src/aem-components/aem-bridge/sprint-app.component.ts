import * as _ from 'lodash';
import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
import { IAEMGlobalMessage } from '../interfaces/aem-bridge/aem-global-messages.interface';
import { IAEMGlobalError } from '../interfaces/aem-bridge/aem-global-errors.interface';
import { SprintAppEventsEnum } from '../interfaces/aem-bridge/sprint-app-events.enum';
import * as addressMethods from '../shared-methods/address-methods';
import * as storageMethods from '../shared-methods/storage-methods';
import * as locationMethods from '../shared-methods/location-methods';
import * as scrollToMethods from '../shared-methods/scroll-to-methods';
import * as pricingMethods from '../shared-methods/pricing-methods';
import * as phoneMethods from '../shared-methods/phone-methods';
import * as streamMethods from '../shared-methods/stream-methods';
import * as dateMethods from '../shared-methods/date-methods';
import * as imageMethods from '../shared-methods/image-methods';
import * as stringMethods from '../shared-methods/string-methods';
import * as analyticsMethods from '../shared-methods/analytics-methods';

export class SprintApp implements ISprintApp {
  private componentFactories: {[name: string]: any};
  private componentQueue: {[name: string]: any[]};
  private configData: any;
  sharedMethods: any;
  utils: any;
  globalMessages: IAEMGlobalMessage[];
  globalErrors: IAEMGlobalError[];

  constructor() {
    // start
    this.dispatchEvent( SprintAppEventsEnum.INIT_STARTED, document, {} );

    this.componentFactories = {};
    this.componentQueue = {};
    this.configData = {};
    this.sharedMethods = {
      addressMethods,
      storageMethods,
      locationMethods,
      scrollToMethods,
      pricingMethods,
      phoneMethods,
      streamMethods,
      dateMethods,
      imageMethods,
      stringMethods,
      analyticsMethods
    };
    this.utils = {};

    this.globalMessages = [];
    this.globalErrors = [];

    // stop
    this.dispatchEvent( SprintAppEventsEnum.INIT_COMPLETED, document, {} );
  }


  /**
   * Method to dispatch a custom event in an ie safe way.
   * @param {string} eventName name of custom event
   * @param {Element|Document|Window} element element to dispatch event on
   * @param {object} obj event data
   */
  dispatchEvent(eventName: string, element: Element|Document|Window, obj: {[param: string]: any}) {
    const event: Event = document.createEvent('Event');
    event.initEvent(eventName, true, true);

    // Copy obj to the event
    for (const prop in obj) {
      if (obj.hasOwnProperty(prop)) {
        event[prop] = obj[prop];
      }
    }

    element.dispatchEvent(event);
  }

  attachComponentFactory(componentName: string, fn: any) {
    this.componentFactories[ componentName ] = fn;
    if (this.componentQueue[ componentName ]) {
      const resolves = this.componentQueue[ componentName ];
      resolves.forEach((resolve) => {
        resolve(fn);
      });
    }
  }

  getComponentFactory<T>(componentName: string): Promise<T> {
    if (this.componentFactories[ componentName ]) {
      return Promise.resolve(<T> this.componentFactories[ componentName ]);
    } else {
      if (!this.componentQueue[ componentName ]) { this.componentQueue[ componentName ] = []; }

      return new Promise<T>((resolve) => {
        this.componentQueue[ componentName ].push((fn: T) => resolve(<T> fn));
      });
    }
  }

  setConfigData(configData: any): void {
    this.configData = Object.assign({}, this.configData, configData);
  }

  getConfigData(): any {
    return _.cloneDeep(this.configData);
  }
}
