// import '../rxjs';
import { SprintApp } from './sprint-app.component';
import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
declare let sprintApp: ISprintApp;

(function init() {
  const sprintAppBackup: { [key: string]: any } = Object.assign({}, sprintApp) || {};
  sprintApp = new SprintApp();

  /**
   * We need to assign back over the cached properties that may have been added to window.sprintApp before this
   * script was executed.
   */
  const merge = (recipient: { [key: string]: any }, source: { [key: string]: any }) => {
    Object.keys(source).forEach((key) => {
      if (!recipient[key]) {
        recipient[key] = source[key];
      } else {
        if (typeof source[key] === 'object') {
          merge(recipient[key], source[key]);
        } else if (Array.isArray(source[key])) {
          recipient[key] = [].concat(source[key], recipient[key]);
        }

        // We ignore all other properties. They should not be assigned outside of frontend-components.
      }
    });
  };
  merge(sprintApp, sprintAppBackup);

  if (sprintAppBackup['baseConfig']) {
    const baseConfig = sprintAppBackup['baseConfig'];
    sprintApp.setConfigData(baseConfig);
  }
})();
