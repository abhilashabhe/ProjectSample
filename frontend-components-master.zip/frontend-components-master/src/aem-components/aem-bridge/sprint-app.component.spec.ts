/* tslint:disable:no-unused-expression */
import { SprintApp } from './sprint-app.component';
import { SprintAppEventsEnum } from '../interfaces/aem-bridge/sprint-app-events.enum';
import * as _ from 'lodash';

type ITestFactory = (name: string) => void;
const factory: ITestFactory =
  function MenuDropdownFactory() {
    /**/
  };

describe('Sprint App Component', () => {

  describe('class constructor', () => {

    it('should fire init started event when constructed', (cb) => {
      document.addEventListener(SprintAppEventsEnum.INIT_STARTED, () => {
        cb();
      });
      new SprintApp();
    });

    it('should fire init completed event when constructed', (cb) => {
      document.addEventListener(SprintAppEventsEnum.INIT_COMPLETED, () => {
        cb();
      });
      new SprintApp();
    });

  });

  describe('adding and retrieving component factories', () => {

    it('should be capable of attaching factory', () => {
      const componentName = 'Test';
      new SprintApp().attachComponentFactory(componentName, factory);
    });

    it('should process any pending requests for a factory', (cb) => {
      const componentName = 'Test';
      const sprintApp = new SprintApp();
      sprintApp.getComponentFactory<ITestFactory>(componentName).then((componentFactory) => {
        expect(typeof componentFactory).toBe('function');
        expect(componentFactory).toEqual(factory);
        cb();
      });
      sprintApp.attachComponentFactory(componentName, factory);
    });

    it('should resolve with component factory', (cb) => {
      const componentName = 'Test';
      const sprintApp = new SprintApp();
      sprintApp.attachComponentFactory(componentName, factory);

      sprintApp.getComponentFactory<ITestFactory>(componentName).then((componentFactory) => {
        expect(typeof componentFactory).toBe('function');
        expect(componentFactory).toEqual(factory);
        cb();
      });
    });

  });

  describe('adding and retrieving config data', () => {

    it('should store and return new config data', () => {
      const sprintApp = new SprintApp();
      const testData = {
        test: 'test',
        foobar: {
          bizbaz: 'test foobat.bizbaz'
        }
      };

      sprintApp.setConfigData(testData);
      expect(_.isEqual(sprintApp.getConfigData(), testData)).toBeTruthy();
    });

  });

});
