import { ISprintApp } from '../interfaces/aem-bridge/sprint-app.interface';
declare var sprintApp: ISprintApp;

describe('AEM Bridge', () => {

  it('should have created a new sprintApp object on the window', () => {
    expect(sprintApp).toBeDefined();
    expect(typeof sprintApp.attachComponentFactory).toBe('function');
    expect(typeof sprintApp.getComponentFactory).toBe('function');
  });

});
